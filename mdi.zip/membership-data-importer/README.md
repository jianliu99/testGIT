

Membership Data Migration
=

Membership Data Migration is a spring boot application which uses spring batch library to read data from csparc contract table and transforms the data and persists the data to membership and address table.

Responsibilies
-
The spring batch job does three steps to complete the migration

1. Read: The source data is read from the source table defined in CsparcContract.java.
2. Process: The data is transformed using a custom ItemProcessor implementation in MembershipDataProcessor.java.
3. Write: The transformed data is written to destination tables (Membership and Address).

How to build
-
~~~
mvn clean package
~~~

How to run locally
-
~~~
mvn spring-boot:run
~~~

How to start the migration process
-

~~~
GET /migrate-csparc-data
~~~

Reference docs
-
https://docs.spring.io/spring-batch/docs/current/reference/html/readersAndWriters.html
