package ca.bestbuy.membership.membershipdatamigration.processor;

import static ca.bestbuy.membership.membershipdatamigration.factory.CustomerFactory.buildCustomer;
import static ca.bestbuy.membership.membershipdatamigration.factory.CustomerFactory.buildCustomerWithoutAddress;
import static ca.bestbuy.membership.membershipdatamigration.factory.reltio.CrosswalkFactory.buildCrosswalk;
import static ca.bestbuy.membership.membershipdatamigration.factory.reltio.EntityFactory.buildEntity;
import static ca.bestbuy.membership.membershipdatamigration.factory.reltio.ReltioCustomerFactory.buildReltioCustomer;
import static ca.bestbuy.membership.membershipdatamigration.factory.reltio.ReltioCustomerFactory.buildReltioCustomerWithoutAddress;
import static ca.bestbuy.membership.membershipdatamigration.util.MigrationReportConstant.REPORT_STATUS_FAIL;
import static ca.bestbuy.membership.membershipdatamigration.util.MigrationReportConstant.REPORT_STATUS_PASS;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.MEMBERSHIP_ID;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.MEMBERSHIP_SYSTEM_CROSSWALK;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.PARTY_KEY_VALUE_1;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.RELTIO_CROSSWALK;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.RELTIO_CROSSWALK_VALUE;
import static java.util.Collections.singletonMap;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.CALLS_REAL_METHODS;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.when;

import ca.bestbuy.membership.membershipdatamigration.entity.reltio.Entity;
import ca.bestbuy.membership.membershipdatamigration.entity.report.MigrationReportItem;
import ca.bestbuy.membership.membershipdatamigration.entity.report.ReltioCustomer;
import ca.bestbuy.membership.membershipdatamigration.mapper.CustomerMapper;
import ca.bestbuy.membership.membershipdatamigration.repository.CustomerRepository;
import ca.bestbuy.membership.membershipdatamigration.util.ReltioSyncReportUtil;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

@ExtendWith(MockitoExtension.class)
class ReportPostCustomerMigrationProcessorTest {

    private static final Entity ENTITY = buildEntity(
        true,
        PARTY_KEY_VALUE_1,
        buildCrosswalk(MEMBERSHIP_SYSTEM_CROSSWALK, String.valueOf(MEMBERSHIP_ID)),
        buildCrosswalk(RELTIO_CROSSWALK, RELTIO_CROSSWALK_VALUE)
    );

    @InjectMocks
    private ReportPostCustomerMigrationProcessor reportPostCustomerMigrationProcessor;

    @Mock
    private CustomerRepository customerRepository;

    @Mock
    private CustomerMapper customerMapper;

    @BeforeEach
    public void setup() {
        reportPostCustomerMigrationProcessor = new ReportPostCustomerMigrationProcessor(customerRepository, customerMapper);
    }

    @Test
    void shouldReturnNonEmptyReportWhenRandomlyProcessedValidCustomerAttributeMapValidCustomerWithAddress() throws Exception {
        ReflectionTestUtils.setField(reportPostCustomerMigrationProcessor, "reportDaily", true);
        ReflectionTestUtils.setField(reportPostCustomerMigrationProcessor, "reportCoverage", 1.0);

        when(customerMapper.getCustomerMap(any(Entity.class), anyBoolean(), anyString())).thenReturn(singletonMap(
            String.valueOf(MEMBERSHIP_ID), buildReltioCustomer()
        ));
        when(customerRepository.getCustomer(anyString())).thenReturn(buildCustomer());

        final List<MigrationReportItem> result;
        try (final MockedStatic<ReltioSyncReportUtil> mockedStatic = mockStatic(ReltioSyncReportUtil.class, CALLS_REAL_METHODS)) {
            result = reportPostCustomerMigrationProcessor.process(ENTITY);
        }

        assertNotNull(result);
        assertEquals(1, result.size());

        MigrationReportItem actual = result.get(0);
        assertEquals(PARTY_KEY_VALUE_1, actual.getReltioPartyKey());
        assertEquals(REPORT_STATUS_PASS, actual.getPartyKeyStatus());
        assertEquals(REPORT_STATUS_PASS, actual.getFirstNameStatus());
        assertEquals(REPORT_STATUS_PASS, actual.getLastNameStatus());
        assertEquals(REPORT_STATUS_PASS, actual.getEmailStatus());
        assertEquals(REPORT_STATUS_PASS, actual.getPhoneStatus());
        assertEquals(REPORT_STATUS_PASS, actual.getAddressStatus());
    }

    @Test
    void shouldReturnNonEmptyReportWhenRandomlyProcessedValidCustomerAttributeMapValidCustomerWithAddressNoDailyReport() throws Exception {
        ReflectionTestUtils.setField(reportPostCustomerMigrationProcessor, "reportDaily", false);
        ReflectionTestUtils.setField(reportPostCustomerMigrationProcessor, "reportCoverage", 1.0);

        when(customerMapper.getCustomerMap(any(Entity.class), anyBoolean(), anyString())).thenReturn(singletonMap(
            String.valueOf(MEMBERSHIP_ID), buildReltioCustomer()
        ));
        when(customerRepository.getCustomer(anyString())).thenReturn(buildCustomer());

        final List<MigrationReportItem> result;
        try (final MockedStatic<ReltioSyncReportUtil> mockedStatic = mockStatic(ReltioSyncReportUtil.class, CALLS_REAL_METHODS)) {
            result = reportPostCustomerMigrationProcessor.process(ENTITY);
        }

        assertNotNull(result);
        assertEquals(1, result.size());

        MigrationReportItem actual = result.get(0);
        assertEquals(PARTY_KEY_VALUE_1, actual.getReltioPartyKey());
        assertEquals(REPORT_STATUS_PASS, actual.getPartyKeyStatus());
        assertEquals(REPORT_STATUS_PASS, actual.getFirstNameStatus());
        assertEquals(REPORT_STATUS_PASS, actual.getLastNameStatus());
        assertEquals(REPORT_STATUS_PASS, actual.getEmailStatus());
        assertEquals(REPORT_STATUS_PASS, actual.getPhoneStatus());
        assertNull(actual.getAddressStatus());
    }

    @Test
    void shouldReturnNonEmptyReportWhenRandomlyProcessedValidCustomerAttributeMapValidCustomerWithoutAddress() throws Exception {
        ReflectionTestUtils.setField(reportPostCustomerMigrationProcessor, "reportDaily", true);
        ReflectionTestUtils.setField(reportPostCustomerMigrationProcessor, "reportCoverage", 1.0);

        Map<String, ReltioCustomer> reltioCustomerMap = singletonMap(String.valueOf(MEMBERSHIP_ID), buildReltioCustomerWithoutAddress());
        when(customerMapper.getCustomerMap(any(Entity.class), anyBoolean(), anyString())).thenReturn(reltioCustomerMap);
        when(customerRepository.getCustomer(anyString())).thenReturn(buildCustomerWithoutAddress());

        final List<MigrationReportItem> result;
        try (final MockedStatic<ReltioSyncReportUtil> mockedStatic = mockStatic(ReltioSyncReportUtil.class, CALLS_REAL_METHODS)) {
            result = reportPostCustomerMigrationProcessor.process(ENTITY);
        }

        assertNotNull(result);
        assertEquals(1, result.size());

        MigrationReportItem actual = result.get(0);
        assertEquals(PARTY_KEY_VALUE_1, actual.getReltioPartyKey());
        assertEquals(REPORT_STATUS_PASS, actual.getPartyKeyStatus());
        assertEquals(REPORT_STATUS_PASS, actual.getFirstNameStatus());
        assertEquals(REPORT_STATUS_PASS, actual.getLastNameStatus());
        assertEquals(REPORT_STATUS_PASS, actual.getEmailStatus());
        assertEquals(REPORT_STATUS_PASS, actual.getPhoneStatus());
        assertNull(actual.getAddressStatus());
    }

    @Test
    void shouldReturnNonEmptyReportWhenRandomlyProcessedValidCustomerAttributeMapNullCustomer() throws Exception {
        ReflectionTestUtils.setField(reportPostCustomerMigrationProcessor, "reportCoverage", 1.0);

        when(customerMapper.getCustomerMap(any(Entity.class), anyBoolean(), anyString())).thenReturn(singletonMap(
            String.valueOf(MEMBERSHIP_ID), buildReltioCustomer()
        ));
        when(customerRepository.getCustomer(anyString())).thenReturn(null);

        List<MigrationReportItem> result;
        try (final MockedStatic<ReltioSyncReportUtil> mockedStatic = mockStatic(ReltioSyncReportUtil.class, CALLS_REAL_METHODS)) {
            result = reportPostCustomerMigrationProcessor.process(ENTITY);
        }

        assertNotNull(result);
        assertEquals(1, result.size());

        MigrationReportItem actual = result.get(0);
        assertEquals(PARTY_KEY_VALUE_1, actual.getReltioPartyKey());
        assertEquals(REPORT_STATUS_FAIL, actual.getPartyKeyStatus());
        assertNull(actual.getFirstNameStatus());
        assertNull(actual.getLastNameStatus());
        assertNull(actual.getEmailStatus());
        assertNull(actual.getPhoneStatus());
        assertNull(actual.getAddressStatus());
        assertEquals("No corresponding membership found in membership db for entity", actual.getError());
    }

    @Test
    void shouldReturnNonEmptyReportWhenRandomlyProcessedEmptyCustomerAttributeMap() throws Exception {
        ReflectionTestUtils.setField(reportPostCustomerMigrationProcessor, "reportCoverage", 1.0);
        when(customerMapper.getCustomerMap(any(Entity.class), anyBoolean(), anyString())).thenReturn(new HashMap<>());

        List<MigrationReportItem> result;
        try (final MockedStatic<ReltioSyncReportUtil> mockedStatic = mockStatic(ReltioSyncReportUtil.class, CALLS_REAL_METHODS)) {
            result = reportPostCustomerMigrationProcessor.process(ENTITY);
        }

        assertNotNull(result);
        assertEquals(1, result.size());

        MigrationReportItem actual = result.get(0);
        assertEquals(PARTY_KEY_VALUE_1, actual.getReltioPartyKey());
        assertEquals(REPORT_STATUS_FAIL, actual.getPartyKeyStatus());
        assertNull(actual.getFirstNameStatus());
        assertNull(actual.getLastNameStatus());
        assertNull(actual.getEmailStatus());
        assertNull(actual.getPhoneStatus());
        assertNull(actual.getAddressStatus());
        assertEquals("No membership db crosswalk or membership id found for entity", actual.getError());
    }

    @Test
    void shouldReturnEmptyReportWhenNotRandomlyProcessed() throws Exception {
        ReflectionTestUtils.setField(reportPostCustomerMigrationProcessor, "reportCoverage", 0.0);

        List<MigrationReportItem> result;
        try (final MockedStatic<ReltioSyncReportUtil> mockedStatic = mockStatic(ReltioSyncReportUtil.class, CALLS_REAL_METHODS)) {
            result = reportPostCustomerMigrationProcessor.process(ENTITY);
        }

        assertNotNull(result);
        assertEquals(0, result.size());
    }
}
