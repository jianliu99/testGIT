package ca.bestbuy.membership.membershipdatamigration.processor;

import static ca.bestbuy.membership.membershipdatamigration.factory.MembershipCancelRequestFactory.buildMembershipCancelRequest;
import static ca.bestbuy.membership.membershipdatamigration.factory.MembershipStatusFactory.buildMembershipStatus;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.MEMBERSHIP_CANCELLED_STATUS_DESCRIPTION;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.MEMBERSHIP_CANCELLED_STATUS_ID;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import ca.bestbuy.membership.membershipdatamigration.entity.jpa.Membership;
import ca.bestbuy.membership.membershipdatamigration.entity.jpa.MembershipCancelRequest;
import ca.bestbuy.membership.membershipdatamigration.entity.jpa.MembershipStatus;
import ca.bestbuy.membership.membershipdatamigration.entity.jpa.MembershipStatusCode;
import ca.bestbuy.membership.membershipdatamigration.entity.jpa.Status;
import ca.bestbuy.membership.membershipdatamigration.repository.MembershipStatusRepository;
import jakarta.annotation.Resource;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class CancelRequestProcessorTest {

    @InjectMocks
    @Resource
    private CancelRequestProcessor cancelRequestProcessor;

    @Mock
    private MembershipStatusRepository membershipStatusRepository;

    private MembershipCancelRequest membershipCancelRequest;

    private MembershipStatus canceledMembershipStatus;

    @Before
    public void setUp() {
        membershipCancelRequest = buildMembershipCancelRequest();
        canceledMembershipStatus = buildMembershipStatus(MEMBERSHIP_CANCELLED_STATUS_ID, Status.CANCELLED,
                MembershipStatusCode.C, MEMBERSHIP_CANCELLED_STATUS_DESCRIPTION);
    }

    @Test
    public void testProcessCancelRequestForActiveMembership() {

        when(membershipStatusRepository.getByMembershipStatusCode(MembershipStatusCode.C))
                .thenReturn(canceledMembershipStatus);

        Membership result = cancelRequestProcessor.process(membershipCancelRequest);

        assertNotNull(result);
        assertEquals(MembershipStatusCode.C, result.getMembershipStatus().getMembershipStatusCode());

        verify(membershipStatusRepository, times(1)).getByMembershipStatusCode(MembershipStatusCode.C);
    }

    @Test
    public void testProcessCancelRequestForCanceledMembership() {

        membershipCancelRequest.getMembership().setMembershipStatus(canceledMembershipStatus);
        Membership result = cancelRequestProcessor.process(membershipCancelRequest);

        assertNotNull(result);
        assertEquals(MembershipStatusCode.C, result.getMembershipStatus().getMembershipStatusCode());

        verify(membershipStatusRepository, times(0)).getByMembershipStatusCode(MembershipStatusCode.C);
    }
}
