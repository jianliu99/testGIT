package ca.bestbuy.membership.membershipdatamigration.factory;

import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.CREATED_BY;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.MEMBERSHIP_MONTHLY_PAYMENT_FREQUENCY_DESCRIPTION;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.MEMBERSHIP_PAYMENT_FREQUENCY_ID;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.TIMESTAMP;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.UPDATED_BY;

import ca.bestbuy.membership.membershipdatamigration.entity.jpa.MembershipPaymentFrequency;
import ca.bestbuy.membership.membershipdatamigration.entity.jpa.MembershipPaymentFrequencyCode;
import ca.bestbuy.membership.membershipdatamigration.entity.jpa.MembershipPaymentFrequencyName;

public class MembershipPaymentFrequencyFactory {

    public static MembershipPaymentFrequency buildMonthlyMembershipPaymentFrequency() {
        return buildMembershipPaymentFrequency(
                MembershipPaymentFrequencyName.MONTHLY,
                MembershipPaymentFrequencyCode.M,
                MEMBERSHIP_MONTHLY_PAYMENT_FREQUENCY_DESCRIPTION
        );
    }

    public static MembershipPaymentFrequency buildMembershipPaymentFrequency(
            MembershipPaymentFrequencyName paymentFrequencyName,
            MembershipPaymentFrequencyCode paymentFrequencyCode,
            String paymentFrequencyDescription) {

        MembershipPaymentFrequency membershipPaymentFrequency = new MembershipPaymentFrequency();
        membershipPaymentFrequency.setMembershipPaymentFrequencyId(MEMBERSHIP_PAYMENT_FREQUENCY_ID);
        membershipPaymentFrequency.setMembershipPaymentFrequencyName(paymentFrequencyName);
        membershipPaymentFrequency.setMembershipPaymentFrequencyCode(paymentFrequencyCode);
        membershipPaymentFrequency.setMembershipPaymentFrequencyDescription(paymentFrequencyDescription);
        membershipPaymentFrequency.setCreatedBy(CREATED_BY);
        membershipPaymentFrequency.setCreatedDate(TIMESTAMP);
        membershipPaymentFrequency.setUpdatedBy(UPDATED_BY);
        membershipPaymentFrequency.setUpdatedDate(TIMESTAMP);
        return membershipPaymentFrequency;
    }
}
