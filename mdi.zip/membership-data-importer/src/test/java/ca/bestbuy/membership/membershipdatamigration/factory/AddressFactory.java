package ca.bestbuy.membership.membershipdatamigration.factory;

import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.ADDRESS_LINE_1;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.ADDRESS_LINE_2;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.CITY;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.COUNTRY_CODE;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.COUNTRY_NAME;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.MEMBERSHIP_ID;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.POSTAL_CODE;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.REGION_CODE;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.REGION_NAME;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.SUITE;

import ca.bestbuy.membership.accountdatamigration.entity.AccountAddress;
import ca.bestbuy.membership.membershipdatamigration.entity.report.jpa.Address;

public class AddressFactory {

    public static Address buildAddress() {
        return Address.builder()
            .addressLine1(ADDRESS_LINE_1)
            .addressLine2(ADDRESS_LINE_2)
            .city(CITY)
            .suite(SUITE)
            .regionName(REGION_NAME)
            .postalCode(POSTAL_CODE)
            .countryName(COUNTRY_NAME)
            .membershipId(String.valueOf(MEMBERSHIP_ID))
            .build();
    }

    public static AccountAddress buildAccountAddress() {
        return AccountAddress.builder()
                .addressLine1(ADDRESS_LINE_1)
                .addressLine2(ADDRESS_LINE_2)
                .city(CITY)
                .regionName(REGION_NAME)
                .postalCode(POSTAL_CODE)
                .countryName(COUNTRY_NAME)
                .build();
    }
}
