package ca.bestbuy.membership.membershipdatamigration.processor;

import static ca.bestbuy.membership.membershipdatamigration.factory.MembershipFactory.buildMembership;
import static ca.bestbuy.membership.membershipdatamigration.factory.MembershipPaymentFrequencyFactory.buildMembershipPaymentFrequency;
import static ca.bestbuy.membership.membershipdatamigration.factory.MembershipStatusFactory.buildMembershipStatus;
import static ca.bestbuy.membership.membershipdatamigration.factory.PaymentCalculationFactory.buildPaymentCalculation;
import static ca.bestbuy.membership.membershipdatamigration.util.Constant.averageNumberOfDaysInMonth;
import static ca.bestbuy.membership.membershipdatamigration.util.Constant.averageNumberOfDaysInYear;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.MEMBERSHIP_ACTIVE_STATUS_DESCRIPTION;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.MEMBERSHIP_ACTIVE_STATUS_ID;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.MEMBERSHIP_ANNUAL_PAYMENT_FREQUENCY_DESCRIPTION;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.MEMBERSHIP_SUSPENDED_STATUS_DESCRIPTION;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.MEMBERSHIP_SUSPENDED_STATUS_ID;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.RECURRING_PAYMENT_AMOUNT;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import ca.bestbuy.membership.membershipdatamigration.entity.jpa.Membership;
import ca.bestbuy.membership.membershipdatamigration.entity.jpa.MembershipPaymentFrequencyCode;
import ca.bestbuy.membership.membershipdatamigration.entity.jpa.MembershipPaymentFrequencyName;
import ca.bestbuy.membership.membershipdatamigration.entity.jpa.MembershipStatus;
import ca.bestbuy.membership.membershipdatamigration.entity.jpa.MembershipStatusCode;
import ca.bestbuy.membership.membershipdatamigration.entity.jpa.PaymentCalculation;
import ca.bestbuy.membership.membershipdatamigration.entity.jpa.Status;
import ca.bestbuy.membership.membershipdatamigration.repository.MembershipPaymentRepository;
import ca.bestbuy.membership.membershipdatamigration.repository.MembershipStatusRepository;
import jakarta.annotation.Resource;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Date;
import java.sql.Timestamp;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class PaymentProcessorTest {

    @InjectMocks
    @Resource
    private PaymentProcessor paymentProcessor;

    @Mock
    private MembershipPaymentRepository membershipPaymentRepository;

    @Mock
    private MembershipStatusRepository membershipStatusRepository;

    private MembershipStatus activeMembershipStatus;

    private MembershipStatus suspendedMembershipStatus;

    private Membership membership;

    @Before
    public void setUp() {
        paymentProcessor.setGracePeriod(2);
        membership = buildMembership();
        activeMembershipStatus = buildMembershipStatus(MEMBERSHIP_ACTIVE_STATUS_ID, Status.ACTIVE,
                MembershipStatusCode.A, MEMBERSHIP_ACTIVE_STATUS_DESCRIPTION);
        suspendedMembershipStatus = buildMembershipStatus(MEMBERSHIP_SUSPENDED_STATUS_ID, Status.SUSPENDED,
                MembershipStatusCode.S, MEMBERSHIP_SUSPENDED_STATUS_DESCRIPTION);
    }

    @Test
    public void testProcessMissingPaymentsMonthlyMembership() {

        membership.setMembershipStartDate(Date.valueOf(membership.getMembershipStartDate().toLocalDate().minusMonths(3)));
        membership.setMembershipStatus(suspendedMembershipStatus);

        PaymentCalculation paymentCalculation = buildPaymentCalculation(RECURRING_PAYMENT_AMOUNT, membership);
        Membership result = paymentProcessor.process(paymentCalculation);

        assertNotNull(result);
        assertEquals(MembershipStatusCode.S, result.getMembershipStatus().getMembershipStatusCode());
        assertEquals(RECURRING_PAYMENT_AMOUNT, membership.getTotalRecurringAmountPaid());
        assertEquals(calculateExpectedPaidUpToDate(2, membership.getMembershipStartDate(), MembershipPaymentFrequencyCode.M),
                membership.getPaidUpToDate());

        verify(membershipStatusRepository, times(0)).getByMembershipStatusCode(MembershipStatusCode.A);
        verify(membershipPaymentRepository, times(0)).paymentCancelCodeExists(any(Timestamp.class), any(Integer.class));
    }

    @Test
    public void testProcessUpToFutureDatePaymentsMonthlyMembership() {

        when(membershipStatusRepository.getByMembershipStatusCode(MembershipStatusCode.A)).thenReturn(activeMembershipStatus);
        when(membershipPaymentRepository.paymentCancelCodeExists(any(Timestamp.class), any(Integer.class))).thenReturn(false);

        membership.setMembershipStartDate(Date.valueOf(membership.getMembershipStartDate().toLocalDate().minusMonths(1)));
        membership.setMembershipStatus(suspendedMembershipStatus);

        PaymentCalculation paymentCalculation = buildPaymentCalculation(RECURRING_PAYMENT_AMOUNT, membership);
        Membership result = paymentProcessor.process(paymentCalculation);

        assertNotNull(result);
        assertEquals(MembershipStatusCode.A, result.getMembershipStatus().getMembershipStatusCode());
        assertEquals(RECURRING_PAYMENT_AMOUNT, membership.getTotalRecurringAmountPaid());
        assertEquals(calculateExpectedPaidUpToDate(2, membership.getMembershipStartDate(), MembershipPaymentFrequencyCode.M),
                membership.getPaidUpToDate());

        verify(membershipStatusRepository, times(1)).getByMembershipStatusCode(MembershipStatusCode.A);
    }

    @Test
    public void testProcessUpToTodayOnlyPaymentsMonthlyMembership() {

        when(membershipStatusRepository.getByMembershipStatusCode(MembershipStatusCode.A)).thenReturn(activeMembershipStatus);
        membership.setMembershipStartDate(Date.valueOf(membership.getMembershipStartDate().toLocalDate().minusMonths(2)));
        membership.setMembershipStatus(suspendedMembershipStatus);

        PaymentCalculation paymentCalculation = buildPaymentCalculation(RECURRING_PAYMENT_AMOUNT, membership);
        Membership result = paymentProcessor.process(paymentCalculation);

        assertNotNull(result);
        assertEquals(MembershipStatusCode.A, result.getMembershipStatus().getMembershipStatusCode());
        assertEquals(RECURRING_PAYMENT_AMOUNT, membership.getTotalRecurringAmountPaid());
        assertEquals(calculateExpectedPaidUpToDate(2, membership.getMembershipStartDate(), MembershipPaymentFrequencyCode.M),
                membership.getPaidUpToDate());

        verify(membershipStatusRepository, times(1)).getByMembershipStatusCode(MembershipStatusCode.A);
        verify(membershipPaymentRepository, times(1)).paymentCancelCodeExists(any(Timestamp.class), any(Integer.class));
    }

    @Test
    public void testProcessUpToFutureDatePaymentsAnnualMembership() {

        when(membershipStatusRepository.getByMembershipStatusCode(MembershipStatusCode.A)).thenReturn(activeMembershipStatus);
        when(membershipPaymentRepository.paymentCancelCodeExists(any(Timestamp.class), any(Integer.class))).thenReturn(false);

        membership.getMembershipSku().setMembershipPaymentFrequency(buildMembershipPaymentFrequency(
                MembershipPaymentFrequencyName.ANNUAL, MembershipPaymentFrequencyCode.A, MEMBERSHIP_ANNUAL_PAYMENT_FREQUENCY_DESCRIPTION));
        membership.setMembershipStartDate(Date.valueOf(membership.getMembershipStartDate().toLocalDate().minusYears(2)));
        membership.setMembershipStatus(suspendedMembershipStatus);

        PaymentCalculation paymentCalculation = buildPaymentCalculation(RECURRING_PAYMENT_AMOUNT.multiply(BigDecimal.valueOf(2)), membership);
        Membership result = paymentProcessor.process(paymentCalculation);

        assertNotNull(result);
        assertEquals(MembershipStatusCode.A, result.getMembershipStatus().getMembershipStatusCode());
        assertEquals(RECURRING_PAYMENT_AMOUNT.multiply(BigDecimal.valueOf(2)), membership.getTotalRecurringAmountPaid());
        assertEquals(calculateExpectedPaidUpToDate(3, membership.getMembershipStartDate(), MembershipPaymentFrequencyCode.A),
                membership.getPaidUpToDate());

        verify(membershipStatusRepository, times(1)).getByMembershipStatusCode(MembershipStatusCode.A);
    }

    private Date calculateExpectedPaidUpToDate(int addedAmountExpected, Date membershipStartDate,
            MembershipPaymentFrequencyCode membershipPaymentFrequency) {

        if (membershipPaymentFrequency == MembershipPaymentFrequencyCode.A) {
            return Date.valueOf(membership.getMembershipStartDate().toLocalDate().plusDays(
                    averageNumberOfDaysInYear.multiply(BigDecimal.valueOf(addedAmountExpected))
                            .setScale(0, RoundingMode.HALF_UP).longValue()));
        } else if (membershipPaymentFrequency == MembershipPaymentFrequencyCode.M) {
            return Date.valueOf(membership.getMembershipStartDate().toLocalDate()
                    .plusDays(averageNumberOfDaysInMonth.multiply(BigDecimal.valueOf(addedAmountExpected))
                            .setScale(0, RoundingMode.HALF_UP).longValue()));
        }

        return membershipStartDate;
    }
}
