package ca.bestbuy.membership.membershipdatamigration.factory.reltio;

import static ca.bestbuy.membership.membershipdatamigration.factory.report.AddressFactory.buildAddress;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.EMAIL_ADDRESS;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.FIRST_NAME;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.LAST_NAME;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.PHONE_NUMBER;

import ca.bestbuy.membership.membershipdatamigration.entity.report.ReltioCustomer;

public class ReltioCustomerFactory {

    public static ReltioCustomer buildReltioCustomer() {
        return ReltioCustomer.builder()
            .firstName(FIRST_NAME)
            .lastName(LAST_NAME)
            .email(EMAIL_ADDRESS)
            .phoneNumber(PHONE_NUMBER)
            .address(buildAddress())
            .build();
    }

    public static ReltioCustomer buildReltioCustomerWithoutAddress() {
        return ReltioCustomer.builder()
            .firstName(FIRST_NAME)
            .lastName(LAST_NAME)
            .email(EMAIL_ADDRESS)
            .phoneNumber(PHONE_NUMBER)
            .build();
    }
}
