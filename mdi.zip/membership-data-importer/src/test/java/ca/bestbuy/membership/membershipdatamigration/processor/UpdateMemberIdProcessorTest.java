package ca.bestbuy.membership.membershipdatamigration.processor;

import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.MEMBERSHIP_CONTRACT_ID;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.MEMBER_ID;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.MEMBER_ID_NOT_EXISTENT;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.times;

import ca.bestbuy.membership.membershipdatamigration.entity.jpa.MemberIdStage;
import ca.bestbuy.membership.membershipdatamigration.entity.jpa.MembershipContract;
import ca.bestbuy.membership.membershipdatamigration.util.MemberIdGenerator;
import jakarta.annotation.Resource;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class UpdateMemberIdProcessorTest {

    @InjectMocks
    @Resource
    private UpdateMemberIdProcessor updateMemberIdProcessor;

    @Test
    public void testProcessToGenerateMemberIdWhenNotExisting() throws Exception {

        try (MockedStatic<MemberIdGenerator> mock = Mockito.mockStatic(MemberIdGenerator.class)) {
            mock.when(MemberIdGenerator::generate).thenReturn(MEMBER_ID);

            MemberIdStage result = updateMemberIdProcessor.process(new MembershipContract(MEMBERSHIP_CONTRACT_ID));

            assertNotNull(result);
            assertEquals(MEMBER_ID, result.getMemberId());
            assertEquals(MEMBERSHIP_CONTRACT_ID, result.getId());

            mock.verify(MemberIdGenerator::generate, times(1));
        }
    }

    @Test
    public void testProcessToGenerateExistingMemberId() throws Exception {

        try (MockedStatic<MemberIdGenerator> mock = Mockito.mockStatic(MemberIdGenerator.class)) {
            mock.when(MemberIdGenerator::generate).thenReturn(MEMBER_ID);

            MemberIdStage result = updateMemberIdProcessor.process(new MembershipContract(MEMBERSHIP_CONTRACT_ID));

            assertNotNull(result);
            assertEquals(MEMBER_ID, result.getMemberId());
            assertEquals(MEMBERSHIP_CONTRACT_ID, result.getId());

            mock.when(MemberIdGenerator::generate).thenReturn(MEMBER_ID_NOT_EXISTENT);

            result = updateMemberIdProcessor.process(new MembershipContract(MEMBERSHIP_CONTRACT_ID));

            assertNotNull(result);
            assertEquals(MEMBER_ID_NOT_EXISTENT, result.getMemberId());
            assertEquals(MEMBERSHIP_CONTRACT_ID, result.getId());

            mock.verify(MemberIdGenerator::generate, times(2));
        }
    }
}
