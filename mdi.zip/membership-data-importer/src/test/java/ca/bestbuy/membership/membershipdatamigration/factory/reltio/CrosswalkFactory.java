package ca.bestbuy.membership.membershipdatamigration.factory.reltio;

import ca.bestbuy.membership.membershipdatamigration.entity.reltio.Crosswalk;
import java.util.List;

public class CrosswalkFactory {

    public static Crosswalk buildCrosswalk(String type, String value, String... attributes) {
        return Crosswalk.builder()
            .type(type)
            .value(value)
            .attributes(List.of(attributes))
            .build();
    }

    public static Crosswalk buildCrosswalk(String type, String value, List<String> attributes, List<String> attributeUris) {
        return Crosswalk.builder()
            .type(type)
            .value(value)
            .attributes(attributes)
            .attributeUris(attributeUris)
            .build();
    }
}
