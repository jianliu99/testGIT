package ca.bestbuy.membership.membershipdatamigration.factory.reltio;

import ca.bestbuy.membership.membershipdatamigration.entity.reltio.PartyKey;

public class PartyKeyFactory {

    public static PartyKey buildPartyKey(boolean isOv, String value) {
        return PartyKey.builder()
            .ov(isOv)
            .value(value)
            .build();
    }
}
