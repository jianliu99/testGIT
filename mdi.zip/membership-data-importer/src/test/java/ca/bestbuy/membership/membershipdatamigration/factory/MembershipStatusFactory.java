package ca.bestbuy.membership.membershipdatamigration.factory;

import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.CREATED_BY;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.TIMESTAMP;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.UPDATED_BY;

import ca.bestbuy.membership.membershipdatamigration.entity.jpa.MembershipStatus;
import ca.bestbuy.membership.membershipdatamigration.entity.jpa.MembershipStatusCode;
import ca.bestbuy.membership.membershipdatamigration.entity.jpa.Status;

public class MembershipStatusFactory {

    public static MembershipStatus buildMembershipStatus(Integer membershipStatusId, Status status,
            MembershipStatusCode membershipStatusCode,
            String membershipStatusDescription) {
        MembershipStatus membershipStatus = new MembershipStatus();
        membershipStatus.setMembershipStatusId(membershipStatusId);
        membershipStatus.setMembershipStatusName(status);
        membershipStatus.setMembershipStatusCode(membershipStatusCode);
        membershipStatus.setMembershipStatusDescription(membershipStatusDescription);
        membershipStatus.setCreatedBy(CREATED_BY);
        membershipStatus.setCreatedDate(TIMESTAMP);
        membershipStatus.setUpdatedBy(UPDATED_BY);
        membershipStatus.setUpdatedDate(TIMESTAMP);
        return membershipStatus;
    }
}
