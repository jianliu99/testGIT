package ca.bestbuy.membership.membershipdatamigration.factory;

import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.CREATED_BY;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.MEMBERSHIP_BM_TIER_DESCRIPTION;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.MEMBERSHIP_TIER_ID;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.TIMESTAMP;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.UPDATED_BY;

import ca.bestbuy.membership.membershipdatamigration.entity.jpa.MembershipTier;
import ca.bestbuy.membership.membershipdatamigration.entity.jpa.MembershipTierCode;
import ca.bestbuy.membership.membershipdatamigration.entity.jpa.MembershipTierName;

public class MembershipTierFactory {

    public static MembershipTier buildMembershipTier() {
        MembershipTier membershipTier = new MembershipTier();
        membershipTier.setMembershipTierId(MEMBERSHIP_TIER_ID);
        membershipTier.setMembershipTierName(MembershipTierName.BEST_BUY_MEMBERSHIP);
        membershipTier.setMembershipTierCode(MembershipTierCode.BM);
        membershipTier.setMembershipTierDescription(MEMBERSHIP_BM_TIER_DESCRIPTION);
        membershipTier.setCreatedBy(CREATED_BY);
        membershipTier.setCreatedDate(TIMESTAMP);
        membershipTier.setUpdatedBy(UPDATED_BY);
        membershipTier.setUpdatedDate(TIMESTAMP);
        return membershipTier;
    }
}
