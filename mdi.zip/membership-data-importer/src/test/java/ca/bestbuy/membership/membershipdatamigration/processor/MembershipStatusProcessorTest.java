package ca.bestbuy.membership.membershipdatamigration.processor;

import static ca.bestbuy.membership.membershipdatamigration.factory.MembershipFactory.buildMembership;
import static ca.bestbuy.membership.membershipdatamigration.factory.MembershipPaymentFrequencyFactory.buildMembershipPaymentFrequency;
import static ca.bestbuy.membership.membershipdatamigration.factory.MembershipStatusFactory.buildMembershipStatus;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.MEMBERSHIP_CANCELLED_STATUS_DESCRIPTION;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.MEMBERSHIP_CANCELLED_STATUS_ID;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.MEMBERSHIP_LUMP_SUM_PAYMENT_FREQUENCY_DESCRIPTION;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.MEMBERSHIP_SUSPENDED_STATUS_DESCRIPTION;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.MEMBERSHIP_SUSPENDED_STATUS_ID;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import ca.bestbuy.membership.membershipdatamigration.entity.jpa.Membership;
import ca.bestbuy.membership.membershipdatamigration.entity.jpa.MembershipPaymentFrequencyCode;
import ca.bestbuy.membership.membershipdatamigration.entity.jpa.MembershipPaymentFrequencyName;
import ca.bestbuy.membership.membershipdatamigration.entity.jpa.MembershipStatus;
import ca.bestbuy.membership.membershipdatamigration.entity.jpa.MembershipStatusCode;
import ca.bestbuy.membership.membershipdatamigration.entity.jpa.Status;
import ca.bestbuy.membership.membershipdatamigration.repository.MembershipStatusRepository;
import jakarta.annotation.Resource;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class MembershipStatusProcessorTest {

    @InjectMocks
    @Resource
    private MembershipStatusProcessor membershipStatusProcessor;

    @Mock
    private MembershipStatusRepository membershipStatusRepository;

    private Membership membership;

    private MembershipStatus suspendedMembershipStatus;

    private MembershipStatus canceledMembershipStatus;

    @Before
    public void setUp() {
        membership = buildMembership();
        suspendedMembershipStatus = buildMembershipStatus(MEMBERSHIP_SUSPENDED_STATUS_ID, Status.SUSPENDED,
                MembershipStatusCode.S, MEMBERSHIP_SUSPENDED_STATUS_DESCRIPTION);
        canceledMembershipStatus = buildMembershipStatus(MEMBERSHIP_CANCELLED_STATUS_ID, Status.CANCELLED,
                MembershipStatusCode.C, MEMBERSHIP_CANCELLED_STATUS_DESCRIPTION);
    }

    @Test
    public void testProcessStatusChangeForMonthlyMembership() {

        when(membershipStatusRepository.getByMembershipStatusCode(MembershipStatusCode.S)).thenReturn(suspendedMembershipStatus);

        Membership result = membershipStatusProcessor.process(membership);

        assertNotNull(result);
        assertEquals(MembershipStatusCode.S, result.getMembershipStatus().getMembershipStatusCode());

        verify(membershipStatusRepository, times(1)).getByMembershipStatusCode(MembershipStatusCode.S);
    }

    @Test
    public void testProcessStatusChangeForLumpSumMembership() {
        when(membershipStatusRepository.getByMembershipStatusCode(MembershipStatusCode.C)).thenReturn(canceledMembershipStatus);

        membership.getMembershipSku().setMembershipPaymentFrequency(
                buildMembershipPaymentFrequency(MembershipPaymentFrequencyName.LUMP_SUM, MembershipPaymentFrequencyCode.LS,
                        MEMBERSHIP_LUMP_SUM_PAYMENT_FREQUENCY_DESCRIPTION));
        Membership result = membershipStatusProcessor.process(membership);

        assertNotNull(result);
        assertEquals(MembershipStatusCode.C, result.getMembershipStatus().getMembershipStatusCode());

        verify(membershipStatusRepository, times(1)).getByMembershipStatusCode(MembershipStatusCode.C);
    }

    @Test
    public void testProcessStatusChangeForCanceledMonthlyMembership() {

        membership.setMembershipStatus(buildMembershipStatus(MEMBERSHIP_CANCELLED_STATUS_ID, Status.CANCELLED,
                MembershipStatusCode.C, MEMBERSHIP_CANCELLED_STATUS_DESCRIPTION));

        Membership result = membershipStatusProcessor.process(membership);

        assertNotNull(result);
        assertEquals(MembershipStatusCode.C, result.getMembershipStatus().getMembershipStatusCode());

        verify(membershipStatusRepository, times(0)).getByMembershipStatusCode(MembershipStatusCode.S);
    }
}
