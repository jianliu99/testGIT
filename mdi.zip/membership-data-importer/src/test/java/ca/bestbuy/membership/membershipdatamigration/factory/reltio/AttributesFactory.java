package ca.bestbuy.membership.membershipdatamigration.factory.reltio;

import static ca.bestbuy.membership.membershipdatamigration.factory.reltio.PartyKeyFactory.buildPartyKey;

import ca.bestbuy.membership.membershipdatamigration.entity.reltio.Attributes;
import java.util.List;

public class AttributesFactory {

    public static Attributes buildPartyKeyAttributes(boolean isOv, String value) {
        return Attributes.builder()
            .partyKeys(List.of(buildPartyKey(isOv, value)))
            .build();
    }
}
