package ca.bestbuy.membership.membershipdatamigration.factory.reltio;

import static ca.bestbuy.membership.membershipdatamigration.factory.reltio.AttributeFactory.buildAttribute;

import ca.bestbuy.membership.membershipdatamigration.entity.reltio.Zip;
import ca.bestbuy.membership.membershipdatamigration.entity.reltio.ZipValue;
import java.util.List;

public class ZipFactory {

    public static Zip buildZip(boolean isOv, String value) {
        return Zip.builder()
            .value(buildZipValue(isOv, value))
            .build();
    }

    private static ZipValue buildZipValue(boolean isOv, String value) {
        return ZipValue.builder()
            .postalCode(List.of(buildAttribute(
                "configuration/entityTypes/Individual/attributes/Zip/attributes/Zip",
                isOv,
                value,
                "entities/abc/attributes/Address/xyz/Zip/qwe/PostalCode/rty"))
            )
            .build();
    }
}
