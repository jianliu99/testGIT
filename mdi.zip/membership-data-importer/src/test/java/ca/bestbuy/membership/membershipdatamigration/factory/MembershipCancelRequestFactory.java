package ca.bestbuy.membership.membershipdatamigration.factory;

import static ca.bestbuy.membership.membershipdatamigration.factory.MembershipCancelReasonFactory.buildMembershipCancelReason;
import static ca.bestbuy.membership.membershipdatamigration.factory.MembershipFactory.buildMembership;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.ASSURANT_ID;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.CREATED_BY;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.DATE;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.MEMBERSHIP_CANCEL_REQUEST_ID;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.TIMESTAMP;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.UPDATED_BY;

import ca.bestbuy.membership.membershipdatamigration.entity.jpa.MembershipCancelRequest;

public class MembershipCancelRequestFactory {

    public static MembershipCancelRequest buildMembershipCancelRequest() {
        MembershipCancelRequest membershipCancelRequest = new MembershipCancelRequest();
        membershipCancelRequest.setMembershipCancelRequestId(MEMBERSHIP_CANCEL_REQUEST_ID);
        membershipCancelRequest.setMembership(buildMembership());
        membershipCancelRequest.setMembershipCancelReason(buildMembershipCancelReason());
        membershipCancelRequest.setMembershipCancelRequestDate(DATE);
        membershipCancelRequest.setMembershipCancelProcessedDate(DATE);
        membershipCancelRequest.setAssurantId(ASSURANT_ID);
        membershipCancelRequest.setCreatedBy(CREATED_BY);
        membershipCancelRequest.setCreatedDate(TIMESTAMP);
        membershipCancelRequest.setUpdatedBy(UPDATED_BY);
        membershipCancelRequest.setUpdatedDate(TIMESTAMP);

        return membershipCancelRequest;
    }
}
