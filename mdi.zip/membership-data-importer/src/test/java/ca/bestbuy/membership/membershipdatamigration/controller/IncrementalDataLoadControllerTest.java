package ca.bestbuy.membership.membershipdatamigration.controller;

import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.INCREMENTAL_DATA_LOAD_PATH;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import ca.bestbuy.membership.membershipdatamigration.entity.request.IncrementalDataLoadRequest;
import ca.bestbuy.membership.membershipdatamigration.service.IncrementalDataLoadService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import jakarta.annotation.Resource;
import java.time.LocalDate;
import java.util.concurrent.Semaphore;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

@RunWith(MockitoJUnitRunner.class)
public class IncrementalDataLoadControllerTest {

    @InjectMocks
    @Resource
    private IncrementalDataLoadController incrementalDataLoadController;

    @Mock
    private IncrementalDataLoadService incrementalDataLoadService;

    private IncrementalDataLoadRequest incrementalDataLoadRequest;

    private MockMvc mockMvc;

    private ObjectMapper objectMapper;

    private final Semaphore incrementalLoadLock = new Semaphore(1);

    @Before
    public void setUp() {
        incrementalDataLoadRequest = new IncrementalDataLoadRequest();
        mockMvc = MockMvcBuilders.standaloneSetup(incrementalDataLoadController).build();
        objectMapper = new ObjectMapper().registerModule(new JavaTimeModule());
    }

    @Test
    public void testProcessIncrementalDataLoadWithCustomDate() throws Exception {
        doNothing().when(incrementalDataLoadService).processIncrementalDataLoad(any(IncrementalDataLoadRequest.class), any(Semaphore.class));

        incrementalDataLoadRequest.setIncrementalLoadStartDate(LocalDate.now());
        mockMvc.perform(MockMvcRequestBuilders.post(INCREMENTAL_DATA_LOAD_PATH)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(incrementalDataLoadRequest)))
                .andExpect(status().isOk());

        verify(incrementalDataLoadService, times(1)).processIncrementalDataLoad(any(IncrementalDataLoadRequest.class), any(Semaphore.class));
        verifyNoMoreInteractions(incrementalDataLoadService);
    }

    @Test
    public void testProcessIncrementalDataLoadWithoutCustomDate() throws Exception {
        doNothing().when(incrementalDataLoadService).processIncrementalDataLoad(any(IncrementalDataLoadRequest.class), any(Semaphore.class));

        mockMvc.perform(MockMvcRequestBuilders.post(INCREMENTAL_DATA_LOAD_PATH)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(incrementalDataLoadRequest)))
                .andExpect(status().isOk());

        verify(incrementalDataLoadService, times(1)).processIncrementalDataLoad(any(IncrementalDataLoadRequest.class), any(Semaphore.class));
        verifyNoMoreInteractions(incrementalDataLoadService);
    }

    @Test
    public void testProcessIncrementalDataLoadWithIncompleteRunFlag() throws Exception {
        doNothing().when(incrementalDataLoadService).processIncrementalDataLoad(any(IncrementalDataLoadRequest.class), any(Semaphore.class));

        incrementalDataLoadRequest.setRunIncomplete(true);
        mockMvc.perform(MockMvcRequestBuilders.post(INCREMENTAL_DATA_LOAD_PATH)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(incrementalDataLoadRequest)))
                .andExpect(status().isOk());

        verify(incrementalDataLoadService, times(1)).processIncrementalDataLoad(any(IncrementalDataLoadRequest.class), any(Semaphore.class));
        verifyNoMoreInteractions(incrementalDataLoadService);
    }

    @Test
    public void testProcessIncrementalDataLoadWithSecondRequestWhilePreviousIsOngoing() throws Exception {

        doNothing().when(incrementalDataLoadService).processIncrementalDataLoad(any(IncrementalDataLoadRequest.class), any(Semaphore.class));
        incrementalDataLoadRequest.setRunIncomplete(true);
        mockMvc.perform(MockMvcRequestBuilders.post(INCREMENTAL_DATA_LOAD_PATH)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(incrementalDataLoadRequest)))
                .andExpect(status().isOk());

        // HTTP Response code 409 is thrown if a incremental load is already running
        mockMvc.perform(MockMvcRequestBuilders.post(INCREMENTAL_DATA_LOAD_PATH)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(incrementalDataLoadRequest)))
                .andExpect(status().is4xxClientError());

    }

}
