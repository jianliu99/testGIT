package ca.bestbuy.membership.membershipdatamigration.factory.reltio;

import static ca.bestbuy.membership.membershipdatamigration.factory.reltio.AttributeFactory.buildAttribute;

import ca.bestbuy.membership.membershipdatamigration.entity.reltio.Email;
import ca.bestbuy.membership.membershipdatamigration.entity.reltio.EmailValue;
import java.util.List;

public class EmailFactory {

    public static Email buildEmail(boolean isOv, String value) {
        return Email.builder()
            .value(buildEmailValue(isOv, value))
            .build();
    }

    private static EmailValue buildEmailValue(boolean isOv, String value) {
        return EmailValue.builder()
            .email(List.of(buildAttribute(
                "configuration/entityTypes/Individual/attributes/Email/attributes/Email",
                isOv,
                value,
                "entities/abc/attributes/Email/xyz/Email/qwe"))
            )
            .build();
    }
}
