package ca.bestbuy.membership.membershipdatamigration.processor;

import static ca.bestbuy.membership.membershipdatamigration.factory.PartyKeyFactory.buildPartyKey;
import static ca.bestbuy.membership.membershipdatamigration.factory.reltio.EntityFactory.buildEntity;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.MEMBERSHIP_ID;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.MEMBERSHIP_SYSTEM_CROSSWALK;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.PARTY_KEY_VALUE_1;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.RELTIO_CROSSWALK;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.RELTIO_CROSSWALK_VALUE;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import ca.bestbuy.membership.membershipdatamigration.entity.PartyKey;
import ca.bestbuy.membership.membershipdatamigration.entity.reltio.Entity;
import ca.bestbuy.membership.membershipdatamigration.factory.reltio.CrosswalkFactory;
import java.util.List;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class PartyKeyLoadProcessorTest {

    @InjectMocks
    private PartyKeyProcessor partyKeyLoadProcessor;

    @Test
    public void testProcessWithEntityWithOvTrue() throws Exception {
        PartyKey expectedPartyKey = buildPartyKey(PARTY_KEY_VALUE_1, MEMBERSHIP_ID);
        Entity entity = buildEntity(true, PARTY_KEY_VALUE_1,
            CrosswalkFactory.buildCrosswalk(MEMBERSHIP_SYSTEM_CROSSWALK, String.valueOf(MEMBERSHIP_ID)),
            CrosswalkFactory.buildCrosswalk(RELTIO_CROSSWALK, RELTIO_CROSSWALK_VALUE)
        );

        List<PartyKey> result = partyKeyLoadProcessor.process(entity);

        assertNotNull(result);
        assertEquals(1, result.size());

        PartyKey actual = result.get(0);
        assertEquals(expectedPartyKey.getPartyKey(), actual.getPartyKey());
        assertEquals(expectedPartyKey.getMembershipId(), actual.getMembershipId());
    }

    @Test
    public void testProcessWithEntityWithOvFalse() throws Exception {
        Entity entity = buildEntity(false, PARTY_KEY_VALUE_1,
            CrosswalkFactory.buildCrosswalk(MEMBERSHIP_SYSTEM_CROSSWALK, String.valueOf(MEMBERSHIP_ID)),
            CrosswalkFactory.buildCrosswalk(RELTIO_CROSSWALK, RELTIO_CROSSWALK_VALUE)
        );

        List<PartyKey> result = partyKeyLoadProcessor.process(entity);

        assertNull(result);
    }

    @Test
    public void testProcessWithEntityWithoutMembershipSystemCrosswalk() throws Exception {
        Entity entity = buildEntity(true, PARTY_KEY_VALUE_1,
            CrosswalkFactory.buildCrosswalk(RELTIO_CROSSWALK, RELTIO_CROSSWALK_VALUE)
        );

        List<PartyKey> result = partyKeyLoadProcessor.process(entity);

        assertNull(result);
    }
}