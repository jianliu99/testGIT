package ca.bestbuy.membership.membershipdatamigration.factory.reltio;

import ca.bestbuy.membership.membershipdatamigration.entity.reltio.Attribute;

public class AttributeFactory {

    public static Attribute buildAttribute(String type, boolean isOv, String value, String uri) {
        return Attribute.builder()
            .type(type)
            .ov(isOv)
            .value(value)
            .uri(uri)
            .build();
    }
}
