package ca.bestbuy.membership.accountdatamigration.processor;

import static ca.bestbuy.membership.membershipdatamigration.factory.CustomerFactory.buildAccountCustomer;
import static ca.bestbuy.membership.membershipdatamigration.factory.reltio.CrosswalkFactory.buildCrosswalk;
import static ca.bestbuy.membership.membershipdatamigration.factory.reltio.EntityFactory.buildEntity;
import static ca.bestbuy.membership.membershipdatamigration.factory.reltio.ReltioCustomerFactory.buildReltioCustomer;
import static ca.bestbuy.membership.membershipdatamigration.factory.reltio.ReltioCustomerFactory.buildReltioCustomerWithoutAddress;
import static ca.bestbuy.membership.membershipdatamigration.util.MigrationReportConstant.REPORT_STATUS_FAIL;
import static ca.bestbuy.membership.membershipdatamigration.util.MigrationReportConstant.REPORT_STATUS_PASS;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.ACCOUNT_SYSTEM_CROSSWALK;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.MEMBERSHIP_ID;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.PARTY_KEY_VALUE_1;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.RELTIO_CROSSWALK;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.RELTIO_CROSSWALK_VALUE;
import static java.util.Collections.singletonMap;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.CALLS_REAL_METHODS;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.when;

import ca.bestbuy.membership.accountdatamigration.entity.AccountCustomer;
import ca.bestbuy.membership.accountdatamigration.entity.AccountMigrationReportItem;
import ca.bestbuy.membership.accountdatamigration.repository.AccountJdbcRepository;
import ca.bestbuy.membership.membershipdatamigration.entity.reltio.Entity;
import ca.bestbuy.membership.membershipdatamigration.entity.report.ReltioCustomer;
import ca.bestbuy.membership.membershipdatamigration.mapper.CustomerMapper;
import ca.bestbuy.membership.membershipdatamigration.util.ReltioSyncReportUtil;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

@ExtendWith(MockitoExtension.class)
class AccountReportPostMigrationProcessorTest {

    private static final Entity ENTITY = buildEntity(
        true,
        PARTY_KEY_VALUE_1,
        buildCrosswalk(ACCOUNT_SYSTEM_CROSSWALK, String.valueOf(MEMBERSHIP_ID)),
        buildCrosswalk(RELTIO_CROSSWALK, RELTIO_CROSSWALK_VALUE)
    );

    @InjectMocks
    private AccountReportPostMigrationProcessor accountReportPostMigrationProcessor;

    @Mock
    private AccountJdbcRepository accountJdbcRepository;

    @Mock
    private CustomerMapper customerMapper;

    @BeforeEach
    public void setup() {
        accountReportPostMigrationProcessor = new AccountReportPostMigrationProcessor(accountJdbcRepository, customerMapper);
    }

    @Test
    void shouldReturnNonEmptyReportWhenRandomlyProcessedValidCustomerAttributeMapValidCustomerWithAddress() throws Exception {
        ReflectionTestUtils.setField(accountReportPostMigrationProcessor, "reportDaily", true);
        ReflectionTestUtils.setField(accountReportPostMigrationProcessor, "reportCoverage", 1.0);

        when(customerMapper.getCustomerMap(any(Entity.class), anyBoolean(), anyString())).thenReturn(singletonMap(
            String.valueOf(MEMBERSHIP_ID), buildReltioCustomer()
        ));
        when(accountJdbcRepository.getCustomerById(anyString())).thenReturn(buildAccountCustomer());

        final List<AccountMigrationReportItem> result;
        try (final MockedStatic<ReltioSyncReportUtil> mockedStatic = mockStatic(ReltioSyncReportUtil.class, CALLS_REAL_METHODS)) {
            result = accountReportPostMigrationProcessor.process(ENTITY);
        }

        assertNotNull(result);
        assertEquals(1, result.size());

        AccountMigrationReportItem actual = result.get(0);
        assertEquals(PARTY_KEY_VALUE_1, actual.getReltioPartyKey());
        assertEquals(REPORT_STATUS_PASS, actual.getPartyKeyStatus());
        assertEquals(REPORT_STATUS_PASS, actual.getFirstNameStatus());
        assertEquals(REPORT_STATUS_PASS, actual.getLastNameStatus());
        assertEquals(REPORT_STATUS_PASS, actual.getEmailStatus());
        assertEquals(REPORT_STATUS_PASS, actual.getPhoneStatus());
        assertEquals(REPORT_STATUS_PASS, actual.getAddressStatus());
    }

    @Test
    void shouldReturnNonEmptyReportWhenRandomlyProcessedValidCustomerAttributeMapValidCustomerWithAddressNoDailyReport() throws Exception {
        ReflectionTestUtils.setField(accountReportPostMigrationProcessor, "reportDaily", false);
        ReflectionTestUtils.setField(accountReportPostMigrationProcessor, "reportCoverage", 1.0);

        when(customerMapper.getCustomerMap(any(Entity.class), anyBoolean(), anyString())).thenReturn(singletonMap(
            String.valueOf(MEMBERSHIP_ID), buildReltioCustomer()
        ));
        when(accountJdbcRepository.getCustomerById(anyString())).thenReturn(buildAccountCustomer());

        final List<AccountMigrationReportItem> result;
        try (final MockedStatic<ReltioSyncReportUtil> mockedStatic = mockStatic(ReltioSyncReportUtil.class, CALLS_REAL_METHODS)) {
            result = accountReportPostMigrationProcessor.process(ENTITY);
        }

        assertNotNull(result);
        assertEquals(1, result.size());

        AccountMigrationReportItem actual = result.get(0);
        assertEquals(PARTY_KEY_VALUE_1, actual.getReltioPartyKey());
        assertEquals(REPORT_STATUS_PASS, actual.getPartyKeyStatus());
        assertEquals(REPORT_STATUS_PASS, actual.getFirstNameStatus());
        assertEquals(REPORT_STATUS_PASS, actual.getLastNameStatus());
        assertEquals(REPORT_STATUS_PASS, actual.getEmailStatus());
        assertEquals(REPORT_STATUS_PASS, actual.getPhoneStatus());
        assertNull(actual.getAddressStatus());
    }

    @Test
    void shouldReturnNonEmptyReportWhenRandomlyProcessedValidCustomerAttributeMapValidCustomerWithoutAddress() throws Exception {
        ReflectionTestUtils.setField(accountReportPostMigrationProcessor, "reportDaily", true);
        ReflectionTestUtils.setField(accountReportPostMigrationProcessor, "reportCoverage", 1.0);

        Map<String, ReltioCustomer> reltioCustomerMap = singletonMap(String.valueOf(MEMBERSHIP_ID), buildReltioCustomerWithoutAddress());
        when(customerMapper.getCustomerMap(any(Entity.class), anyBoolean(), anyString())).thenReturn(reltioCustomerMap);
        AccountCustomer accountCustomer = buildAccountCustomer();
        accountCustomer.setAddress(null);
        when(accountJdbcRepository.getCustomerById(anyString())).thenReturn(accountCustomer);

        final List<AccountMigrationReportItem> result;
        try (final MockedStatic<ReltioSyncReportUtil> mockedStatic = mockStatic(ReltioSyncReportUtil.class, CALLS_REAL_METHODS)) {
            result = accountReportPostMigrationProcessor.process(ENTITY);
        }

        assertNotNull(result);
        assertEquals(1, result.size());

        AccountMigrationReportItem actual = result.get(0);
        assertEquals(PARTY_KEY_VALUE_1, actual.getReltioPartyKey());
        assertEquals(REPORT_STATUS_PASS, actual.getPartyKeyStatus());
        assertEquals(REPORT_STATUS_PASS, actual.getFirstNameStatus());
        assertEquals(REPORT_STATUS_PASS, actual.getLastNameStatus());
        assertEquals(REPORT_STATUS_PASS, actual.getEmailStatus());
        assertEquals(REPORT_STATUS_PASS, actual.getPhoneStatus());
        assertNull(actual.getAddressStatus());
    }

    @Test
    void shouldReturnNonEmptyReportWhenRandomlyProcessedValidCustomerAttributeMapNullCustomer() throws Exception {
        ReflectionTestUtils.setField(accountReportPostMigrationProcessor, "reportCoverage", 1.0);

        when(customerMapper.getCustomerMap(any(Entity.class), anyBoolean(), anyString())).thenReturn(singletonMap(
            String.valueOf(MEMBERSHIP_ID), buildReltioCustomer()
        ));
        when(accountJdbcRepository.getCustomerById(anyString())).thenReturn(null);

        List<AccountMigrationReportItem> result;
        try (final MockedStatic<ReltioSyncReportUtil> mockedStatic = mockStatic(ReltioSyncReportUtil.class, CALLS_REAL_METHODS)) {
            result = accountReportPostMigrationProcessor.process(ENTITY);
        }

        assertNotNull(result);
        assertEquals(1, result.size());

        AccountMigrationReportItem actual = result.get(0);
        assertEquals(PARTY_KEY_VALUE_1, actual.getReltioPartyKey());
        assertEquals(REPORT_STATUS_FAIL, actual.getPartyKeyStatus());
        assertNull(actual.getFirstNameStatus());
        assertNull(actual.getLastNameStatus());
        assertNull(actual.getEmailStatus());
        assertNull(actual.getPhoneStatus());
        assertNull(actual.getAddressStatus());
        assertEquals("No corresponding customer found in account db for entity", actual.getError());
    }

    @Test
    void shouldReturnNonEmptyReportWhenRandomlyProcessedEmptyCustomerAttributeMap() throws Exception {
        ReflectionTestUtils.setField(accountReportPostMigrationProcessor, "reportCoverage", 1.0);
        when(customerMapper.getCustomerMap(any(Entity.class), anyBoolean(), anyString())).thenReturn(new HashMap<>());

        List<AccountMigrationReportItem> result;
        try (final MockedStatic<ReltioSyncReportUtil> mockedStatic = mockStatic(ReltioSyncReportUtil.class, CALLS_REAL_METHODS)) {
            result = accountReportPostMigrationProcessor.process(ENTITY);
        }

        assertNotNull(result);
        assertEquals(1, result.size());

        AccountMigrationReportItem actual = result.get(0);
        assertEquals(PARTY_KEY_VALUE_1, actual.getReltioPartyKey());
        assertEquals(REPORT_STATUS_FAIL, actual.getPartyKeyStatus());
        assertNull(actual.getFirstNameStatus());
        assertNull(actual.getLastNameStatus());
        assertNull(actual.getEmailStatus());
        assertNull(actual.getPhoneStatus());
        assertNull(actual.getAddressStatus());
        assertEquals("No account db crosswalk or account key found for entity", actual.getError());
    }

    @Test
    void shouldReturnEmptyReportWhenNotRandomlyProcessed() throws Exception {
        ReflectionTestUtils.setField(accountReportPostMigrationProcessor, "reportCoverage", 0.0);

        List<AccountMigrationReportItem> result;
        try (final MockedStatic<ReltioSyncReportUtil> mockedStatic = mockStatic(ReltioSyncReportUtil.class, CALLS_REAL_METHODS)) {
            result = accountReportPostMigrationProcessor.process(ENTITY);
        }

        assertNotNull(result);
        assertEquals(0, result.size());
    }
}
