package ca.bestbuy.membership.membershipdatamigration.factory;

import static ca.bestbuy.membership.membershipdatamigration.factory.MembershipSkuFactory.buildMembershipSku;
import static ca.bestbuy.membership.membershipdatamigration.factory.MembershipStatusFactory.buildMembershipStatus;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.CREATED_BY;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.DATE;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.EMAIL_ADDRESS;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.FIRST_NAME;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.GCID;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.LAST_NAME;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.MEMBERSHIP_ACTIVE_STATUS_DESCRIPTION;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.MEMBERSHIP_ACTIVE_STATUS_ID;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.MEMBERSHIP_ID;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.MEMBER_ID;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.PSP_ID;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.STORE_ID;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.TIMESTAMP;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.TOTAL_RECURRING_AMOUNT_PAID;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.UPDATED_BY;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.ZUORA_PRODUCT_RATE_PLAN_ID;

import ca.bestbuy.membership.membershipdatamigration.entity.jpa.Membership;
import ca.bestbuy.membership.membershipdatamigration.entity.jpa.MembershipStatusCode;
import ca.bestbuy.membership.membershipdatamigration.entity.jpa.Status;

public class MembershipFactory {

    public static Membership buildMembership() {
        Membership membership = new Membership();
        membership.setMembershipId(MEMBERSHIP_ID);
        membership.setMemberId(MEMBER_ID);
        membership.setMembershipStatus(buildMembershipStatus(MEMBERSHIP_ACTIVE_STATUS_ID, Status.ACTIVE,
                MembershipStatusCode.A, MEMBERSHIP_ACTIVE_STATUS_DESCRIPTION));
        membership.setMembershipSku(buildMembershipSku());
        membership.setGlobalContractId(GCID);
        membership.setZuoraProductRatePlanId(ZUORA_PRODUCT_RATE_PLAN_ID);
        membership.setMembershipStartDate(DATE);
        membership.setMembershipEndDate(DATE);
        membership.setCreatedBy(CREATED_BY);
        membership.setCreatedDate(TIMESTAMP);
        membership.setUpdatedBy(UPDATED_BY);
        membership.setUpdatedDate(TIMESTAMP);
        membership.setEmailAddress(EMAIL_ADDRESS);
        membership.setFirstName(FIRST_NAME);
        membership.setLastName(LAST_NAME);
        membership.setPspId(PSP_ID);
        membership.setPaidUpToDate(DATE);
        membership.setStoreId(STORE_ID);
        membership.setTotalRecurringAmountPaid(TOTAL_RECURRING_AMOUNT_PAID);
        return membership;
    }
}
