package ca.bestbuy.membership.membershipdatamigration.factory.report;

import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.ADDRESS_LINE_1;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.ADDRESS_LINE_2;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.CITY;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.COUNTRY_NAME;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.POSTAL_CODE;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.REGION_NAME;

import ca.bestbuy.membership.membershipdatamigration.entity.report.Address;

public class AddressFactory {

    public static Address buildAddress() {
        return Address.builder()
            .addressLine1(ADDRESS_LINE_1)
            .addressLine2(ADDRESS_LINE_2)
            .city(CITY)
            .stateProvince(REGION_NAME)
            .zip(POSTAL_CODE)
            .country(COUNTRY_NAME)
            .build();
    }
}
