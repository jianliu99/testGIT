package ca.bestbuy.membership.membershipdatamigration.factory.reltio;

import static ca.bestbuy.membership.membershipdatamigration.factory.reltio.AddressFactory.buildAddress;
import static ca.bestbuy.membership.membershipdatamigration.factory.reltio.AttributeFactory.buildAttribute;
import static ca.bestbuy.membership.membershipdatamigration.factory.reltio.AttributesFactory.buildPartyKeyAttributes;
import static ca.bestbuy.membership.membershipdatamigration.factory.reltio.CrosswalkFactory.buildCrosswalk;
import static ca.bestbuy.membership.membershipdatamigration.factory.reltio.EmailFactory.buildEmail;
import static ca.bestbuy.membership.membershipdatamigration.factory.reltio.PhoneFactory.buildPhone;
import static ca.bestbuy.membership.membershipdatamigration.util.Constant.ENTITY_TYPE_INDIVIDUAL;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.ADDRESS_LINE_1;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.ADDRESS_LINE_2;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.CITY;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.COUNTRY_NAME;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.EMAIL_ADDRESS;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.FIRST_NAME;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.LAST_NAME;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.MEMBERSHIP_ID;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.MEMBERSHIP_SYSTEM_CROSSWALK;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.PHONE_NUMBER;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.POSTAL_CODE;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.REGION_NAME;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.RELTIO_CROSSWALK;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.RELTIO_CROSSWALK_VALUE;

import ca.bestbuy.membership.membershipdatamigration.entity.reltio.Attributes;
import ca.bestbuy.membership.membershipdatamigration.entity.reltio.Crosswalk;
import ca.bestbuy.membership.membershipdatamigration.entity.reltio.Entity;
import java.util.List;

public class EntityFactory {

    public static Entity buildEntity(boolean isOv, String value, Crosswalk... crosswalks) {
        return Entity.builder()
            .type(ENTITY_TYPE_INDIVIDUAL)
            .attributes(buildPartyKeyAttributes(isOv, value))
            .crosswalks(List.of(crosswalks))
            .build();
    }

    public static Entity buildEntity() {
        return Entity.builder()
            .type(ENTITY_TYPE_INDIVIDUAL)
            .attributes(
                Attributes.builder()
                    .firstName(List.of(buildAttribute(
                        "configuration/entityTypes/Individual/attributes/FirstName",
                        true,
                        FIRST_NAME,
                        "entities/abc/attributes/FirstName/xyz"))
                    )
                    .lastName(List.of(buildAttribute(
                        "configuration/entityTypes/Individual/attributes/LastName",
                        true,
                        LAST_NAME,
                        "entities/abc/attributes/LastName/xyz"))
                    )
                    .phoneNumbers(List.of(buildPhone(true, PHONE_NUMBER)))
                    .emails(List.of(buildEmail(true, EMAIL_ADDRESS)))
                    .addresses(List.of(buildAddress(
                        true, ADDRESS_LINE_1, ADDRESS_LINE_2, CITY, REGION_NAME, POSTAL_CODE, COUNTRY_NAME))
                    )
                    .build()
            )
            .crosswalks(List.of(
                buildCrosswalk(MEMBERSHIP_SYSTEM_CROSSWALK, String.valueOf(MEMBERSHIP_ID),
                    "entities/abc/attributes/FirstName/xyz",
                    "entities/abc/attributes/LastName/xyz",
                    "entities/abc/attributes/Email/xyz/Email/qwe",
                    "entities/abc/attributes/Phone/xyz/Number/qwe",
                    "entities/abc/attributes/AddressLine1/xyz",
                    "entities/abc/attributes/AddressLine2/xyz",
                    "entities/abc/attributes/City/xyz",
                    "entities/abc/attributes/StateProvince/xyz",
                    "entities/abc/attributes/Country/xyz"
                ),
                buildCrosswalk(RELTIO_CROSSWALK, RELTIO_CROSSWALK_VALUE)
            ))
            .build();
    }
}
