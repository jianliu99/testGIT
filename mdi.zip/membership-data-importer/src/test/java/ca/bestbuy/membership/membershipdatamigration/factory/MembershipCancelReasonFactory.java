package ca.bestbuy.membership.membershipdatamigration.factory;

import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.CREATED_BY;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.MEMBERSHIP_CANCEL_REASON_DESCRIPTION;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.MEMBERSHIP_CANCEL_REASON_ID;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.TIMESTAMP;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.UPDATED_BY;

import ca.bestbuy.membership.membershipdatamigration.entity.jpa.CancelCode;
import ca.bestbuy.membership.membershipdatamigration.entity.jpa.CancelCodeName;
import ca.bestbuy.membership.membershipdatamigration.entity.jpa.MembershipCancelReason;

public class MembershipCancelReasonFactory {

    public static MembershipCancelReason buildMembershipCancelReason() {
        MembershipCancelReason membershipCancelReason = new MembershipCancelReason();
        membershipCancelReason.setMembershipCancelReasonId(MEMBERSHIP_CANCEL_REASON_ID);
        membershipCancelReason.setMembershipCancelReasonName(CancelCodeName.COMPLETE_NONPAY);
        membershipCancelReason.setMembershipCancelReasonCode(CancelCode.OT);
        membershipCancelReason.setMembershipCancelReasonDescription(MEMBERSHIP_CANCEL_REASON_DESCRIPTION);
        membershipCancelReason.setCreatedBy(CREATED_BY);
        membershipCancelReason.setCreatedDate(TIMESTAMP);
        membershipCancelReason.setUpdatedBy(UPDATED_BY);
        membershipCancelReason.setUpdatedDate(TIMESTAMP);
        return membershipCancelReason;
    }
}
