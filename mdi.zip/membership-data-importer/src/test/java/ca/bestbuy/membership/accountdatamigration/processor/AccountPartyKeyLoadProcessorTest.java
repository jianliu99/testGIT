package ca.bestbuy.membership.accountdatamigration.processor;

import static ca.bestbuy.membership.accountdatamigration.util.Constant.ACCOUNT_SYSTEM_SOURCE;
import static ca.bestbuy.membership.membershipdatamigration.factory.PartyKeyFactory.buildAccountPartyKey;
import static ca.bestbuy.membership.membershipdatamigration.factory.reltio.EntityFactory.buildEntity;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.ACCOUNT_KEY;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.PARTY_KEY_VALUE_1;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.RELTIO_CROSSWALK;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.RELTIO_CROSSWALK_VALUE;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import ca.bestbuy.membership.accountdatamigration.entity.AccountPartyKey;
import ca.bestbuy.membership.membershipdatamigration.entity.reltio.Entity;
import ca.bestbuy.membership.membershipdatamigration.factory.reltio.CrosswalkFactory;
import java.util.List;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class AccountPartyKeyLoadProcessorTest {

    @InjectMocks
    private AccountPartyKeyProcessor partyKeyLoadProcessor;

    @Test
    public void testProcessWithEntityWithOvTrue() throws Exception {
        AccountPartyKey expectedPartyKey = buildAccountPartyKey(PARTY_KEY_VALUE_1, ACCOUNT_KEY);
        Entity entity = buildEntity(true, PARTY_KEY_VALUE_1,
            CrosswalkFactory.buildCrosswalk(ACCOUNT_SYSTEM_SOURCE, ACCOUNT_KEY),
            CrosswalkFactory.buildCrosswalk(RELTIO_CROSSWALK, RELTIO_CROSSWALK_VALUE)
        );

        List<AccountPartyKey> result = partyKeyLoadProcessor.process(entity);

        assertNotNull(result);
        assertEquals(1, result.size());

        AccountPartyKey actual = result.get(0);
        assertEquals(expectedPartyKey.getPartyKey(), actual.getPartyKey());
        assertEquals(expectedPartyKey.getAccountKey(), actual.getAccountKey());
    }

    @Test
    public void testProcessWithEntityWithOvFalse() throws Exception {
        Entity entity = buildEntity(false, PARTY_KEY_VALUE_1,
            CrosswalkFactory.buildCrosswalk(ACCOUNT_SYSTEM_SOURCE, ACCOUNT_KEY),
            CrosswalkFactory.buildCrosswalk(RELTIO_CROSSWALK, RELTIO_CROSSWALK_VALUE)
        );

        List<AccountPartyKey> result = partyKeyLoadProcessor.process(entity);

        assertNull(result);
    }

    @Test
    public void testProcessWithEntityWithoutAccountSystemCrosswalk() throws Exception {
        Entity entity = buildEntity(true, PARTY_KEY_VALUE_1,
            CrosswalkFactory.buildCrosswalk(RELTIO_CROSSWALK, RELTIO_CROSSWALK_VALUE)
        );

        List<AccountPartyKey> result = partyKeyLoadProcessor.process(entity);

        assertNull(result);
    }
}