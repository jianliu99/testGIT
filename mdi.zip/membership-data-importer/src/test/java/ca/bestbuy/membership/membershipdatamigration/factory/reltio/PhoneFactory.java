package ca.bestbuy.membership.membershipdatamigration.factory.reltio;

import static ca.bestbuy.membership.membershipdatamigration.factory.reltio.AttributeFactory.buildAttribute;

import ca.bestbuy.membership.membershipdatamigration.entity.reltio.Phone;
import ca.bestbuy.membership.membershipdatamigration.entity.reltio.PhoneValue;
import java.util.List;

public class PhoneFactory {

    public static Phone buildPhone(boolean isOv, String value) {
        return Phone.builder()
            .value(buildPhoneValue(isOv, value))
            .build();
    }

    private static PhoneValue buildPhoneValue(boolean isOv, String value) {
        return PhoneValue.builder()
            .number(List.of(buildAttribute(
                "configuration/entityTypes/Individual/attributes/Phone/attributes/Number",
                isOv,
                value,
                "entities/abc/attributes/Phone/xyz/Number/qwe"))
            )
            .build();
    }
}
