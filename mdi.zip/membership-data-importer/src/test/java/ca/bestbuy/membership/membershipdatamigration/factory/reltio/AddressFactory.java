package ca.bestbuy.membership.membershipdatamigration.factory.reltio;

import static ca.bestbuy.membership.membershipdatamigration.factory.reltio.AttributeFactory.buildAttribute;
import static ca.bestbuy.membership.membershipdatamigration.factory.reltio.CrosswalkFactory.buildCrosswalk;
import static ca.bestbuy.membership.membershipdatamigration.factory.reltio.ZipFactory.buildZip;
import static ca.bestbuy.membership.membershipdatamigration.util.Constant.MEMBERSHIP_SYSTEM_SOURCE;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.MEMBERSHIP_ID;

import ca.bestbuy.membership.membershipdatamigration.entity.reltio.Address;
import ca.bestbuy.membership.membershipdatamigration.entity.reltio.AddressValue;
import ca.bestbuy.membership.membershipdatamigration.entity.reltio.Crosswalk;
import ca.bestbuy.membership.membershipdatamigration.entity.reltio.RefEntity;
import java.util.List;

public class AddressFactory {

    public static Address buildAddress(boolean isOv, String addressLine1, String addressLine2,
                                       String city, String regionName, String postalCode, String countryName) {
        final List<Crosswalk> membershipSystemSourceCrosswalks = List.of(buildCrosswalk(
            MEMBERSHIP_SYSTEM_SOURCE,
            String.valueOf(MEMBERSHIP_ID),
            List.of(),
            List.of(
                "entities/abc/attributes/AddressLine1/xyz",
                "entities/abc/attributes/AddressLine2/xyz",
                "entities/abc/attributes/City/xyz",
                "entities/abc/attributes/StateProvince/xyz",
                "entities/abc/attributes/Country/xyz",
                "entities/abc/attributes/Address/xyz/Zip/qwe/PostalCode/rty"
            )
        ));

        return Address.builder()
            .value(buildAddressValue(isOv, addressLine1, addressLine2, city, regionName, postalCode, countryName))
            .startObjectCrosswalks(membershipSystemSourceCrosswalks)
            .refEntity(RefEntity.builder()
                .crosswalks(membershipSystemSourceCrosswalks)
                .build())
            .build();
    }

    private static AddressValue buildAddressValue(boolean isOv, String addressLine1, String addressLine2, String city,
                                                  String regionName, String postalCode, String countryName) {
        return AddressValue.builder()
            .addressLine1List(List.of(buildAttribute(
                "configuration/entityTypes/Location/attributes/AddressLine1",
                isOv,
                addressLine1,
                "entities/abc/attributes/AddressLine1/xyz"))
            )
            .addressLine2List(List.of(buildAttribute(
                "configuration/entityTypes/Location/attributes/AddressLine2",
                isOv,
                addressLine2,
                "entities/abc/attributes/AddressLine2/xyz"))
            )
            .cityList(List.of(buildAttribute(
                "configuration/entityTypes/Location/attributes/City",
                isOv,
                city,
                "entities/abc/attributes/City/xyz"))
            )
            .stateProvinceList(List.of(buildAttribute(
                "configuration/entityTypes/Location/attributes/StateProvince",
                isOv,
                regionName,
                "entities/abc/attributes/StateProvince/xyz"))
            )
            .zipList(List.of(buildZip(isOv, postalCode)))
            .countryList(List.of(buildAttribute(
                "configuration/entityTypes/Location/attributes/Country",
                isOv,
                countryName,
                "entities/abc/attributes/Country/xyz"))
            )
            .build();
    }
}
