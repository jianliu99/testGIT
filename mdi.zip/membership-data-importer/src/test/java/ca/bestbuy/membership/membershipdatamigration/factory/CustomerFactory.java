package ca.bestbuy.membership.membershipdatamigration.factory;

import static ca.bestbuy.membership.membershipdatamigration.factory.AddressFactory.buildAccountAddress;
import static ca.bestbuy.membership.membershipdatamigration.factory.AddressFactory.buildAddress;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.ACCOUNT_KEY;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.EMAIL_ADDRESS;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.FIRST_NAME;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.LAST_NAME;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.MEMBERSHIP_ID;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.PARTY_KEY_VALUE_1;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.PHONE_NUMBER;

import ca.bestbuy.membership.accountdatamigration.entity.AccountCustomer;
import ca.bestbuy.membership.membershipdatamigration.entity.report.jpa.Customer;

public class CustomerFactory {

    public static Customer buildCustomer() {
        return Customer.builder()
            .partyKey(PARTY_KEY_VALUE_1)
            .membershipId(String.valueOf(MEMBERSHIP_ID))
            .firstName(FIRST_NAME)
            .lastName(LAST_NAME)
            .emailAddress(EMAIL_ADDRESS)
            .phoneNumber(PHONE_NUMBER)
            .address(buildAddress())
            .build();
    }

    public static Customer buildCustomerWithoutAddress() {
        return Customer.builder()
            .partyKey(PARTY_KEY_VALUE_1)
            .membershipId(String.valueOf(MEMBERSHIP_ID))
            .firstName(FIRST_NAME)
            .lastName(LAST_NAME)
            .emailAddress(EMAIL_ADDRESS)
            .phoneNumber(PHONE_NUMBER)
            .build();
    }

    public static AccountCustomer buildAccountCustomer() {
        return AccountCustomer.builder()
                .partyKey(PARTY_KEY_VALUE_1)
                .accountKey(ACCOUNT_KEY)
                .firstName(FIRST_NAME)
                .lastName(LAST_NAME)
                .emailAddress(EMAIL_ADDRESS)
                .phoneNumber(PHONE_NUMBER)
                .address(buildAccountAddress())
                .build();
    }
}
