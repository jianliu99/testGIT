package ca.bestbuy.membership.membershipdatamigration.controller;

import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.EXPORT_FILE_NAME;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.http.HttpHeaders.CONTENT_DISPOSITION;
import static org.springframework.http.HttpHeaders.CONTENT_TYPE;
import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import ca.bestbuy.membership.membershipdatamigration.entity.request.PartyKeyProcessRequest;
import ca.bestbuy.membership.membershipdatamigration.service.ReportPostCustomerMigrationService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

@ExtendWith(MockitoExtension.class)
public class ReportPostCustomerMigrationControllerTest {

    @InjectMocks
    private ReportPostCustomerMigrationController reportPostCustomerMigrationController;

    @Mock
    private ReportPostCustomerMigrationService reportPostCustomerMigrationService;

    private PartyKeyProcessRequest partyKeyProcessRequest;

    private ObjectMapper objectMapper;

    private MockMvc mockMvc;

    @BeforeEach
    public void setUp() {
        partyKeyProcessRequest = PartyKeyProcessRequest.builder()
            .fileExportName(EXPORT_FILE_NAME)
            .build();
        mockMvc = MockMvcBuilders.standaloneSetup(reportPostCustomerMigrationController).build();
        objectMapper = new ObjectMapper().registerModule(new JavaTimeModule());
    }

    @Test
    void shouldStartDataSyncReportingBatchProcessSuccessfully() throws Exception {
        doNothing().when(reportPostCustomerMigrationService).reportOnMigration(anyString());

        mockMvc
            .perform(
                post("/post-customer-migration/report-data-sync")
                    .content(objectMapper.writeValueAsString(partyKeyProcessRequest))
                    .contentType(APPLICATION_JSON)
            )
            .andExpect(status().isOk());

        verify(reportPostCustomerMigrationService, times(1)).reportOnMigration(anyString());
        verifyNoMoreInteractions(reportPostCustomerMigrationService);
    }

    @Test
    void downloadOutputFileSuccessfully() throws Exception {
        final FileSystemResource fileSystemResource = mock(FileSystemResource.class);
        when(fileSystemResource.exists()).thenReturn(true);
        when(fileSystemResource.getFilename()).thenReturn("output.csv");
        ReflectionTestUtils.setField(reportPostCustomerMigrationController, "outputResource", fileSystemResource);

        final MvcResult mvcResult = mockMvc
            .perform(
                get("/download-output-file")
                    .contentType(APPLICATION_JSON))
            .andExpect(status().isOk())
            .andReturn();

        MockHttpServletResponse response = mvcResult.getResponse();
        assertEquals("application/csv", response.getHeader(CONTENT_TYPE));
        assertEquals("attachment; filename=\"output.csv\"", response.getHeader(CONTENT_DISPOSITION));
    }

    @Test
    void downloadOutputFileNotFound() throws Exception {
        mockMvc
            .perform(
                get("/download-output-file")
                    .contentType(APPLICATION_JSON))
            .andExpect(status().isNotFound());
    }
}
