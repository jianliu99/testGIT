package ca.bestbuy.membership.membershipdatamigration.util;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

public class TestConstant {

    // Routes
    public static final String INCREMENTAL_DATA_LOAD_PATH = "/process-incremental-data-load";
    public static final String PARTY_KEY_LOAD_PATH = "/process-party-key-load";

    // Generic
    public static final String CREATED_BY = "createdBy";
    public static final String UPDATED_BY = "updatedBy";
    public static final Timestamp TIMESTAMP = new Timestamp(new Date().getTime());
    public static final java.sql.Date DATE = new java.sql.Date(new Date().getTime());

    // MembershipCancelRequest
    public static final int MEMBERSHIP_CANCEL_REQUEST_ID = 1;
    public static final String ASSURANT_ID = "007612375012342-01";

    // Membership
    public static final String EMAIL_ADDRESS = "test@bestbuycanada.ca";
    public static final String PSP_ID = "pspId";
    public static final String FIRST_NAME = "Test FirstName";
    public static final String LAST_NAME = "Test LastName";
    public static final BigDecimal TOTAL_RECURRING_AMOUNT_PAID = BigDecimal.ZERO;
    public static final String GCID = "952220826900242";
    public static final String ZUORA_PRODUCT_RATE_PLAN_ID = "8ac6881f80d18d7a0180d37e5d1508f2";
    public static final Integer MEMBERSHIP_ID = 1;
    public static final Integer MEMBER_ID = 100000000;
    public static final String STORE_ID = "123";

    public static final String PARTY_KEY_VALUE_1 = "f11ed709-8f3a-45fb-9ed7-098f3a35fb1d";

    // Membership Tier
    public static final Integer MEMBERSHIP_TIER_ID = 1;
    public static final String MEMBERSHIP_BM_TIER_DESCRIPTION = "Best Buy Membership";

    // Membership Status
    public static final Integer MEMBERSHIP_ACTIVE_STATUS_ID = 1;
    public static final String MEMBERSHIP_ACTIVE_STATUS_DESCRIPTION = "Active membership status";
    public static final Integer MEMBERSHIP_CANCELLED_STATUS_ID = 2;
    public static final String MEMBERSHIP_CANCELLED_STATUS_DESCRIPTION = "Cancelled membership status";
    public static final Integer MEMBERSHIP_SUSPENDED_STATUS_ID = 3;
    public static final String MEMBERSHIP_SUSPENDED_STATUS_DESCRIPTION = "Suspended membership status";

    // Membership Sku
    public static final Integer MEMBERSHIP_SKU_ID = 1;
    public static final Integer CONTRACT_ASSET_PERIOD = 12;
    public static final BigDecimal RECURRING_PAYMENT_AMOUNT = BigDecimal.valueOf(19.99);
    public static final BigDecimal INITIAL_PAYMENT_AMOUNT = BigDecimal.valueOf(0.00);
    public static final String MEMBERSHIP_SKU = "15441165";

    // Membership Payment Frequency
    public static final Integer MEMBERSHIP_PAYMENT_FREQUENCY_ID = 1;
    public static final String MEMBERSHIP_MONTHLY_PAYMENT_FREQUENCY_DESCRIPTION = "Monthly payment frequency";
    public static final String MEMBERSHIP_LUMP_SUM_PAYMENT_FREQUENCY_DESCRIPTION = "Lump sum payment frequency";
    public static final String MEMBERSHIP_ANNUAL_PAYMENT_FREQUENCY_DESCRIPTION = "Annual payment frequency";

    // Membership Cancel Reason
    public static final Integer MEMBERSHIP_CANCEL_REASON_ID = 1;
    public static final String MEMBERSHIP_CANCEL_REASON_DESCRIPTION = "Written Off due to Non-Paymen";

    // Membership Contract
    public static final Integer MEMBERSHIP_CONTRACT_ID = 1;
    public static final Integer MEMBER_ID_NOT_EXISTENT = 100000001;

    // Reltio
    public static String MEMBERSHIP_SYSTEM_CROSSWALK = "configuration/sources/MembershipSystem";

    public static String RELTIO_CROSSWALK = "configuration/sources/Reltio";

    public static String RELTIO_CROSSWALK_VALUE = "sksk-034ldl";

    public static String ATTRIBUTE_NAME = "attributeName";
    public static String ATTRIBUTE_A = "attributeA";
    public static String ATTRIBUTE_B = "attributeB";

    // Address
    public static final String ADDRESS_LINE_1 = "Test Address Line 1";
    public static final String ADDRESS_LINE_2 = "Test Address Line 2";
    public static final String CITY = "Toronto";
    public static final String SUITE = "123";
    public static final String COUNTRY_CODE = "CA";
    public static final String COUNTRY_NAME = "Canada";
    public static final String POSTAL_CODE = "W6ZH8K";
    public static final String REGION_CODE = "ON";
    public static final String REGION_NAME = "Ontario";
    public static final String PHONE_NUMBER = "5143101010";

    public static String EXPORT_FILE_NAME = "reltio_individual.gz";

    //Account
    public static final String ACCOUNT_KEY = "{7a8c0b05-c8d8-40c2-aac2-cbe94a73d9ff}";
    public static final String ACCOUNT_PROCESS_PARTY_KEY_LOAD = "/account/process-party-key-load";
    public static String ACCOUNT_SYSTEM_CROSSWALK = "configuration/sources/AccountsDatabase";

}
