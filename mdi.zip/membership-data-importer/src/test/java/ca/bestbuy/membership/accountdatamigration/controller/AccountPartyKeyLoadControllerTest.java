package ca.bestbuy.membership.accountdatamigration.controller;

import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.ACCOUNT_PROCESS_PARTY_KEY_LOAD;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.EXPORT_FILE_NAME;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import ca.bestbuy.membership.accountdatamigration.service.AccountPartyKeyLoadService;
import ca.bestbuy.membership.membershipdatamigration.entity.request.PartyKeyProcessRequest;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import java.util.concurrent.Semaphore;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

@RunWith(MockitoJUnitRunner.class)
public class AccountPartyKeyLoadControllerTest {

    @InjectMocks
    private AccountPartyKeyLoadController partyKeyLoadController;

    @Mock
    private AccountPartyKeyLoadService partyKeyLoadService;

    private PartyKeyProcessRequest partyKeyProcessRequest;

    private ObjectMapper objectMapper;

    private MockMvc mockMvc;

    @Before
    public void setUp() {
        partyKeyProcessRequest = PartyKeyProcessRequest.builder()
            .fileExportName(EXPORT_FILE_NAME)
            .build();
        mockMvc = MockMvcBuilders.standaloneSetup(partyKeyLoadController).build();
        objectMapper = new ObjectMapper().registerModule(new JavaTimeModule());
    }

    @Test
    public void testProcessPartyKeyLoad() throws Exception {
        doNothing().when(partyKeyLoadService).processAccountPartyKeyLoad(any(Semaphore.class), anyString());

        mockMvc.perform(MockMvcRequestBuilders.post(ACCOUNT_PROCESS_PARTY_KEY_LOAD)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(partyKeyProcessRequest)))
                .andExpect(status().isOk());

        verify(partyKeyLoadService, times(1)).processAccountPartyKeyLoad(any(Semaphore.class), anyString());
        verifyNoMoreInteractions(partyKeyLoadService);
    }

    @Test
    public void testPartyKeyLoadWithSecondRequestWhilePreviousIsOngoing() throws Exception {
        doNothing().when(partyKeyLoadService).processAccountPartyKeyLoad(any(Semaphore.class), anyString());

        mockMvc.perform(MockMvcRequestBuilders.post(ACCOUNT_PROCESS_PARTY_KEY_LOAD)
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(partyKeyProcessRequest)))
            .andExpect(status().isOk());

        mockMvc.perform(MockMvcRequestBuilders.post(ACCOUNT_PROCESS_PARTY_KEY_LOAD)
             .contentType(MediaType.APPLICATION_JSON)
             .content(objectMapper.writeValueAsString(partyKeyProcessRequest)))
            .andExpect(status().isConflict());
    }
}