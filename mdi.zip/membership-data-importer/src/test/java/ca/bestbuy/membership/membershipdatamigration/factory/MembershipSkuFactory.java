package ca.bestbuy.membership.membershipdatamigration.factory;

import static ca.bestbuy.membership.membershipdatamigration.factory.MembershipPaymentFrequencyFactory.buildMonthlyMembershipPaymentFrequency;
import static ca.bestbuy.membership.membershipdatamigration.factory.MembershipTierFactory.buildMembershipTier;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.CONTRACT_ASSET_PERIOD;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.CREATED_BY;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.INITIAL_PAYMENT_AMOUNT;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.MEMBERSHIP_SKU;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.MEMBERSHIP_SKU_ID;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.RECURRING_PAYMENT_AMOUNT;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.TIMESTAMP;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.UPDATED_BY;

import ca.bestbuy.membership.membershipdatamigration.entity.jpa.MembershipSku;

public class MembershipSkuFactory {

    public static MembershipSku buildMembershipSku() {
        MembershipSku membershipSku = new MembershipSku();
        membershipSku.setMembershipSkuId(MEMBERSHIP_SKU_ID);
        membershipSku.setMembershipSku(MEMBERSHIP_SKU);
        membershipSku.setMembershipPaymentFrequency(buildMonthlyMembershipPaymentFrequency());
        membershipSku.setContractAssetPeriod(CONTRACT_ASSET_PERIOD);
        membershipSku.setInitialPaymentAmount(INITIAL_PAYMENT_AMOUNT);
        membershipSku.setRecurringPaymentAmount(RECURRING_PAYMENT_AMOUNT);
        membershipSku.setMembershipTier(buildMembershipTier());
        membershipSku.setCreatedBy(CREATED_BY);
        membershipSku.setCreatedDate(TIMESTAMP);
        membershipSku.setUpdatedBy(UPDATED_BY);
        membershipSku.setUpdatedDate(TIMESTAMP);
        return membershipSku;
    }
}
