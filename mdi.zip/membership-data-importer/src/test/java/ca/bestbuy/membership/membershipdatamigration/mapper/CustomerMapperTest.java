package ca.bestbuy.membership.membershipdatamigration.mapper;

import static ca.bestbuy.membership.membershipdatamigration.factory.reltio.CrosswalkFactory.buildCrosswalk;
import static ca.bestbuy.membership.membershipdatamigration.factory.reltio.EntityFactory.buildEntity;
import static ca.bestbuy.membership.membershipdatamigration.util.Constant.MEMBERSHIP_SYSTEM_SOURCE;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.ADDRESS_LINE_1;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.ADDRESS_LINE_2;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.CITY;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.COUNTRY_NAME;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.EMAIL_ADDRESS;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.FIRST_NAME;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.LAST_NAME;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.MEMBERSHIP_ID;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.MEMBERSHIP_SYSTEM_CROSSWALK;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.PARTY_KEY_VALUE_1;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.PHONE_NUMBER;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.POSTAL_CODE;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.REGION_NAME;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.RELTIO_CROSSWALK;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.RELTIO_CROSSWALK_VALUE;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

import ca.bestbuy.membership.membershipdatamigration.entity.reltio.Entity;
import ca.bestbuy.membership.membershipdatamigration.entity.report.ReltioCustomer;
import java.util.Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class CustomerMapperTest {

    @InjectMocks
    private CustomerMapper customerMapper;

    @BeforeEach
    public void setup() {
        customerMapper = new CustomerMapper();
    }

    @Test
    void testGetCustomerMap() {
        final Map<String, ReltioCustomer> customerMap = customerMapper.getCustomerMap(buildEntity(), true, MEMBERSHIP_SYSTEM_SOURCE);

        assertNotNull(customerMap);
        assertEquals(1, customerMap.size());
        assertEquals(1, customerMap.keySet().size());
        assertEquals(1, customerMap.values().size());

        ReltioCustomer reltioCustomer = customerMap.get(String.valueOf(MEMBERSHIP_ID));
        assertNotNull(reltioCustomer);
        assertEquals(FIRST_NAME, reltioCustomer.getFirstName());
        assertEquals(LAST_NAME, reltioCustomer.getLastName());
        assertEquals(EMAIL_ADDRESS, reltioCustomer.getEmail());
        assertEquals(PHONE_NUMBER, reltioCustomer.getPhoneNumber());

        assertNotNull(reltioCustomer.getAddress());
        assertEquals(ADDRESS_LINE_1, reltioCustomer.getAddress().getAddressLine1());
        assertEquals(ADDRESS_LINE_2, reltioCustomer.getAddress().getAddressLine2());
        assertEquals(CITY, reltioCustomer.getAddress().getCity());
        assertEquals(REGION_NAME, reltioCustomer.getAddress().getStateProvince());
        assertEquals(COUNTRY_NAME, reltioCustomer.getAddress().getCountry());
        assertEquals(POSTAL_CODE, reltioCustomer.getAddress().getZip());
    }

    @Test
    void testGetCustomerMapNoMembershipSystemCrosswalks() {
        final Entity entity = buildEntity(
            true,
            PARTY_KEY_VALUE_1,
            buildCrosswalk(RELTIO_CROSSWALK, RELTIO_CROSSWALK_VALUE)
        );

        final Map<String, ReltioCustomer> customerMap = customerMapper.getCustomerMap(entity, true, MEMBERSHIP_SYSTEM_SOURCE);

        assertNotNull(customerMap);
        assertEquals(0, customerMap.size());
    }

    @Test
    void testGetCustomerMapNoAttributes() {
        final Entity entity = buildEntity(
            true,
            PARTY_KEY_VALUE_1,
            buildCrosswalk(MEMBERSHIP_SYSTEM_CROSSWALK, String.valueOf(MEMBERSHIP_ID)),
            buildCrosswalk(RELTIO_CROSSWALK, RELTIO_CROSSWALK_VALUE)
        );

        final Map<String, ReltioCustomer> customerMap = customerMapper.getCustomerMap(entity, true, MEMBERSHIP_SYSTEM_SOURCE);

        assertNotNull(customerMap);
        assertEquals(1, customerMap.size());
        assertEquals(1, customerMap.keySet().size());
        assertEquals(1, customerMap.values().size());

        ReltioCustomer reltioCustomer = customerMap.get(String.valueOf(MEMBERSHIP_ID));
        assertNotNull(reltioCustomer);
        assertNull(reltioCustomer.getFirstName());
        assertNull(reltioCustomer.getLastName());
        assertNull(reltioCustomer.getEmail());
        assertNull(reltioCustomer.getPhoneNumber());
        assertNull(reltioCustomer.getAddress());
    }
}