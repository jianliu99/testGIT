package ca.bestbuy.membership.membershipdatamigration.factory;

import ca.bestbuy.membership.membershipdatamigration.entity.jpa.Membership;
import ca.bestbuy.membership.membershipdatamigration.entity.jpa.PaymentCalculation;
import java.math.BigDecimal;

public class PaymentCalculationFactory {

    public static PaymentCalculation buildPaymentCalculation(BigDecimal totalPayed, Membership membership) {
        PaymentCalculation paymentCalculation = new PaymentCalculation();
        paymentCalculation.setMembership(membership);
        paymentCalculation.setTotalPayed(totalPayed);
        return paymentCalculation;
    }
}
