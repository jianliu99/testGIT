package ca.bestbuy.membership.membershipdatamigration.factory;

import ca.bestbuy.membership.accountdatamigration.entity.AccountPartyKey;
import ca.bestbuy.membership.membershipdatamigration.entity.PartyKey;

public class PartyKeyFactory {

    public static PartyKey buildPartyKey(String partyKey, Integer membershipId) {
        return PartyKey.builder()
                .partyKey(partyKey)
                .membershipId(membershipId)
                .build();
    }

    public static AccountPartyKey buildAccountPartyKey(String partyKey, String accountKey) {
        return AccountPartyKey.builder()
                .partyKey(partyKey)
                .accountKey(accountKey)
                .build();
    }
}