package ca.bestbuy.membership.membershipdatamigration.util;

import static ca.bestbuy.membership.membershipdatamigration.util.MigrationReportConstant.REPORT_STATUS_FAIL;
import static ca.bestbuy.membership.membershipdatamigration.util.MigrationReportConstant.REPORT_STATUS_PASS;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.ATTRIBUTE_A;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.ATTRIBUTE_B;
import static ca.bestbuy.membership.membershipdatamigration.util.TestConstant.ATTRIBUTE_NAME;
import static org.junit.jupiter.api.Assertions.assertEquals;

import ca.bestbuy.membership.membershipdatamigration.entity.report.ValidationResult;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.NullAndEmptySource;

class ReltioSyncReportUtilTest {

    @Test
    void testValidateCustomerAttributesSuccess() {
        final ValidationResult validationResult = ReltioSyncReportUtil.validateCustomerAttributes(
            ATTRIBUTE_NAME,
            ATTRIBUTE_A,
            ATTRIBUTE_A,
            ""
        );

        assertEquals(REPORT_STATUS_PASS, validationResult.getStatus());
        assertEquals("", validationResult.getComment());
    }

    @ParameterizedTest
    @NullAndEmptySource
    void testValidateCustomerAttributesMigrationFail(final String value) {
        final ValidationResult validationResult = ReltioSyncReportUtil.validateCustomerAttributes(
            ATTRIBUTE_NAME,
            ATTRIBUTE_A,
            value,
            ""
        );

        assertEquals(REPORT_STATUS_FAIL, validationResult.getStatus());
        assertEquals("attributeName has not been migrated to reltio. ", validationResult.getComment());
    }

    @ParameterizedTest
    @NullAndEmptySource
    void testValidateCustomerAttributesBackFillFail(final String value) {
        final ValidationResult validationResult = ReltioSyncReportUtil.validateCustomerAttributes(
            ATTRIBUTE_NAME,
            value,
            ATTRIBUTE_A,
            ""
        );

        assertEquals(REPORT_STATUS_FAIL, validationResult.getStatus());
        assertEquals("attributeName has not been backfilled to membership DB. ", validationResult.getComment());
    }

    @Test
    void testValidateCustomerAttributesMismatchFail() {
        final ValidationResult validationResult = ReltioSyncReportUtil.validateCustomerAttributes(
            ATTRIBUTE_NAME,
            ATTRIBUTE_A,
            ATTRIBUTE_B,
            ""
        );

        assertEquals(REPORT_STATUS_FAIL, validationResult.getStatus());
        assertEquals("attributeName do not match: attributeB != attributeA.", validationResult.getComment());
    }
}