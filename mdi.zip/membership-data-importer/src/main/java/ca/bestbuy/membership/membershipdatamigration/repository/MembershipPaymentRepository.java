package ca.bestbuy.membership.membershipdatamigration.repository;

import ca.bestbuy.membership.membershipdatamigration.entity.jpa.MembershipPayment;
import ca.bestbuy.membership.membershipdatamigration.entity.jpa.PaymentCalculation;
import java.sql.Timestamp;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface MembershipPaymentRepository extends JpaRepository<MembershipPayment, Integer> {

    @Query(value = "select new ca.bestbuy.membership.membershipdatamigration.entity.jpa.PaymentCalculation("
            + "sum(case when mp.taxAmount = 0 then (-1*mp.paymentAmount) "
            + "else (-1*round(mp.paymentAmount / (mp.taxRate + 1), 2)) end), mp.membership) "
            + "from MembershipPayment mp "
            + "where mp.membership.membershipId in (select distinct mpd.membership.membershipId "
            + "from MembershipPayment mpd where mpd.updatedDate > :updatedDate) "
            + "and (mp.membershipCancelReason is null or mp.membershipCancelReason.membershipCancelReasonId = ("
            + "select mcr.membershipCancelReasonId from MembershipCancelReason mcr where mcr.membershipCancelReasonCode = 'AF'))"
            + "group by mp.membership, mp.membership.membershipId")
    Page<PaymentCalculation> calculateTotalPayed(@Param("updatedDate") Timestamp updatedDate, Pageable pageable);

    @Query(value = "select case when (count(mp) > 0) then true else false end "
            + "from MembershipPayment mp where mp.updatedDate > :updatedDate and mp.membershipCancelReason is not null and "
            + "mp.membership.membershipId = :membershipId")
    boolean paymentCancelCodeExists(@Param("updatedDate") Timestamp updatedDate, @Param("membershipId") Integer membershipId);
}
