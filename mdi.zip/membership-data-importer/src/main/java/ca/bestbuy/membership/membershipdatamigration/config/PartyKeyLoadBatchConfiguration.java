package ca.bestbuy.membership.membershipdatamigration.config;

import ca.bestbuy.membership.membershipdatamigration.entity.PartyKey;
import ca.bestbuy.membership.membershipdatamigration.entity.reltio.Entity;
import ca.bestbuy.membership.membershipdatamigration.listener.PartyKeyLoadListener;
import ca.bestbuy.membership.membershipdatamigration.repository.MembershipRepository;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.Chunk;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.json.JsonItemReader;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.PlatformTransactionManager;

@Configuration
@EnableBatchProcessing
@Slf4j
@RequiredArgsConstructor
public class PartyKeyLoadBatchConfiguration {

    @Value("${membership.partyKeyLoad.chunkSize}")
    private int chunkSize;

    private final MembershipRepository membershipRepository;

    @Bean
    public ItemWriter<List<PartyKey>> partyKeyWriter() {
        return new ItemWriter<List<PartyKey>>() {
            @Override
            public void write(Chunk<? extends List<PartyKey>> chunk) throws Exception {
                if (chunk.getItems().isEmpty()) {
                    return;
                }

                log.info(" Updating membership table with the batch size of {} Party Keys", chunk.getItems().size());
                membershipRepository.updateBatch((List<List<PartyKey>>) chunk.getItems());
            }
        };
    }

    @Bean
    public Step loadPartyKeyStep(JobRepository jobRepository,
            PlatformTransactionManager transactionManager,
            ItemReader<Entity> reltioEntityReader,
            ItemProcessor<Entity, List<PartyKey>> partyKeyProcessor,
            ItemWriter<List<PartyKey>> partyKeyWriter) {
        return new StepBuilder("loadPartyKeyStep", jobRepository)
            .<Entity, List<PartyKey>>chunk(chunkSize, transactionManager)
            .reader(reltioEntityReader)
            .processor(partyKeyProcessor)
            .writer(partyKeyWriter)
            .build();
    }

    @Bean
    public Job loadPartyKeyJob(JobRepository jobRepository, Step loadPartyKeyStep,
            PartyKeyLoadListener partyKeyLoadListener) {
        return new JobBuilder("loadPartyKeyJob", jobRepository)
            .listener(partyKeyLoadListener)
            .start(loadPartyKeyStep)
            .build();
    }
}
