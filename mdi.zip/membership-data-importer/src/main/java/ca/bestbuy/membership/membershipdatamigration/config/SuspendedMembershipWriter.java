package ca.bestbuy.membership.membershipdatamigration.config;

import ca.bestbuy.membership.membershipdatamigration.entity.jpa.Membership;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.springframework.batch.item.Chunk;
import org.springframework.batch.item.ItemWriter;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Component
@Transactional(propagation = Propagation.REQUIRED)
public class SuspendedMembershipWriter implements ItemWriter<Membership> {

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public void write(Chunk<? extends Membership> memberships) throws Exception {
        for (Membership membership : memberships) {
            entityManager.merge(membership);
        }
        entityManager.flush();
    }
}
