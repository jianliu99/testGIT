package ca.bestbuy.membership.membershipdatamigration.entity.jpa;

public enum MembershipStatusCode {
    A, // Active
    S, // Suspended
    C  // Cancelled
}