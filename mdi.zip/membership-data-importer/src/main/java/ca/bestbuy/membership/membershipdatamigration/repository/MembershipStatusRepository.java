package ca.bestbuy.membership.membershipdatamigration.repository;

import static ca.bestbuy.membership.membershipdatamigration.util.Constant.MEMBERSHIP_STATUS_CODES_CACHE_NAME;

import ca.bestbuy.membership.membershipdatamigration.entity.jpa.MembershipStatus;
import ca.bestbuy.membership.membershipdatamigration.entity.jpa.MembershipStatusCode;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MembershipStatusRepository extends JpaRepository<MembershipStatus, Integer> {

    @Cacheable(MEMBERSHIP_STATUS_CODES_CACHE_NAME)
    MembershipStatus getByMembershipStatusCode(MembershipStatusCode membershipStatusCode);
}
