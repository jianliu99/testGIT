package ca.bestbuy.membership.membershipdatamigration.processor;

import ca.bestbuy.membership.membershipdatamigration.entity.jpa.MemberIdStage;
import ca.bestbuy.membership.membershipdatamigration.entity.jpa.MembershipContract;
import ca.bestbuy.membership.membershipdatamigration.util.MemberIdGenerator;
import java.util.HashSet;
import java.util.Set;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@RequiredArgsConstructor
public class UpdateMemberIdProcessor implements ItemProcessor<MembershipContract, MemberIdStage> {

    private final Set<Integer> memberIdCache = new HashSet<>();

    @Override
    public MemberIdStage process(MembershipContract membershipContract) throws Exception {

        int memberId = MemberIdGenerator.generate();
        while (memberIdCache.contains(memberId)) {
            memberId = MemberIdGenerator.generate();
        }
        memberIdCache.add(memberId);
        log.debug(" Generated member id : " + memberId);
        MemberIdStage memberIdStage = new MemberIdStage();
        memberIdStage.setId(membershipContract.getId());
        memberIdStage.setMemberId(memberId);
        return memberIdStage;
    }

    public void clearMemberIdCache() {
        memberIdCache.clear();
    }

}
