package ca.bestbuy.membership.membershipdatamigration.repository;

import ca.bestbuy.membership.membershipdatamigration.entity.report.jpa.Address;
import ca.bestbuy.membership.membershipdatamigration.entity.report.jpa.Customer;
import javax.sql.DataSource;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.UncategorizedSQLException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class CustomerRepository {

    private final JdbcTemplate jdbcTemplate;

    public CustomerRepository(DataSource dataSource) {
        this.jdbcTemplate = new JdbcTemplate(dataSource);
    }

    public Customer getCustomer(String membershipId) {
        String sql = "SELECT m.membership_id, m.party_key, m.first_name, m.last_name, m.email_address, m.phone_number, "
            + "a.address_line_1, a.address_line_2, a.city, a.suite, a.region_code, a.region_name, a.postal_code, a.country_name "
            + "FROM membership m "
            + "LEFT JOIN address a ON m.membership_id = a.membership_id "
            + "WHERE m.membership_id = ?";

        try {
            return jdbcTemplate.queryForObject(sql, (rs, rowNum) -> {
                Address a = new Address();
                a.setAddressLine1(rs.getString("address_line_1"));
                a.setAddressLine2(rs.getString("address_line_2"));
                a.setSuite(rs.getString("suite"));
                a.setCity(rs.getString("city"));
                a.setRegionName(rs.getString("region_name"));
                a.setCountryName(rs.getString("country_name"));
                a.setPostalCode(rs.getString("postal_code"));

                Customer c = new Customer();
                c.setMembershipId(rs.getString("membership_id"));
                c.setPartyKey(rs.getString("party_key"));
                c.setFirstName(rs.getString("first_name"));
                c.setLastName(rs.getString("last_name"));
                c.setEmailAddress(rs.getString("email_address"));
                c.setPhoneNumber(rs.getString("phone_number"));
                c.setAddress(a);

                return c;
            }, membershipId);
        } catch (EmptyResultDataAccessException | UncategorizedSQLException e) {
            return null;
        }
    }
}
