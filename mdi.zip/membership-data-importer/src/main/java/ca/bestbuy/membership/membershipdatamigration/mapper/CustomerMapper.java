package ca.bestbuy.membership.membershipdatamigration.mapper;

import static ca.bestbuy.membership.membershipdatamigration.util.MigrationReportConstant.EMAIL_PATTERN;
import static ca.bestbuy.membership.membershipdatamigration.util.MigrationReportConstant.ENTITIES;
import static ca.bestbuy.membership.membershipdatamigration.util.MigrationReportConstant.PHONE_PATTERN;
import static ca.bestbuy.membership.membershipdatamigration.util.MigrationReportConstant.ZIP_PATTERN;
import static java.util.stream.Collectors.toMap;
import static java.util.stream.Stream.empty;
import static org.springframework.util.CollectionUtils.isEmpty;

import ca.bestbuy.membership.membershipdatamigration.entity.reltio.Address;
import ca.bestbuy.membership.membershipdatamigration.entity.reltio.AddressValue;
import ca.bestbuy.membership.membershipdatamigration.entity.reltio.Attribute;
import ca.bestbuy.membership.membershipdatamigration.entity.reltio.Crosswalk;
import ca.bestbuy.membership.membershipdatamigration.entity.reltio.Entity;
import ca.bestbuy.membership.membershipdatamigration.entity.report.ReltioCustomer;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.regex.Pattern;
import org.springframework.stereotype.Component;

@Component
public class CustomerMapper {

    public Map<String, ReltioCustomer> getCustomerMap(Entity entity, boolean reportDaily, String sourceSystem) {
        return entity.getCrosswalks().stream()
            .filter(it -> it.getType().equals(sourceSystem))
            .collect(toMap(

                // key
                Crosswalk::getValue,

                // value
                it -> {
                    ReltioCustomer reltioCustomer = new ReltioCustomer();

                    if (isEmpty(it.getAttributes())) {
                        return reltioCustomer;
                    }

                    // set FirstName
                    it.getAttributes().stream()
                        .filter(matchesAttribute("/attributes/FirstName/"))
                        .findFirst()
                        .flatMap(firstNameUri ->
                            entity.getAttributes().getFirstName().stream()
                                .filter(matchesUri(firstNameUri))
                                .findFirst()
                        )
                        .ifPresent(attr -> reltioCustomer.setFirstName(attr.getValue()));

                    // set LastName
                    it.getAttributes().stream()
                        .filter(matchesAttribute("/attributes/LastName/"))
                        .findFirst()
                        .flatMap(lastNameUri ->
                            entity.getAttributes().getLastName().stream()
                                .filter(matchesUri(lastNameUri))
                                .findFirst()
                        )
                        .ifPresent(attr -> reltioCustomer.setLastName(attr.getValue()));

                    // set Email
                    it.getAttributes().stream()
                        .filter(matchesRegex(EMAIL_PATTERN))
                        .findFirst()
                        .flatMap(emailUri ->
                            entity.getAttributes().getEmails().stream()
                                .flatMap(emails ->
                                    emails.getValue().getEmail() != null
                                        ? emails.getValue().getEmail().stream()
                                        : empty()
                                )
                                .filter(matchesUri(emailUri))
                                .findFirst()
                        )
                        .ifPresent(email -> reltioCustomer.setEmail(email.getValue()));

                    // set Phone
                    it.getAttributes().stream()
                        .filter(matchesRegex(PHONE_PATTERN))
                        .findFirst()
                        .flatMap(phoneNumberUri -> entity.getAttributes().getPhoneNumbers().stream()
                            .flatMap(phoneNumbers ->
                                phoneNumbers.getValue().getNumber() != null
                                    ? phoneNumbers.getValue().getNumber().stream()
                                    : empty()
                            )
                            .filter(matchesUri(phoneNumberUri))
                            .findFirst()
                        )
                        .ifPresent(phoneNumber -> reltioCustomer.setPhoneNumber(phoneNumber.getValue()));

                    // set Address
                    if (reportDaily && entity.getAttributes() != null && !isEmpty(entity.getAttributes().getAddresses())) {
                        entity.getAttributes().getAddresses().stream()
                            .filter(address ->
                                address.getStartObjectCrosswalks().stream()
                                    .anyMatch(crosswalk -> crosswalk.getValue().equals(it.getValue()))
                            )
                            .findFirst()
                            .map(address -> mapAddress(address, sourceSystem))
                            .ifPresent(reltioCustomer::setAddress);
                    }

                    return reltioCustomer;
                }));
    }

    private ca.bestbuy.membership.membershipdatamigration.entity.report.Address mapAddress(Address address, String sourceSystem) {
        Optional<Crosswalk> firstCrosswalk = address.getRefEntity().getCrosswalks().stream()
            .filter(it -> it.getType().equals(sourceSystem))
            .findFirst();

        if (firstCrosswalk.isPresent()) {
            Crosswalk crosswalk = firstCrosswalk.get();
            ca.bestbuy.membership.membershipdatamigration.entity.report.Address reltioAddress =
                new ca.bestbuy.membership.membershipdatamigration.entity.report.Address();

            AddressValue addressValue = address.getValue();
            if (crosswalk.getAttributeUris() != null) {
                getAttributeValue(crosswalk, addressValue, "/AddressLine1/", AddressValue::getAddressLine1List, reltioAddress::setAddressLine1);
                getAttributeValue(crosswalk, addressValue, "/AddressLine2/", AddressValue::getAddressLine2List, reltioAddress::setAddressLine2);
                getAttributeValue(crosswalk, addressValue, "/City/", AddressValue::getCityList, reltioAddress::setCity);
                getAttributeValue(crosswalk, addressValue, "/StateProvince/", AddressValue::getStateProvinceList, reltioAddress::setStateProvince);
                getAttributeValue(crosswalk, addressValue, "/Country/", AddressValue::getCountryList, reltioAddress::setCountry);

                crosswalk.getAttributeUris().stream()
                    .filter(matchesRegex(ZIP_PATTERN))
                    .findFirst()
                    .flatMap(zipUri ->
                        address.getValue().getZipList().stream()
                            .flatMap(zipList ->
                                zipList.getValue().getPostalCode() != null
                                    ? zipList.getValue().getPostalCode().stream()
                                    : empty()
                            )
                            .filter(matchesUri(zipUri))
                            .findFirst()
                    )
                    .ifPresent(email -> reltioAddress.setZip(email.getValue()));
            }
            return reltioAddress;
        } else {
            // Handle the case where no object was found
            return null;
        }
    }

    private void getAttributeValue(Crosswalk crosswalk, AddressValue addressValue, String attributeName,
                                   Function<AddressValue, List<Attribute>> attributeListGetter, Consumer<String> attributeValueSetter) {
        crosswalk.getAttributeUris().stream()
            .filter(matchesAttribute(attributeName))
            .findFirst()
            .flatMap(attributeUri ->
                attributeListGetter.apply(addressValue).stream()
                    .filter(matchesUri(attributeUri))
                    .findFirst()
            )
            .ifPresent(attr -> attributeValueSetter.accept(attr.getValue()));
    }

    private static Predicate<String> matchesRegex(Pattern pattern) {
        return attr -> pattern.matcher(attr).matches();
    }

    private static Predicate<String> matchesAttribute(String attributeName) {
        return attr -> attr.startsWith(ENTITIES) && attr.contains(attributeName);
    }

    private static Predicate<Attribute> matchesUri(String uri) {
        return attr -> attr.getUri().equals(uri);
    }
}
