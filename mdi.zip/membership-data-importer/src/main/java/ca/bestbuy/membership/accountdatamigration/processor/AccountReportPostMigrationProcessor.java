package ca.bestbuy.membership.accountdatamigration.processor;

import static ca.bestbuy.membership.accountdatamigration.util.Constant.ACCOUNT_SYSTEM_SOURCE;
import static ca.bestbuy.membership.membershipdatamigration.util.Constant.ENTITY_TYPE_INDIVIDUAL;
import static ca.bestbuy.membership.membershipdatamigration.util.MigrationReportConstant.ADDRESS_LINE_1;
import static ca.bestbuy.membership.membershipdatamigration.util.MigrationReportConstant.ADDRESS_LINE_2;
import static ca.bestbuy.membership.membershipdatamigration.util.MigrationReportConstant.CITY;
import static ca.bestbuy.membership.membershipdatamigration.util.MigrationReportConstant.COUNTRY;
import static ca.bestbuy.membership.membershipdatamigration.util.MigrationReportConstant.EMAIL;
import static ca.bestbuy.membership.membershipdatamigration.util.MigrationReportConstant.FIRST_NAME;
import static ca.bestbuy.membership.membershipdatamigration.util.MigrationReportConstant.LAST_NAME;
import static ca.bestbuy.membership.membershipdatamigration.util.MigrationReportConstant.PARTY_KEY;
import static ca.bestbuy.membership.membershipdatamigration.util.MigrationReportConstant.PHONE;
import static ca.bestbuy.membership.membershipdatamigration.util.MigrationReportConstant.REGION_NAME;
import static ca.bestbuy.membership.membershipdatamigration.util.MigrationReportConstant.REPORT_STATUS_FAIL;
import static ca.bestbuy.membership.membershipdatamigration.util.MigrationReportConstant.REPORT_STATUS_PASS;
import static ca.bestbuy.membership.membershipdatamigration.util.MigrationReportConstant.ZIP;
import static java.lang.Math.random;
import static org.springframework.util.CollectionUtils.isEmpty;

import ca.bestbuy.membership.accountdatamigration.entity.AccountAddress;
import ca.bestbuy.membership.accountdatamigration.entity.AccountCustomer;
import ca.bestbuy.membership.accountdatamigration.entity.AccountMigrationReportItem;
import ca.bestbuy.membership.accountdatamigration.repository.AccountJdbcRepository;
import ca.bestbuy.membership.membershipdatamigration.entity.reltio.Entity;
import ca.bestbuy.membership.membershipdatamigration.entity.report.Address;
import ca.bestbuy.membership.membershipdatamigration.entity.report.ReltioCustomer;
import ca.bestbuy.membership.membershipdatamigration.entity.report.ValidationResult;
import ca.bestbuy.membership.membershipdatamigration.mapper.CustomerMapper;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.BiConsumer;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@RequiredArgsConstructor
public class AccountReportPostMigrationProcessor implements ItemProcessor<Entity, List<AccountMigrationReportItem>> {

    private final AccountJdbcRepository accountJdbcRepository;

    private final CustomerMapper customerMapper;

    @Value("${validation-report.daily:false}")
    private boolean reportDaily;

    @Value("${validation-report.coverage:0.2}")
    private double reportCoverage;

    @Override
    public List<AccountMigrationReportItem> process(Entity entity) throws Exception {
        List<AccountMigrationReportItem> report = new ArrayList<>();

        if (toBeValidated()) {
            if (!ENTITY_TYPE_INDIVIDUAL.equals(entity.getType())) {
                return null;
            }
            String partyKey = entity.getAttributes().getPartyKeys().get(0).getValue();

            // Fetch the corresponding membership record
            Map<String, ReltioCustomer> reltioCustomerAttributeMap = customerMapper.getCustomerMap(entity, reportDaily, ACCOUNT_SYSTEM_SOURCE);
            if (!isEmpty(reltioCustomerAttributeMap)) {
                for (Map.Entry<String, ReltioCustomer> crosswalkEntry : reltioCustomerAttributeMap.entrySet()) {
                    AccountMigrationReportItem reportItem = generateReltioSyncReportItem(
                            accountJdbcRepository.getCustomerById(crosswalkEntry.getKey()),
                        crosswalkEntry.getValue(),
                        partyKey
                    );

                    report.add(reportItem);
                }
            } else {
                AccountMigrationReportItem reportItem = new AccountMigrationReportItem();
                reportItem.setReltioPartyKey(partyKey);
                reportItem.setPartyKeyStatus(REPORT_STATUS_FAIL);
                reportItem.setError("No account db crosswalk or account key found for entity");
                report.add(reportItem);
            }
        }

        return report;
    }

    private AccountMigrationReportItem generateReltioSyncReportItem(AccountCustomer accountCustomer,
            ReltioCustomer reltioCustomer, String reltioPartyKey) {
        AccountMigrationReportItem reportItem = new AccountMigrationReportItem();
        reportItem.setReltioPartyKey(reltioPartyKey);

        if (accountCustomer == null) {
            reportItem.setPartyKeyStatus(REPORT_STATUS_FAIL);
            reportItem.setError("No corresponding customer found in account db for entity");
        } else {
            reportItem.setReltioPartyKey(accountCustomer.getPartyKey());
            reportItem.setAccountKey(accountCustomer.getAccountKey());

            validateAndSetStatus(PARTY_KEY, accountCustomer.getPartyKey(), reltioPartyKey, " ",
                reportItem, AccountMigrationReportItem::setPartyKeyStatus);
            validateAndSetStatus(FIRST_NAME, accountCustomer.getFirstName(), reltioCustomer.getFirstName(), reportItem.getError(),
                reportItem, AccountMigrationReportItem::setFirstNameStatus);
            validateAndSetStatus(LAST_NAME, accountCustomer.getLastName(), reltioCustomer.getLastName(), reportItem.getError(),
                reportItem, AccountMigrationReportItem::setLastNameStatus);
            validateAndSetStatus(EMAIL, accountCustomer.getEmailAddress(), reltioCustomer.getEmail(), reportItem.getError(),
                reportItem, AccountMigrationReportItem::setEmailStatus);
            validateAndSetStatus(PHONE, accountCustomer.getPhoneNumber(), reltioCustomer.getPhoneNumber(), reportItem.getError(),
                reportItem, AccountMigrationReportItem::setPhoneStatus);

            AccountAddress address = accountCustomer.getAddress();
            Address reltioAddress = reltioCustomer.getAddress();
            if (reportDaily && reltioAddress != null) {
                validateAndSetStatus(ADDRESS_LINE_1, address.getAddressLine1(), reltioAddress.getAddressLine1(), reportItem.getError(),
                    reportItem, AccountMigrationReportItem::setAddressStatus);
                validateAndSetStatus(ADDRESS_LINE_2, address.getAddressLine2(), reltioAddress.getAddressLine2(), reportItem.getError(),
                    reportItem, AccountMigrationReportItem::setAddressStatus);
                validateAndSetStatus(CITY, address.getCity(), reltioAddress.getCity(), reportItem.getError(),
                    reportItem, AccountMigrationReportItem::setAddressStatus);
                validateAndSetStatus(REGION_NAME, address.getRegionName(), reltioAddress.getStateProvince(), reportItem.getError(),
                    reportItem, AccountMigrationReportItem::setAddressStatus);
                validateAndSetStatus(COUNTRY, address.getCountryName(), reltioAddress.getCountry(), reportItem.getError(),
                    reportItem, AccountMigrationReportItem::setAddressStatus);
                validateAndSetStatus(ZIP, address.getPostalCode(), reltioAddress.getZip(), reportItem.getError(),
                    reportItem, AccountMigrationReportItem::setAddressStatus);
            }
        }

        return reportItem;
    }

    private void validateAndSetStatus(String attribute, String value1, String value2, String comment,
            AccountMigrationReportItem reportItem, BiConsumer<AccountMigrationReportItem, String> setStatus) {
        ValidationResult validationResult = validateCustomerAttributes(attribute, value1, value2, comment);
        setStatus.accept(reportItem, validationResult.getStatus());
        reportItem.setError(validationResult.getComment());
    }

    private ValidationResult validateCustomerAttributes(String attributeName, String accountDbAttribute,
            String reltioAttribute, String error) {
        String status;
        String individualError = "";

        if (StringUtils.isEmpty(reltioAttribute) && !StringUtils.isEmpty(accountDbAttribute)) {
            status = REPORT_STATUS_FAIL;
            individualError = attributeName + " has not been migrated to reltio. ";
        } else if (reltioAttribute != null && StringUtils.isEmpty(accountDbAttribute)) {
            status = REPORT_STATUS_FAIL;
            individualError = attributeName + " has not been backfilled to account DB. ";
        } else if ((reltioAttribute != null && reltioAttribute.equals(accountDbAttribute))
                || (reltioAttribute == null && accountDbAttribute == null)) {
            status = REPORT_STATUS_PASS;
        } else {
            status = REPORT_STATUS_FAIL;
            individualError = attributeName + " do not match: " + reltioAttribute + " != " + accountDbAttribute + ".";
        }

        error = (error == null ? null : error.concat(individualError));
        return new ValidationResult(status, error);
    }

    /**
     * Random validation on percentage of the data in the reltio export file.
     */
    private boolean toBeValidated() {
        return random() < reportCoverage;
    }
}
