package ca.bestbuy.membership.membershipdatamigration.processor;

import static ca.bestbuy.membership.membershipdatamigration.util.Constant.averageNumberOfDaysInMonth;
import static ca.bestbuy.membership.membershipdatamigration.util.Constant.averageNumberOfDaysInYear;
import static ca.bestbuy.membership.membershipdatamigration.util.TimeUtil.getTimestamp;

import ca.bestbuy.membership.membershipdatamigration.entity.jpa.Membership;
import ca.bestbuy.membership.membershipdatamigration.entity.jpa.MembershipPaymentFrequencyCode;
import ca.bestbuy.membership.membershipdatamigration.entity.jpa.MembershipStatusCode;
import ca.bestbuy.membership.membershipdatamigration.entity.jpa.PaymentCalculation;
import ca.bestbuy.membership.membershipdatamigration.repository.MembershipPaymentRepository;
import ca.bestbuy.membership.membershipdatamigration.repository.MembershipStatusRepository;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Date;
import java.time.LocalDate;
import java.time.ZoneId;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
@Slf4j
@StepScope
@Setter
public class PaymentProcessor implements ItemProcessor<PaymentCalculation, Membership> {

    @Value("#{jobParameters['incrementalLoadStartDate']}")
    private String incrementalLoadStartDate;

    @Value("${membership.gracePeriod}")
    private int gracePeriod;

    private static final int ONE = 1;

    private final MembershipPaymentRepository membershipPaymentRepository;

    private final MembershipStatusRepository membershipStatusRepository;

    @Override
    public Membership process(PaymentCalculation paymentCalculation) {

        Membership membership = paymentCalculation.getMembership();
        log.info("Found payments for membershipId {}, paidUpToDate  {}, totalRecurringAmountPaid {}", membership.getMembershipId(),
                membership.getPaidUpToDate(), membership.getTotalRecurringAmountPaid());

        membership.setTotalRecurringAmountPaid(paymentCalculation.getTotalPayed());

        BigDecimal periodLength = membership.getTotalRecurringAmountPaid()
                .divide(membership.getMembershipSku().getRecurringPaymentAmount(), 2, RoundingMode.HALF_DOWN)
                .add(BigDecimal.ONE);

        if (membership.getMembershipSku().getMembershipPaymentFrequency().getMembershipPaymentFrequencyCode()
                == MembershipPaymentFrequencyCode.A) {
            periodLength = periodLength.multiply(averageNumberOfDaysInYear);
        } else if (membership.getMembershipSku().getMembershipPaymentFrequency().getMembershipPaymentFrequencyCode()
                == MembershipPaymentFrequencyCode.M) {
            periodLength = periodLength.multiply(averageNumberOfDaysInMonth);
        }

        LocalDate paidUpToDate = membership.getMembershipStartDate().toLocalDate()
                .plusDays(periodLength.setScale(0, RoundingMode.HALF_UP).longValue());

        membership.setPaidUpToDate(Date.valueOf(paidUpToDate));
        // Grace period is considered before setting membership to Active status
        LocalDate todayDate = LocalDate.now(ZoneId.systemDefault());
        if (paidUpToDate.plusWeeks(gracePeriod).plusDays(ONE).isAfter(todayDate) && Boolean.TRUE
                .equals(!membershipPaymentRepository.paymentCancelCodeExists(
                        getTimestamp(incrementalLoadStartDate), membership.getMembershipId()))) {
            membership.setMembershipStatus(membershipStatusRepository.getByMembershipStatusCode(MembershipStatusCode.A));

            log.info("Updating the status code to {} for membershipId {}",
                    membership.getMembershipStatus().getMembershipStatusCode(), membership.getMembershipId());
        }

        return membership;
    }
}
