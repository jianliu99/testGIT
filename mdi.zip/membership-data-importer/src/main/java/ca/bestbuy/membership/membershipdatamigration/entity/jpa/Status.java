package ca.bestbuy.membership.membershipdatamigration.entity.jpa;

public enum Status {
    ACTIVE,
    SUSPENDED,
    CANCELLED
}
