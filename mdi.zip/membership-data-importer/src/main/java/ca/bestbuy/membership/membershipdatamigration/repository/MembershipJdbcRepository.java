package ca.bestbuy.membership.membershipdatamigration.repository;

import ca.bestbuy.membership.membershipdatamigration.entity.PartyKey;
import java.util.List;

public interface MembershipJdbcRepository {

    void updateBatch(List<List<PartyKey>> partyKeys);
}
