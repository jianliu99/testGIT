package ca.bestbuy.membership.membershipdatamigration.mapper;

import ca.bestbuy.membership.membershipdatamigration.entity.jpa.MemberIdStage;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

public class MemberIdStageMapper implements RowMapper<MemberIdStage> {

    @Override
    public MemberIdStage mapRow(ResultSet rs, int rowNum) throws SQLException {
        MemberIdStage memberIdStage = MemberIdStage.builder().build();
        memberIdStage.setId(rs.getInt("ID"));
        memberIdStage.setMemberId(rs.getInt("MEMBER_ID"));
        return memberIdStage;
    }

}
