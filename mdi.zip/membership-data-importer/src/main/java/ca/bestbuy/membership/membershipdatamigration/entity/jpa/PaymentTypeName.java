package ca.bestbuy.membership.membershipdatamigration.entity.jpa;

public enum PaymentTypeName {
    DIRECT_PAYMENT,
    CHEQUE_REFUND,
    DIRECT_REFUND
}