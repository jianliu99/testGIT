package ca.bestbuy.membership.accountdatamigration.service;

import static ca.bestbuy.membership.accountdatamigration.util.Constant.DEFAULT_COMPRESSED_REPORT_NAME;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.stream.Stream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class FileProcessingService {

    @Value("${account.report.single-report-only: false}")
    private boolean isSingleReportOnly;

    public Resource downloadFile(String inputFilePath) throws MalformedURLException {
        String fileToDownload = inputFilePath + DEFAULT_COMPRESSED_REPORT_NAME
                + (isSingleReportOnly ? ".csv" : ".zip");
        File file = new File(fileToDownload);
        if (file.exists()) {
            return new UrlResource(file.toURI());
        }
        return null;
    }

    public void compress(String inputFilePath) throws IOException {
        int depth = isSingleReportOnly ? 1 : Integer.MAX_VALUE;
        try (Stream<Path> walkStream = Files.walk(Path.of(inputFilePath), depth)) {
            List<File> reportCsvFiles = walkStream.filter(Files::isRegularFile)
                    .filter(p ->
                            isSingleReportOnly ? (DEFAULT_COMPRESSED_REPORT_NAME + ".csv").equals(p.getFileName().toString()) :
                            p.getFileName().toString().endsWith(".csv"))
                    .map(Path::toFile).toList();
            final FileOutputStream fos = new FileOutputStream(inputFilePath + DEFAULT_COMPRESSED_REPORT_NAME + ".zip");
            try (ZipOutputStream zipOut = new ZipOutputStream(fos)) {
                for (File file : reportCsvFiles) {
                    try (FileInputStream fis = new FileInputStream(file)) {
                        ZipEntry zipEntry = new ZipEntry(file.getParentFile().getName() + "_" + file.getName());
                        zipOut.putNextEntry(zipEntry);

                        byte[] bytes = new byte[1024];
                        int length;
                        while ((length = fis.read(bytes)) >= 0) {
                            zipOut.write(bytes, 0, length);
                        }
                    }
                }
            }
            fos.close();
        }
    }
}
