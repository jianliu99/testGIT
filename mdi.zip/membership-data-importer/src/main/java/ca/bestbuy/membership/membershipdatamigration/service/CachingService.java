package ca.bestbuy.membership.membershipdatamigration.service;

import static ca.bestbuy.membership.membershipdatamigration.util.Constant.MEMBERSHIP_STATUS_CODES_CACHE_NAME;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class CachingService {

    private final CacheManager cacheManager;

    public void evictAllCaches() {

        Cache membershipStatusCodesCache = cacheManager.getCache(MEMBERSHIP_STATUS_CODES_CACHE_NAME);
        if (membershipStatusCodesCache != null) {
            membershipStatusCodesCache.clear();
            log.info("Membership status codes cache was cleared.");
        }

    }
}
