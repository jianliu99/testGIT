package ca.bestbuy.membership.accountdatamigration.config;

import static ca.bestbuy.membership.accountdatamigration.util.Constant.DEFAULT_COMPRESSED_REPORT_NAME;

import ca.bestbuy.membership.accountdatamigration.entity.AccountMigrationReportItem;
import ca.bestbuy.membership.membershipdatamigration.entity.reltio.Entity;
import java.nio.file.Path;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.Chunk;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.batch.item.file.builder.FlatFileItemWriterBuilder;
import org.springframework.batch.item.file.transform.BeanWrapperFieldExtractor;
import org.springframework.batch.item.file.transform.DelimitedLineAggregator;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;
import org.springframework.transaction.PlatformTransactionManager;

@Slf4j
@Configuration
@EnableBatchProcessing
public class AccountReportPostMigrationConfiguration {

    private static final String[] MIGRATION_REPORT_ITEM_COLUMNS = {
        "reltioPartyKey",
        "accountKey",
        "firstNameStatus",
        "lastNameStatus",
        "emailStatus",
        "phoneStatus",
        "addressStatus",
        "error"
    };

    @Value("${account.partyKeyLoad.chunkSize:500}")
    private int chunkSize;
    @Value("${account.report.base-path:/app/membership-data-importer/}")
    private String reportBasePath;
    @Value("${account.report.single-report-only: false}")
    private boolean isSingleReportOnly;

    @Bean
    @StepScope
    public ItemWriter<List<AccountMigrationReportItem>> accountReportPostMigrationWriter(
            @Value("#{jobParameters['fileExportName']}") String fileExportName) {
        return items -> {
            BeanWrapperFieldExtractor<AccountMigrationReportItem> fieldExtractor = new BeanWrapperFieldExtractor<>();
            fieldExtractor.setNames(MIGRATION_REPORT_ITEM_COLUMNS);

            DelimitedLineAggregator<AccountMigrationReportItem> lineAggregator = new DelimitedLineAggregator<>();
            lineAggregator.setFieldExtractor(fieldExtractor);
            lineAggregator.setDelimiter(",");

            String reportName = isSingleReportOnly
                    ? reportBasePath + DEFAULT_COMPRESSED_REPORT_NAME + ".csv" : reportBasePath + fileExportName + ".csv";
            FlatFileItemWriter<AccountMigrationReportItem> writer = new FlatFileItemWriterBuilder<AccountMigrationReportItem>()
                .name("reportItemWriter")
                .resource(new FileSystemResource(Path.of(reportName)))
                .append(true)
                .lineAggregator(lineAggregator)
                .headerCallback(callback -> callback.write(String.join(",", MIGRATION_REPORT_ITEM_COLUMNS)))
                .build();
            writer.open(new ExecutionContext());

            for (List<AccountMigrationReportItem> item : items) {
                writer.write(new Chunk<>(item));
            }

            writer.close();
        };
    }

    @Bean
    public Step accountReportPostMigrationStep(JobRepository jobRepository,
                                                PlatformTransactionManager transactionManager,
                                                ItemReader<Entity> reportPostCustomerMigrationReader,
                                                ItemProcessor<Entity, List<AccountMigrationReportItem>> accountReportPostMigrationProcessor,
                                                ItemWriter<List<AccountMigrationReportItem>> accountReportPostMigrationWriter) {
        return new StepBuilder("accountReportPostMigrationStep", jobRepository)
            .<Entity, List<AccountMigrationReportItem>>chunk(chunkSize, transactionManager)
            .reader(reportPostCustomerMigrationReader)
            .processor(accountReportPostMigrationProcessor)
            .writer(accountReportPostMigrationWriter)
            .build();
    }

    @Bean
    public Job accountReportPostMigrationJob(JobRepository jobRepository, Step accountReportPostMigrationStep) {
        return new JobBuilder("accountReportPostMigrationJob", jobRepository)
            .incrementer(new RunIdIncrementer())
            .flow(accountReportPostMigrationStep)
            .end()
            .build();
    }
}
