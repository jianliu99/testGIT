package ca.bestbuy.membership.membershipdatamigration.mapper;

import ca.bestbuy.membership.membershipdatamigration.entity.jpa.MembershipContract;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

public class CsparcContractMapper implements RowMapper<MembershipContract> {

    @Override
    public MembershipContract mapRow(ResultSet resultSet, int rowNum) throws SQLException {
        MembershipContract membershipContract = MembershipContract.builder().build();
        membershipContract.setId(resultSet.getInt("ID"));
        return membershipContract;
    }
}
