package ca.bestbuy.membership.membershipdatamigration.repository;

import ca.bestbuy.membership.membershipdatamigration.entity.jpa.Membership;
import java.sql.Timestamp;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

public interface MembershipRepository extends JpaRepository<Membership, Integer>, MembershipJdbcRepository {

    @Transactional(propagation = Propagation.NOT_SUPPORTED)
    @Query(value = "select m.*, msku.created_by as msku_created_by, mpf.created_by as mpf_mpf, ms.created_by as ms_created_by  from membership m "
            + "inner join membership_sku msku on m.membership_sku_id = msku.membership_sku_id "
            + "inner join membership_payment_frequency mpf on msku.membership_payment_frequency_id = mpf.membership_payment_frequency_id "
            + "inner join membership_status ms on m.membership_status_id = ms.membership_status_id "
            + "where (dateadd(week, :gracePeriod, m.paid_up_to_date) < :todayDate and mpf.membership_payment_frequency_code != 'LS' "
            + "and (ms.membership_status_code != 'S' and ms.membership_status_code != 'C')) "
            + "or (mpf.membership_payment_frequency_code = 'LS' and m.membership_end_date < :todayDate and ms.membership_status_code != 'C')",
            nativeQuery = true)
    Page<Membership> getSuspendedAndCanceledLumpSumsMemberships(@Param("todayDate") Timestamp todayDate, @Param("gracePeriod") int gracePeriod,
            Pageable pageable);

}
