package ca.bestbuy.membership.membershipdatamigration.entity.jpa;

import static ca.bestbuy.membership.membershipdatamigration.util.Constant.APPLICATION_NAME;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.FetchType;
import jakarta.persistence.ForeignKey;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import java.sql.Timestamp;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Data
@Entity(name = "MembershipSku")
@Table(name = "membership_sku")
@EntityListeners(AuditingEntityListener.class)
@NoArgsConstructor
@AllArgsConstructor
public class MembershipSku {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(
            name = "membership_sku_id",
            updatable = false,
            insertable = false,
            unique = true,
            columnDefinition = "INT"
    )
    private Integer membershipSkuId;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(
            name = "membership_payment_frequency_id",
            referencedColumnName = "membership_payment_frequency_id",
            nullable = false,
            foreignKey = @ForeignKey(
                    name = "FK_membership_payment_frequency_id"
            )
    )
    private MembershipPaymentFrequency membershipPaymentFrequency;

    @OneToOne
    @JoinColumn(
        name = "membership_tier_id",
        referencedColumnName = "membership_tier_id",
        nullable = false,
        foreignKey = @ForeignKey(
            name = "FK_membership_tier_id"
        )
    )
    private MembershipTier membershipTier;

    @Column(
            name = "membership_sku",
            unique = true,
            nullable = false,
            columnDefinition = "VARCHAR(8)"
    )
    private String membershipSku;

    @Column(
            name = "contract_asset_period",
            nullable = false,
            columnDefinition = "TINYINT"
    )
    private Integer contractAssetPeriod;

    @Column(
            name = "recurring_payment_amount",
            nullable = false,
            columnDefinition = "DECIMAL(10, 2)"
    )
    private BigDecimal recurringPaymentAmount;

    @Column(
            name = "initial_payment_amount",
            nullable = false,
            columnDefinition = "DECIMAL(10, 2)"
    )
    private BigDecimal initialPaymentAmount;

    @Column(
            name = "created_by",
            updatable = false,
            nullable = false
    )
    @CreatedBy
    private String createdBy;

    @Column(
            name = "created_date",
            nullable = false,
            updatable = false,
            columnDefinition = "DATETIME"
    )
    @CreatedDate
    private Timestamp createdDate;

    @Column(
            name = "updated_by",
            nullable = false
    )
    @LastModifiedBy
    private String updatedBy;

    @Column(
            name = "updated_date",
            nullable = false,
            columnDefinition = "DATETIME"
    )
    @LastModifiedDate
    private Timestamp updatedDate;

    @PreUpdate
    public void onPreUpdate() {
        this.updatedBy = APPLICATION_NAME;
    }
}
