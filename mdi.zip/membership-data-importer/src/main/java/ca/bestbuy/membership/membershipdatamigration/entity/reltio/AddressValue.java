package ca.bestbuy.membership.membershipdatamigration.entity.reltio;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class AddressValue {
    @JsonProperty("AddressLine1")
    private List<Attribute> addressLine1List;

    @JsonProperty("AddressLine2")
    private List<Attribute> addressLine2List;

    @JsonProperty("City")
    private List<Attribute> cityList;

    @JsonProperty("StateProvince")
    private List<Attribute> stateProvinceList;

    @JsonProperty("Country")
    private List<Attribute> countryList;

    @JsonProperty("Zip")
    private List<Zip> zipList;

    @JsonProperty("LegacyValue")
    private List<Legacy> legacyList;

}