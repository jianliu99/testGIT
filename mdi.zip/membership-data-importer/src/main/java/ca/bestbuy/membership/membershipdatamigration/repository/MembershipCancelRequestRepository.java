package ca.bestbuy.membership.membershipdatamigration.repository;

import ca.bestbuy.membership.membershipdatamigration.entity.jpa.MembershipCancelRequest;
import java.sql.Timestamp;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MembershipCancelRequestRepository extends JpaRepository<MembershipCancelRequest, Integer> {

    Page<MembershipCancelRequest> findByUpdatedDateAfter(Timestamp createdDate, Pageable pageable);
}
