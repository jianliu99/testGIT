package ca.bestbuy.membership.membershipdatamigration.controller;

import static org.springframework.http.HttpHeaders.CONTENT_DISPOSITION;
import static org.springframework.http.MediaType.parseMediaType;

import ca.bestbuy.membership.membershipdatamigration.entity.request.PartyKeyProcessRequest;
import ca.bestbuy.membership.membershipdatamigration.service.ReportPostCustomerMigrationService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequiredArgsConstructor
public class ReportPostCustomerMigrationController {

    private final ReportPostCustomerMigrationService reportPostCustomerMigrationService;

    @Value("file:/app/membership-data-importer/output.csv")
    private Resource outputResource;

    @PostMapping("/post-customer-migration/report-data-sync")
    public ResponseEntity<String> reportOnPartyKeyMapping(@Valid @RequestBody PartyKeyProcessRequest request)
        throws JobInstanceAlreadyCompleteException, JobExecutionAlreadyRunningException, JobParametersInvalidException, JobRestartException {
        log.info("Starting report on data sync");
        reportPostCustomerMigrationService.reportOnMigration(request.getFileExportName());
        return ResponseEntity.ok("Data sync reporting batch process started successfully.");
    }

    @GetMapping("/download-output-file")
    public ResponseEntity<Resource> downloadOutputFile() {
        if (outputResource == null || !outputResource.exists()) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok()
            .contentType(parseMediaType("application/csv"))
            .header(CONTENT_DISPOSITION, "attachment; filename=\"" + outputResource.getFilename() + "\"")
            .body(outputResource);
    }
}