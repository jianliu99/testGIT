package ca.bestbuy.membership.membershipdatamigration.util;

import java.util.concurrent.ThreadLocalRandom;
import lombok.experimental.UtilityClass;

/**
 * Custom generator for the Member ID.
 */
@UtilityClass
public class MemberIdGenerator {

    public static final int LOWER_BOUND_MEMBER_ID = 100000000;
    public static final int UPPER_BOUND_MEMBER_ID = 1000000000;

    public static int generate() {
        return ThreadLocalRandom.current().nextInt(LOWER_BOUND_MEMBER_ID, UPPER_BOUND_MEMBER_ID);
    }
}