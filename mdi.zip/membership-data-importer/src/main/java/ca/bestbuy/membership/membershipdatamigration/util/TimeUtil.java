package ca.bestbuy.membership.membershipdatamigration.util;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

@Slf4j
@UtilityClass
public class TimeUtil {

    public static Timestamp getTimestamp(String dateToBeConverted) {

        // Today
        Timestamp timestamp = Timestamp.from(LocalDateTime.now().toLocalDate().atStartOfDay()
                .atZone(ZoneId.systemDefault()).toInstant());

        if (!StringUtils.isEmpty(dateToBeConverted)) {
            timestamp = Timestamp.from(LocalDate.parse(dateToBeConverted).atStartOfDay()
                    .atZone(ZoneId.systemDefault()).toInstant());
        }

        log.debug("Timestamp: {}", timestamp);
        return timestamp;
    }
}
