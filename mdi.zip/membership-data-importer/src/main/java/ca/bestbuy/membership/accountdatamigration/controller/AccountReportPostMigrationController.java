package ca.bestbuy.membership.accountdatamigration.controller;

import static org.apache.commons.lang3.StringUtils.EMPTY;
import static org.apache.commons.lang3.StringUtils.isBlank;
import static org.springframework.http.HttpHeaders.CONTENT_DISPOSITION;

import ca.bestbuy.membership.accountdatamigration.service.AccountReportPostMigrationService;
import ca.bestbuy.membership.accountdatamigration.service.FileProcessingService;
import ca.bestbuy.membership.membershipdatamigration.entity.request.PartyKeyProcessRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequiredArgsConstructor
public class AccountReportPostMigrationController {

    private final AccountReportPostMigrationService accountReportPostMigrationService;

    private final FileProcessingService fileProcessingService;

    @Value("${account.report.base-path:/app/membership-data-importer/}")
    private String reportBasePath;

    @Value("${account.report.single-report-only: false}")
    private boolean isSingleReportOnly;

    @PostMapping("/account-post-migration/report-data-sync")
    public ResponseEntity<String> accountPostMigration(@Valid @RequestBody PartyKeyProcessRequest request)
        throws JobInstanceAlreadyCompleteException, JobExecutionAlreadyRunningException, JobParametersInvalidException, JobRestartException {
        log.info("Starting report on data sync");
        accountReportPostMigrationService.reportOnMigration(request.getFileExportName());
        return ResponseEntity.ok("Data sync reporting batch process started successfully.");
    }

    @PostMapping(value = "/account-post-migration/download", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
    public ResponseEntity<Resource> downloadOutputFile(@Valid @RequestBody PartyKeyProcessRequest request) {

        Resource downloadFile = null;
        try {
            String reportPath = isSingleReportOnly ? EMPTY : request.getFileExportName();
            downloadFile = fileProcessingService.downloadFile(reportBasePath + reportPath);
        } catch (Exception e) {
            log.error("Failed to download account post migration report.", e);
        }

        if (downloadFile == null || !downloadFile.exists()) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok()
            .contentType(MediaType.APPLICATION_OCTET_STREAM)
            .header(CONTENT_DISPOSITION, "attachment; filename=\"" + downloadFile.getFilename() + "\"")
            .body(downloadFile);
    }
}