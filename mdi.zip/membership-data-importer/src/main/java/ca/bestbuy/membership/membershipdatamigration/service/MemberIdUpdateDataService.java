package ca.bestbuy.membership.membershipdatamigration.service;

import java.sql.Timestamp;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class MemberIdUpdateDataService {

    private final JobLauncher jobLauncher;
    private final Job addMemberIdToContractJob;

    @Async
    public void enrichContractData() throws JobParametersInvalidException, JobExecutionAlreadyRunningException,
            JobRestartException, JobInstanceAlreadyCompleteException {
        JobParameters jobParameters = new JobParametersBuilder()
                .addLong("time", System.currentTimeMillis())
                .toJobParameters();

        Timestamp jobStartTime = new Timestamp(System.currentTimeMillis());
        log.info("******  AddMemberIdToContractTable job started at {}", jobStartTime);

        JobExecution jobExecution = jobLauncher.run(addMemberIdToContractJob, jobParameters);
        BatchStatus batchStatus = jobExecution.getStatus();

        if (batchStatus == BatchStatus.COMPLETED) {
            Timestamp jobEndTime = new Timestamp(System.currentTimeMillis());
            log.info("******  AddMemberIdToContractTable job completed at {}", jobEndTime);
            log.info("AddMemberIdToContractTable job completed successfully");
            log.info("Member id is added to each entries in the contract table");
        } else {
            log.error("AddMemberIdToContractTable job did not complete");
            // TODO: error handling
        }
    }

}
