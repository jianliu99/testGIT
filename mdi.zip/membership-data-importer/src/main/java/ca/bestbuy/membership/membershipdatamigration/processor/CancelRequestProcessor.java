package ca.bestbuy.membership.membershipdatamigration.processor;

import ca.bestbuy.membership.membershipdatamigration.entity.jpa.Membership;
import ca.bestbuy.membership.membershipdatamigration.entity.jpa.MembershipCancelRequest;
import ca.bestbuy.membership.membershipdatamigration.entity.jpa.MembershipStatus;
import ca.bestbuy.membership.membershipdatamigration.entity.jpa.MembershipStatusCode;
import ca.bestbuy.membership.membershipdatamigration.repository.MembershipStatusRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
@Slf4j
public class CancelRequestProcessor implements ItemProcessor<MembershipCancelRequest, Membership> {

    private final MembershipStatusRepository membershipStatusRepository;

    @Override
    public Membership process(MembershipCancelRequest membershipCancelRequest) {

        Membership canceledMembership = membershipCancelRequest.getMembership();
        log.info("Found cancel request for membershipId {}", canceledMembership.getMembershipId());

        if (canceledMembership.getMembershipStatus().getMembershipStatusCode() != MembershipStatusCode.C) {
            MembershipStatus canceledMembershipStatus = membershipStatusRepository
                    .getByMembershipStatusCode(MembershipStatusCode.C);
            canceledMembership.setMembershipStatus(canceledMembershipStatus);

            log.info("Updating the status code to {} for membershipId {}",
                    canceledMembership.getMembershipStatus().getMembershipStatusCode(),
                    canceledMembership.getMembershipId());
        }

        return canceledMembership;
    }
}
