package ca.bestbuy.membership.membershipdatamigration.processor;

import static ca.bestbuy.membership.membershipdatamigration.util.Constant.ENTITY_TYPE_INDIVIDUAL;
import static ca.bestbuy.membership.membershipdatamigration.util.Constant.MEMBERSHIP_SYSTEM_SOURCE;

import ca.bestbuy.membership.membershipdatamigration.entity.PartyKey;
import ca.bestbuy.membership.membershipdatamigration.entity.reltio.Entity;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
@Slf4j
public class PartyKeyProcessor implements ItemProcessor<Entity, List<PartyKey>> {

    @Override
    public List<PartyKey> process(Entity entity) throws Exception {
        if (!ENTITY_TYPE_INDIVIDUAL.equals(entity.getType())) {
            return null;
        }

        Optional<ca.bestbuy.membership.membershipdatamigration.entity.reltio.PartyKey> reltioPartyKey = entity.getAttributes().getPartyKeys().stream()
            .filter(ca.bestbuy.membership.membershipdatamigration.entity.reltio.PartyKey::isOv)
            .findFirst();

        if (reltioPartyKey.isEmpty()) {
            return null;
        }

        String partyKeyValue = reltioPartyKey.get().getValue();

        List<PartyKey> partyKeys = entity.getCrosswalks().stream()
            .filter(crosswalk -> MEMBERSHIP_SYSTEM_SOURCE.equals(crosswalk.getType()))
            .map(crosswalk -> {
                try {
                    PartyKey partyKey = new PartyKey();
                    partyKey.setPartyKey(partyKeyValue);
                    partyKey.setMembershipId(Integer.valueOf(crosswalk.getValue()));
                    return partyKey;
                } catch (NumberFormatException e) {
                    return null;
                }
            })
            .filter(Objects::nonNull)
            .collect(Collectors.toList());

        return partyKeys.isEmpty() ? null : partyKeys;
    }
}
