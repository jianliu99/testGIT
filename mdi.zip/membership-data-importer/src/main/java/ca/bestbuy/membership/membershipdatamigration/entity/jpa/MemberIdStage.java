package ca.bestbuy.membership.membershipdatamigration.entity.jpa;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MemberIdStage {

    private Integer id;

    private Integer memberId;

}
