package ca.bestbuy.membership.membershipdatamigration.service;

import static org.springframework.batch.core.BatchStatus.COMPLETED;

import java.sql.Timestamp;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class ReportPostCustomerMigrationService {

    private final JobLauncher jobLauncher;

    private final Job reportPostCustomerMigrationJob;

    private final SlackNotificationService slackNotificationService;

    @Async
    public void reportOnMigration(String exportFileName) throws JobParametersInvalidException, JobExecutionAlreadyRunningException,
        JobRestartException, JobInstanceAlreadyCompleteException {
        JobParameters jobParameters = new JobParametersBuilder()
            .addLong("time", System.currentTimeMillis())
            .addString("fileExportName", exportFileName)
            .toJobParameters();

        Timestamp jobStartTime = new Timestamp(System.currentTimeMillis());
        log.info("******  ReportPostCustomerMigration job started at {}", jobStartTime);

        JobExecution jobExecution = jobLauncher.run(reportPostCustomerMigrationJob, jobParameters);
        BatchStatus batchStatus = jobExecution.getStatus();

        if (batchStatus == COMPLETED) {
            Timestamp jobEndTime = new Timestamp(System.currentTimeMillis());
            log.info("******  ReportPostCustomerMigration job completed at {}", jobEndTime);
            log.info("ReportPostCustomerMigration job completed successfully");
            slackNotificationService.notifySlackChannel();
        } else {
            log.error("ReportPostCustomerMigration job did not complete");
        }
    }
}
