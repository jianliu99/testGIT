package ca.bestbuy.membership.membershipdatamigration.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;

@Slf4j
@Service
@RequiredArgsConstructor
public class SlackNotificationService {

    private final WebClient webClient;

    @Value("${validation-report.slack.webhookUrl}")
    private String slackWebhookUrl;

    @Value("${validation-report.slack.csvFileHostFullUrl}")
    private String csvFileHostFullUrl;

    public void notifySlackChannel() {
        String jsonPayload = String.format("{\"text\":\"Please click the url to download the report: %s\"}", csvFileHostFullUrl);
        webClient.post()
            .uri(slackWebhookUrl)
            .header("Content-Type", "application/json")
            .body(BodyInserters.fromValue(jsonPayload))
            .retrieve()
            .bodyToMono(String.class)
            .block();
        log.info("Report URL has been sent to Slack");
    }
}
