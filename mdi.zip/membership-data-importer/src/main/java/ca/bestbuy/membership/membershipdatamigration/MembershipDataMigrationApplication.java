package ca.bestbuy.membership.membershipdatamigration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

@EnableJpaAuditing
@SpringBootApplication(scanBasePackages = {"ca.bestbuy.membership.membershipdatamigration", "ca.bestbuy.membership.accountdatamigration"})
public class MembershipDataMigrationApplication {

    public static void main(String[] args) {
        SpringApplication.run(MembershipDataMigrationApplication.class, args);
    }

}
