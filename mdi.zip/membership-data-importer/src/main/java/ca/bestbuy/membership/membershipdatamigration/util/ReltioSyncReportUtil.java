package ca.bestbuy.membership.membershipdatamigration.util;

import static ca.bestbuy.membership.membershipdatamigration.util.MigrationReportConstant.REPORT_STATUS_FAIL;
import static ca.bestbuy.membership.membershipdatamigration.util.MigrationReportConstant.REPORT_STATUS_PASS;
import static org.apache.commons.lang3.StringUtils.isEmpty;

import ca.bestbuy.membership.membershipdatamigration.entity.report.ValidationResult;
import lombok.experimental.UtilityClass;

@UtilityClass
public class ReltioSyncReportUtil {

    public static ValidationResult validateCustomerAttributes(String attributeName, String membershipDbAttribute,
                                                              String reltioAttribute, String error) {
        String status;
        String individualError = "";

        if (isEmpty(reltioAttribute) && !isEmpty(membershipDbAttribute)) {
            status = REPORT_STATUS_FAIL;
            individualError = attributeName + " has not been migrated to reltio. ";
        } else if (reltioAttribute != null && isEmpty(membershipDbAttribute)) {
            status = REPORT_STATUS_FAIL;
            individualError = attributeName + " has not been backfilled to membership DB. ";
        } else if (reltioAttribute != null && reltioAttribute.equals(membershipDbAttribute)) {
            status = REPORT_STATUS_PASS;
        } else {
            status = REPORT_STATUS_FAIL;
            individualError = attributeName + " do not match: " + reltioAttribute + " != " + membershipDbAttribute + ".";
        }

        error = (error == null ? null : error.concat(individualError));
        return new ValidationResult(status, error);
    }
}
