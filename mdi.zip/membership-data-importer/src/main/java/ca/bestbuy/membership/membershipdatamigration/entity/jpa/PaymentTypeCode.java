package ca.bestbuy.membership.membershipdatamigration.entity.jpa;

public enum PaymentTypeCode {
    DP, // Direct Payment
    CR, // Cheque Refund
    DR, // Direct Refund
}