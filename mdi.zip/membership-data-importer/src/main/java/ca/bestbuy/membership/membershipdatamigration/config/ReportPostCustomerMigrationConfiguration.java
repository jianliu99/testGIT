package ca.bestbuy.membership.membershipdatamigration.config;

import ca.bestbuy.membership.membershipdatamigration.entity.reltio.Entity;
import ca.bestbuy.membership.membershipdatamigration.entity.report.MigrationReportItem;
import java.nio.file.Path;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.Chunk;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.batch.item.file.builder.FlatFileItemWriterBuilder;
import org.springframework.batch.item.file.transform.BeanWrapperFieldExtractor;
import org.springframework.batch.item.file.transform.DelimitedLineAggregator;
import org.springframework.batch.item.json.JsonItemReader;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;
import org.springframework.transaction.PlatformTransactionManager;

@Slf4j
@Configuration
@EnableBatchProcessing
public class ReportPostCustomerMigrationConfiguration {

    private static final String[] MIGRATION_REPORT_ITEM_COLUMNS = {
        "reltioPartyKey",
        "membershipPartyKey",
        "membershipId",
        "partyKeyStatus",
        "firstNameStatus",
        "lastNameStatus",
        "phoneStatus",
        "emailStatus",
        "addressStatus",
        "error"
    };

    @Value("${membership.partyKeyLoad.chunkSize}")
    private int chunkSize;

    @Bean
    public ItemWriter<List<MigrationReportItem>> reportPostCustomerMigrationWriter() {
        return items -> {
            BeanWrapperFieldExtractor<MigrationReportItem> fieldExtractor = new BeanWrapperFieldExtractor<>();
            fieldExtractor.setNames(MIGRATION_REPORT_ITEM_COLUMNS);

            DelimitedLineAggregator<MigrationReportItem> lineAggregator = new DelimitedLineAggregator<>();
            lineAggregator.setFieldExtractor(fieldExtractor);
            lineAggregator.setDelimiter(",");

            FlatFileItemWriter<MigrationReportItem> writer = new FlatFileItemWriterBuilder<MigrationReportItem>()
                .name("reportItemWriter")
                .resource(new FileSystemResource(Path.of("/app/membership-data-importer/output.csv")))
                .lineAggregator(lineAggregator)
                .headerCallback(callback -> callback.write(String.join(",", MIGRATION_REPORT_ITEM_COLUMNS)))
                .build();

            writer.open(new ExecutionContext());

            for (List<MigrationReportItem> membershipReportItems : items) {
                writer.write(new Chunk<>(membershipReportItems));
            }

            writer.close();
        };
    }

    @Bean
    public Step reportPostCustomerMigrationStep(JobRepository jobRepository,
                                                PlatformTransactionManager transactionManager,
                                                ItemReader<Entity> reportPostCustomerMigrationReader,
                                                ItemProcessor<Entity, List<MigrationReportItem>> reportPostCustomerMigrationProcessor,
                                                ItemWriter<List<MigrationReportItem>> reportPostCustomerMigrationWriter) {
        return new StepBuilder("reportPostCustomerMigrationStep", jobRepository)
            .<Entity, List<MigrationReportItem>>chunk(chunkSize, transactionManager)
            .reader(reportPostCustomerMigrationReader)
            .processor(reportPostCustomerMigrationProcessor)
            .writer(reportPostCustomerMigrationWriter)
            .build();
    }

    @Bean
    public Job reportPostCustomerMigrationJob(JobRepository jobRepository, Step reportPostCustomerMigrationStep) {
        return new JobBuilder("reportPostCustomerMigrationJob", jobRepository)
            .incrementer(new RunIdIncrementer())
            .flow(reportPostCustomerMigrationStep)
            .end()
            .build();
    }
}
