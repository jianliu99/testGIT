package ca.bestbuy.membership.accountdatamigration.config;

import ca.bestbuy.membership.accountdatamigration.entity.AccountPartyKey;
import ca.bestbuy.membership.accountdatamigration.listener.AccountPartyKeyLoadListener;
import ca.bestbuy.membership.accountdatamigration.repository.AccountJdbcRepository;
import ca.bestbuy.membership.membershipdatamigration.entity.reltio.Entity;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.PlatformTransactionManager;

@Configuration
@EnableBatchProcessing
@Slf4j
@RequiredArgsConstructor
@SuppressWarnings("unchecked")
public class AccountPartyKeyLoadBatchConfiguration {

    @Value("${account.partyKeyLoad.chunkSize:500}")
    private int chunkSize;

    private final AccountJdbcRepository accountRepository;

    @Bean
    public ItemWriter<List<AccountPartyKey>> accountPartyKeyWriter() {
        return chunk -> {
            if (chunk.getItems().isEmpty()) {
                log.info(" Chunk size is empty for the current reader, continue.");
                return;
            }
            log.info(" Updating UserObject table with the batch size of {} ", chunk.getItems().size());
            accountRepository.updateBatch((List<List<AccountPartyKey>>) chunk.getItems());
        };
    }

    @Bean
    public Step loadAccountPartyKeyStep(JobRepository jobRepository,
            PlatformTransactionManager transactionManager,
            ItemReader<Entity> reltioEntityReader,
            ItemProcessor<Entity, List<AccountPartyKey>> accountPartyKeyProcessor,
            ItemWriter<List<AccountPartyKey>> accountPartyKeyWriter) {
        return new StepBuilder("loadAccountPartyKeyStep", jobRepository)
            .<Entity, List<AccountPartyKey>>chunk(chunkSize, transactionManager)
            .reader(reltioEntityReader)
            .processor(accountPartyKeyProcessor)
            .writer(accountPartyKeyWriter)
            .build();
    }

    @Bean
    public Job loadAccountPartyKeyJob(JobRepository jobRepository, Step loadAccountPartyKeyStep,
            AccountPartyKeyLoadListener accountPartyKeyLoadListener) {
        return new JobBuilder("loadAccountPartyKeyJob", jobRepository)
            .listener(accountPartyKeyLoadListener)
            .start(loadAccountPartyKeyStep)
            .build();
    }
}
