package ca.bestbuy.membership.accountdatamigration.repository;

import ca.bestbuy.membership.accountdatamigration.entity.AccountCustomer;
import ca.bestbuy.membership.accountdatamigration.entity.AccountPartyKey;
import java.util.List;

public interface AccountJdbcRepository {

    void updateBatch(List<List<AccountPartyKey>> partyKeys);

    AccountCustomer getCustomerById(String id);
}
