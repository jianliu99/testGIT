package ca.bestbuy.membership.membershipdatamigration.entity.report;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ValidationResult {
    private String status;
    private String comment;
}
