package ca.bestbuy.membership.membershipdatamigration.entity.jpa;

public enum MembershipTierCode {
    BM, // Best Buy Membership
    PL,
    NL,
    GSPADP,
    GSPPBT1,
    GSPPBT2,
    GSPPBT3,
    GSBMT1,
    GSBMT2,
    GSBMT3,
    BBPP
}