package ca.bestbuy.membership.membershipdatamigration.config;

import static ca.bestbuy.membership.membershipdatamigration.util.TimeUtil.getTimestamp;

import ca.bestbuy.membership.membershipdatamigration.entity.jpa.Membership;
import ca.bestbuy.membership.membershipdatamigration.entity.jpa.MembershipCancelRequest;
import ca.bestbuy.membership.membershipdatamigration.entity.jpa.PaymentCalculation;
import ca.bestbuy.membership.membershipdatamigration.entity.reltio.Entity;
import ca.bestbuy.membership.membershipdatamigration.repository.MembershipCancelRequestRepository;
import ca.bestbuy.membership.membershipdatamigration.repository.MembershipPaymentRepository;
import ca.bestbuy.membership.membershipdatamigration.repository.MembershipRepository;
import com.azure.storage.blob.BlobClient;
import com.azure.storage.blob.BlobContainerClient;
import com.azure.storage.blob.BlobServiceClient;
import com.azure.storage.blob.specialized.BlobInputStream;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.annotation.PostConstruct;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.List;
import java.util.zip.GZIPInputStream;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.data.RepositoryItemReader;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.domain.Sort;

@Configuration
@Slf4j
public class ReaderConfiguration {

    @Value("${membership.gracePeriod}")
    private int gracePeriod;

    @Value("${membership.incrementalStatusLoad.reader.pageSize}")
    private int pageSize;

    @Value("${azure.blobStorage.container-name}")
    private String blobContainer;

    @Value("${azure.blobStorage.blob-name}")
    private String blobName;

    @Bean
    @StepScope
    public ItemReader<MembershipCancelRequest> cancelRequestReader(
        @Value("#{jobParameters['incrementalLoadStartDate']}") String incrementalLoadStartDate,
        MembershipCancelRequestRepository repository) {

        RepositoryItemReader<MembershipCancelRequest> reader = new RepositoryItemReader<>();
        reader.setPageSize(pageSize);
        reader.setRepository(repository);
        reader.setMethodName("findByUpdatedDateAfter");
        reader.setArguments(List.of(getTimestamp(incrementalLoadStartDate)));
        reader.setSort(Collections.singletonMap("membershipCancelRequestId", Sort.Direction.ASC));
        return reader;
    }

    @Bean
    @StepScope
    public ItemReader<PaymentCalculation> paymentReader(
        @Value("#{jobParameters['incrementalLoadStartDate']}") String incrementalLoadStartDate,
        MembershipPaymentRepository repository) {

        RepositoryItemReader<PaymentCalculation> reader = new RepositoryItemReader<>();
        reader.setPageSize(pageSize);
        reader.setRepository(repository);
        reader.setMethodName("calculateTotalPayed");
        reader.setArguments(List.of(getTimestamp(incrementalLoadStartDate)));
        reader.setSort(Collections.singletonMap("membership.membershipId", Sort.Direction.ASC));
        return reader;
    }

    @Bean
    @StepScope
    public ItemReader<Membership> suspendedAndCanceledLumpSumsMembershipReader(
        @Value("#{jobParameters['incrementalLoadStartDate']}") String incrementalLoadStartDate,
        MembershipRepository repository) {

        RepositoryItemReader<Membership> reader = new RepositoryItemReader<>();
        reader.setPageSize(pageSize);
        reader.setRepository(repository);
        reader.setMethodName("getSuspendedAndCanceledLumpSumsMemberships");
        reader.setArguments(List.of(getTimestamp(incrementalLoadStartDate), gracePeriod));
        reader.setSort(Collections.singletonMap("membership_id", Sort.Direction.ASC));
        return reader;
    }

    @Bean
    @StepScope
    public ItemReader<Entity> reltioEntityReader(BlobServiceClient blobServiceClient,
        @Value("#{jobParameters['fileExportName']}") String fileExportName) throws IOException {

        return readReltioFileFromAzureBlob(blobServiceClient, "reltioEntityReader", fileExportName);
    }

    @Bean
    @StepScope
    public ItemReader<Entity> reportPostCustomerMigrationReader(BlobServiceClient blobServiceClient,
        @Value("#{jobParameters['fileExportName']}") String fileExportName) throws IOException {

        return readReltioFileFromAzureBlob(blobServiceClient, "reportPostCustomerMigrationReader", fileExportName);
    }

    private ItemReader<Entity> readReltioFileFromAzureBlob(BlobServiceClient blobServiceClient, String readerName,
        String fileExportName) {

        return new ItemReader<Entity>() {
            private JsonParser jsonParser;
            private ObjectMapper objectMapper = new ObjectMapper();

            @PostConstruct
            public void init() throws IOException {
                try {
                    BlobContainerClient blobContainerClient = blobServiceClient.getBlobContainerClient(blobContainer);
                    String fullBlobName = blobName + fileExportName;
                    BlobClient blobClient = blobContainerClient.getBlobClient(fullBlobName);
                    BlobInputStream blobInputStream = blobClient.openInputStream();
                    GZIPInputStream gzipIn = new GZIPInputStream(blobInputStream);
                    InputStreamReader reader = new InputStreamReader(gzipIn, StandardCharsets.UTF_8);
                    jsonParser = objectMapper.getFactory().createParser(reader);
                } catch (IOException e) {
                    log.error("Error initializing JsonParser", e);
                    throw new RuntimeException(e);
                }
            }

            @Override
            public Entity read() throws Exception {
                JsonToken nextToken = jsonParser.nextToken();
                if (nextToken == JsonToken.START_ARRAY) {
                    // If the next token is the start of an array, move to the next token
                    nextToken = jsonParser.nextToken();
                }
                if (nextToken == JsonToken.START_OBJECT) {
                    return jsonParser.readValueAs(Entity.class);
                } else {
                    return null;
                }
            }
        };
    }
}
