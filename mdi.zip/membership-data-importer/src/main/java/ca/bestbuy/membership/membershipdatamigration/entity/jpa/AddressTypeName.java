package ca.bestbuy.membership.membershipdatamigration.entity.jpa;

public enum AddressTypeName {
    BILLING,
    SERVICE
}
