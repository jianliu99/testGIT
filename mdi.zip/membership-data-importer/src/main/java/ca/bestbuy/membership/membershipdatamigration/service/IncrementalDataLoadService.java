package ca.bestbuy.membership.membershipdatamigration.service;

import ca.bestbuy.membership.membershipdatamigration.entity.request.IncrementalDataLoadRequest;
import java.util.concurrent.Semaphore;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.stereotype.Service;

@Service
public interface IncrementalDataLoadService {

    void processIncrementalDataLoad(IncrementalDataLoadRequest request, Semaphore incrementalLoadLock)
            throws JobInstanceAlreadyCompleteException, JobExecutionAlreadyRunningException, JobParametersInvalidException, JobRestartException;
}
