package ca.bestbuy.membership.membershipdatamigration.processor;

import ca.bestbuy.membership.membershipdatamigration.entity.jpa.Membership;
import ca.bestbuy.membership.membershipdatamigration.entity.jpa.MembershipPaymentFrequencyCode;
import ca.bestbuy.membership.membershipdatamigration.entity.jpa.MembershipStatusCode;
import ca.bestbuy.membership.membershipdatamigration.repository.MembershipStatusRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
@Slf4j
public class MembershipStatusProcessor implements ItemProcessor<Membership, Membership> {

    private final MembershipStatusRepository membershipStatusRepository;

    @Override
    public Membership process(Membership membership) {
        log.info("Found membership with membershipId {}", membership.getMembershipId());

        if (membership.getMembershipSku().getMembershipPaymentFrequency()
                .getMembershipPaymentFrequencyCode() == MembershipPaymentFrequencyCode.LS
                && membership.getMembershipStatus().getMembershipStatusCode() != MembershipStatusCode.C) {

            membership.setMembershipStatus(membershipStatusRepository.getByMembershipStatusCode(MembershipStatusCode.C));

            log.info("Updating the status code to {} for membershipId {}",
                    membership.getMembershipStatus().getMembershipStatusCode(), membership.getMembershipId());

        } else if ((membership.getMembershipSku().getMembershipPaymentFrequency()
                .getMembershipPaymentFrequencyCode() == MembershipPaymentFrequencyCode.M
                || membership.getMembershipSku().getMembershipPaymentFrequency()
                .getMembershipPaymentFrequencyCode() == MembershipPaymentFrequencyCode.A)
                && membership.getMembershipStatus().getMembershipStatusCode() != MembershipStatusCode.C
                && membership.getMembershipStatus().getMembershipStatusCode() != MembershipStatusCode.S) {

            membership.setMembershipStatus(membershipStatusRepository.getByMembershipStatusCode(MembershipStatusCode.S));

            log.info("Updating the status code to {} for membershipId {}",
                    membership.getMembershipStatus().getMembershipStatusCode(), membership.getMembershipId());
        }

        return membership;
    }
}
