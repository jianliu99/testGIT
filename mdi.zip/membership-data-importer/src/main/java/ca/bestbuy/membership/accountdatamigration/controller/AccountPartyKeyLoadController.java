package ca.bestbuy.membership.accountdatamigration.controller;

import ca.bestbuy.membership.accountdatamigration.service.AccountPartyKeyLoadService;
import ca.bestbuy.membership.membershipdatamigration.entity.request.PartyKeyProcessRequest;
import jakarta.validation.Valid;
import java.util.concurrent.Semaphore;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@AllArgsConstructor
public class AccountPartyKeyLoadController {

    AccountPartyKeyLoadService partyKeyLoadService;

    private final Semaphore partyKeyLoadLock = new Semaphore(1);

    @PostMapping("/account/process-party-key-load")
    public ResponseEntity<String> handle(@Valid @RequestBody PartyKeyProcessRequest request) throws Exception {
        log.info("Handling party key load request for AccountDB");
        if (partyKeyLoadLock.tryAcquire()) {
            partyKeyLoadService.processAccountPartyKeyLoad(partyKeyLoadLock, request.getFileExportName());
            return ResponseEntity.ok("AccountDB party key load batch process started successfully.");
        } else {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                .body("A previous AccountDB party key load batch process still running. Try after sometime");
        }
    }

}
