package ca.bestbuy.membership.membershipdatamigration.entity.jpa;

import static ca.bestbuy.membership.membershipdatamigration.util.Constant.APPLICATION_NAME;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.ForeignKey;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import lombok.Data;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Data
@Entity(name = "MembershipPayment")
@Table(name = "membership_payment")
@EntityListeners(AuditingEntityListener.class)
public class MembershipPayment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(
            name = "membership_payment_id",
            updatable = false,
            insertable = false,
            unique = true,
            columnDefinition = "INT"
    )
    private Integer membershipPaymentId;

    @ManyToOne
    @JoinColumn(
            name = "membership_id",
            referencedColumnName = "membership_id",
            nullable = false,
            foreignKey = @ForeignKey(
                    name = "FK_payment_membership_id"
            )
    )
    private Membership membership;

    @OneToOne
    @JoinColumn(
            name = "payment_type_id",
            referencedColumnName = "payment_type_id",
            nullable = false,
            foreignKey = @ForeignKey(
                    name = "FK_payment_type_id"
            )
    )
    private PaymentType paymentType;

    @OneToOne
    @JoinColumn(
        name = "membership_cancel_reason_id",
        referencedColumnName = "membership_cancel_reason_id",
        foreignKey = @ForeignKey(
            name = "FK_membership_cancel_reason_id"
        )
    )
    private MembershipCancelReason membershipCancelReason;

    @Column(
            name = "batch_sequence_id",
            nullable = false,
            columnDefinition = "VARCHAR(25)"
    )
    private String batchSequenceId;

    @Column(
            name = "payment_amount",
            nullable = false,
            columnDefinition = "DECIMAL(10, 2)"
    )
    private BigDecimal paymentAmount;

    @Column(
            name = "transaction_date",
            columnDefinition = "DATE"
    )
    private Date transactionDate;

    @Column(
            name = "posting_date",
            columnDefinition = "DATE"
    )
    private Date postingDate;

    @Column(
            name = "tax_rate",
            nullable = false,
            columnDefinition = "DECIMAL(10, 2)"
    )
    private BigDecimal taxRate;

    @Column(
            name = "tax_amount",
            nullable = false,
            columnDefinition = "DECIMAL(10, 2)"
    )
    private BigDecimal taxAmount;

    @Column(
            name = "assurant_id",
            nullable = false,
            columnDefinition = "VARCHAR(30)"
    )
    private BigDecimal assurantId;

    @Column(
            name = "created_by",
            updatable = false,
            nullable = false
    )
    @CreatedBy
    private String createdBy;

    @Column(
            name = "created_date",
            nullable = false,
            updatable = false,
            columnDefinition = "DATETIME"
    )
    @CreatedDate
    private Timestamp createdDate;

    @Column(
            name = "updated_by",
            nullable = false
    )
    @LastModifiedBy
    private String updatedBy;

    @Column(
            name = "updated_date",
            nullable = false,
            columnDefinition = "DATETIME"
    )
    @LastModifiedDate
    private Timestamp updatedDate;

    @PreUpdate
    public void onPreUpdate() {
        this.updatedBy = APPLICATION_NAME;
    }
}