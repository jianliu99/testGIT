package ca.bestbuy.membership.membershipdatamigration.service;

import java.sql.Timestamp;
import java.util.concurrent.Semaphore;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@AllArgsConstructor
public class PartyKeyLoadServiceImpl implements PartyKeyLoadService {

    private final JobLauncher jobLauncher;

    private Job loadPartyKeyJob;

    @Async
    public void processPartyKeyLoad(Semaphore partyKeyLoadLock, String fileExportName) throws JobParametersInvalidException,
        JobExecutionAlreadyRunningException, JobRestartException, JobInstanceAlreadyCompleteException {

        try {
            Timestamp jobStartTime = new Timestamp(System.currentTimeMillis());
            JobParameters jobParameters = createInitialJobParameterMap(jobStartTime, fileExportName);
            log.info("******  ProcessPartyKeyLoad job started at {}", jobStartTime);
            JobExecution jobExecution = jobLauncher.run(loadPartyKeyJob, jobParameters);

            BatchStatus batchStatus = jobExecution.getStatus();

            if (batchStatus == BatchStatus.COMPLETED) {
                Timestamp jobEndTime = new Timestamp(System.currentTimeMillis());
                log.info("******  ProcessPartyKeyLoad job completed at {}", jobEndTime);
                log.info("ProcessPartyKeyLoad job completed successfully");
                log.info("Party Key is updated for related memberships in membership table");
            } else {
                log.error("ProcessPartyKeyLoad job did not complete");
            }
        } finally {
            partyKeyLoadLock.release();
        }
    }

    private JobParameters createInitialJobParameterMap(Timestamp jobStartTime, String fileExportName) {
        return new JobParametersBuilder()
            .addLong("time", jobStartTime.getTime())
            .addString("fileExportName", fileExportName)
            .toJobParameters();
    }
}
