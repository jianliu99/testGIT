package ca.bestbuy.membership.membershipdatamigration.entity.jpa;

public enum CancelCodeName {
    COMPLETE_NONPAY,
    PARTIAL_NONPAY,
    DELAYED_RETURN,
    EARLY_RETURN,
    QUEBEC_VLNTRY,
    LIFE_EVENT,
    ADMIN_CORRECTION,
    CHARGEBACK,
    NONCONTRACT_ASSET_VLNTRY,
    CONTRACT_ASSET_VLNTRY,
    T2MOB_NONPAY,
    T2MOB_VLNTRY,
}
