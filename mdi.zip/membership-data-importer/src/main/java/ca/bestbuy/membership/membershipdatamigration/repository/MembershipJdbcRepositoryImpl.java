package ca.bestbuy.membership.membershipdatamigration.repository;

import ca.bestbuy.membership.membershipdatamigration.entity.PartyKey;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.stream.Collectors;
import javax.sql.DataSource;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.annotation.Transactional;

public class MembershipJdbcRepositoryImpl implements MembershipJdbcRepository {

    private final JdbcTemplate jdbcTemplate;

    public MembershipJdbcRepositoryImpl(DataSource dataSource) {
        this.jdbcTemplate = new JdbcTemplate(dataSource);
    }

    @Override
    @Transactional
    public void updateBatch(List<List<PartyKey>> partyKeys) {
        String sql = "UPDATE membership SET party_key = ? where membership_id = ?";

        List<PartyKey> partyKeysFlat = partyKeys.stream()
            .flatMap(List::stream)
            .collect(Collectors.toList());

        jdbcTemplate.batchUpdate(sql, new BatchPreparedStatementSetter() {
            @Override
            public void setValues(PreparedStatement ps, int i) throws SQLException {
                PartyKey partyKey = partyKeysFlat.get(i);
                ps.setNString(1, partyKey.getPartyKey());
                ps.setInt(2, partyKey.getMembershipId());
            }

            @Override
            public int getBatchSize() {
                return partyKeysFlat.size();
            }
        });
    }
}
