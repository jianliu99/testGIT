package ca.bestbuy.membership.membershipdatamigration.config;

import ca.bestbuy.membership.membershipdatamigration.entity.jpa.Membership;
import ca.bestbuy.membership.membershipdatamigration.entity.jpa.MembershipCancelRequest;
import ca.bestbuy.membership.membershipdatamigration.entity.jpa.PaymentCalculation;
import ca.bestbuy.membership.membershipdatamigration.listener.CachingListener;
import ca.bestbuy.membership.membershipdatamigration.listener.IncrementalDataLoadListener;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.support.IteratorItemReader;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.transaction.PlatformTransactionManager;

@Configuration
@EnableBatchProcessing
@EnableAsync
@Slf4j
public class ProcessIncrementalDataLoadConfiguration {

    @Value("${membership.incrementalStatusLoad.processor.chunkSize}")
    private int chunkSize;

    @Bean
    public Step processCancelRequestStep(JobRepository jobRepository,
            PlatformTransactionManager transactionManager,
            ItemReader<MembershipCancelRequest> cancelRequestReader,
            ItemProcessor<MembershipCancelRequest, Membership> cancelRequestProcessor,
            ItemWriter<Membership> membershipWriter) {

        return new StepBuilder("processCancelRequestStep", jobRepository)
                .<MembershipCancelRequest, Membership>chunk(chunkSize, transactionManager)
                .reader(cancelRequestReader)
                .processor(cancelRequestProcessor)
                .writer(membershipWriter)
                .build();
    }

    @Bean
    public Step processPaymentStep(JobRepository jobRepository,
            PlatformTransactionManager transactionManager,
            ItemReader<PaymentCalculation> paymentReader,
            ItemProcessor<PaymentCalculation, Membership> paymentProcessor,
            ItemWriter<Membership> membershipWriter) {

        return new StepBuilder("processPaymentStep", jobRepository)
                .<PaymentCalculation, Membership>chunk(chunkSize, transactionManager)
                .reader(paymentReader)
                .processor(paymentProcessor)
                .writer(membershipWriter)
                .build();
    }

    @Bean
    public Step processSuspendedAndCanceledMembershipsStep(JobRepository jobRepository,
            PlatformTransactionManager transactionManager,
            ItemReader<Membership>
                    suspendedAndCanceledLumpSumsMembershipReader,
            ItemProcessor<Membership, Membership>
                    suspendedAndCanceledLumpSumsMembershipProcessor,
            SuspendedAndCanceledLumpSumsCollector<Membership> membershipSuspendedAndCanceledLumpSumsCollector) {

        return new StepBuilder("processSuspendedAndLumpSumsMembershipsStep", jobRepository)
                .<Membership, Membership>chunk(chunkSize, transactionManager)
                .reader(suspendedAndCanceledLumpSumsMembershipReader)
                .processor(suspendedAndCanceledLumpSumsMembershipProcessor)
                .writer(membershipSuspendedAndCanceledLumpSumsCollector)
                .build();
    }

    @Bean
    @StepScope
    public ItemReader<Membership> membershipItemReader(SuspendedAndCanceledLumpSumsCollector<Membership> collector) {
        List<Membership> membershipsCache = collector.getSuspendedMemberships();
        return new IteratorItemReader<Membership>(membershipsCache.iterator());
    }

    @Bean
    public Step writeSuspendedAndLumpSumsMembershipsStep(JobRepository jobRepository,
            PlatformTransactionManager transactionManager,
            ItemReader<Membership> membershipItemReader,
            SuspendedMembershipWriter suspendedMembershipWriter) {

        return new StepBuilder("writeSuspendedAndLumpSumsMembershipsStep", jobRepository)
                .<Membership, Membership>chunk(chunkSize, transactionManager)
                .reader(membershipItemReader)
                .writer(suspendedMembershipWriter)
                .build();

    }

    @Bean
    public Job processCancelRequestsAndPaymentsJob(JobRepository jobRepository,
            Step processCancelRequestStep, Step processPaymentStep,
            CachingListener cachingListener) {

        return new JobBuilder("processCancelRequestsAndPaymentsJob", jobRepository)
                .start(processCancelRequestStep)
                .next(processPaymentStep)
                .listener(cachingListener)
                .build();

    }

    @Bean
    public Job processSuspendedAndCanceledMembershipsJob(JobRepository jobRepository,
            Step processSuspendedAndCanceledMembershipsStep,
            Step writeSuspendedAndLumpSumsMembershipsStep,
            IncrementalDataLoadListener incrementalDataLoadListener) {

        return new JobBuilder("processSuspendedAndCanceledMembershipsJob", jobRepository)
                .start(processSuspendedAndCanceledMembershipsStep)
                .next(writeSuspendedAndLumpSumsMembershipsStep)
                .listener(incrementalDataLoadListener)
                .build();
    }
}
