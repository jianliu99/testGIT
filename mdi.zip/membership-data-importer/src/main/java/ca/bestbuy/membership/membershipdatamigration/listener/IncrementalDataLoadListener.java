package ca.bestbuy.membership.membershipdatamigration.listener;

import ca.bestbuy.membership.membershipdatamigration.config.SuspendedAndCanceledLumpSumsCollector;
import ca.bestbuy.membership.membershipdatamigration.entity.jpa.Membership;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class IncrementalDataLoadListener implements JobExecutionListener {

    private SuspendedAndCanceledLumpSumsCollector<Membership> collector;

    public IncrementalDataLoadListener(SuspendedAndCanceledLumpSumsCollector<Membership> collector) {
        this.collector = collector;
    }

    @Override
    public void beforeJob(JobExecution jobExecution) {
        // Clear the suspended memberships cache before incremental data load job run
        log.info("Clearing suspended memberships cache before starting incremental data load job");
        collector.clearSuspendedMemberships();
    }

    @Override
    public void afterJob(JobExecution jobExecution) {
        // Clear the suspended memberships cache after the incremental data load job run
        log.info("Clearing suspended memberships cache after finishing incremental data load job");
        collector.clearSuspendedMemberships();
    }
}
