package ca.bestbuy.membership.membershipdatamigration.entity.report.jpa;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class Address {

    @JsonProperty("address_line_1")
    private String addressLine1;

    @JsonProperty("address_line_2")
    private String addressLine2;

    @JsonProperty("city")
    private String city;

    @JsonProperty("suite")
    private String suite;

    @JsonProperty("region_name")
    private String regionName;

    @JsonProperty("postal_code")
    private String postalCode;

    @JsonProperty("country_name")
    private String countryName;

    @JsonProperty("membership_id")
    private String membershipId;
}
