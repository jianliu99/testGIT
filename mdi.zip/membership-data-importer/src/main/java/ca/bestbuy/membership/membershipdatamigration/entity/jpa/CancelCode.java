package ca.bestbuy.membership.membershipdatamigration.entity.jpa;

public enum CancelCode {
    OT, // COMPLETE_NONPAY
    NP, // PARTIAL_NONPAY
    MC, // DELAYED_RETURN
    DC, // EARLY_RETURN
    QC, // QUEBEC_VLNTRY
    CS, // LIFE_EVENT
    AF, // ADMIN_CORRECTION
    CL, // CHARGEBACK
    CM, // NONCONTRACT_ASSET_VLNTRY
    CP, // CONTRACT_ASSET_VLNTRY
    TW, // T2MOB_NONPAY
    TV  // T2MOB_VLNTRY
}
