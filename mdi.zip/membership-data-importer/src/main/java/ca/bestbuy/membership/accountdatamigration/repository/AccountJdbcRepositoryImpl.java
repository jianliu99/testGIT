package ca.bestbuy.membership.accountdatamigration.repository;

import ca.bestbuy.membership.accountdatamigration.entity.AccountAddress;
import ca.bestbuy.membership.accountdatamigration.entity.AccountCustomer;
import ca.bestbuy.membership.accountdatamigration.entity.AccountPartyKey;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Configuration;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.UncategorizedSQLException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.annotation.Transactional;

@Configuration
public class AccountJdbcRepositoryImpl implements AccountJdbcRepository {

    private final JdbcTemplate jdbcTemplate;

    public AccountJdbcRepositoryImpl(@Qualifier("accountDataSource") DataSource dataSource) {
        this.jdbcTemplate = new JdbcTemplate(dataSource);
    }

    @Override
    @Transactional
    public void updateBatch(List<List<AccountPartyKey>> accountPartyKeys) {
        String sql = "UPDATE UserObject SET U_CUSTOMER_PARTY_KEY = ?, i_migration_flag=? where U_USER_ID = ?";

        List<AccountPartyKey> accountPartyKeysFlat = accountPartyKeys.stream()
                .flatMap(List::stream)
                .toList();

        jdbcTemplate.batchUpdate(sql, new BatchPreparedStatementSetter() {
            @Override
            public void setValues(PreparedStatement ps, int i) throws SQLException {
                AccountPartyKey accountPartyKey = accountPartyKeysFlat.get(i);
                ps.setNString(1, accountPartyKey.getPartyKey());
                ps.setInt(2, 1);
                ps.setNString(3, accountPartyKey.getAccountKey());
            }

            @Override
            public int getBatchSize() {
                return accountPartyKeys.size();
            }
        });
    }

    public AccountCustomer getCustomerById(String id) {
        String sql = "SELECT u.u_user_id, u.u_first_name, u.u_last_name, u.u_email_address, u.u_customer_party_key,"
                + " a.u_primary_phone_number, a.u_address_line1, a.u_address_line2, a.u_city, a.u_region_code,"
                + " a.u_region_name, a.u_postal_code"
                + " FROM UserObject u LEFT join Addresses a"
                + " on u.u_default_address = a.u_address_id"
                + " where u_user_id = ?";

        try {
            return jdbcTemplate.queryForObject(sql, (rs, rowNum) -> {
                AccountAddress a = new AccountAddress();
                a.setAddressLine1(rs.getString("u_address_line1"));
                a.setAddressLine2(rs.getString("u_address_line2"));
                a.setCity(rs.getString("u_city"));
                a.setPostalCode(rs.getString("u_region_code"));
                a.setRegionName(rs.getString("u_region_name"));
                a.setPostalCode(rs.getString("u_postal_code"));

                AccountCustomer c = new AccountCustomer();
                c.setPartyKey(rs.getString("u_customer_party_key"));
                c.setAccountKey(rs.getString("u_user_id"));
                c.setFirstName(rs.getString("u_first_name"));
                c.setLastName(rs.getString("u_last_name"));
                c.setEmailAddress(rs.getString("u_email_address"));
                c.setPhoneNumber(rs.getString("u_primary_phone_number"));
                c.setAddress(a);

                return c;
            }, id);
        } catch (EmptyResultDataAccessException | UncategorizedSQLException e) {
            return null;
        }
    }
}
