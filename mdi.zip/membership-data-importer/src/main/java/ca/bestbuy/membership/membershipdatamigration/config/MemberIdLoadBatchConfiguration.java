package ca.bestbuy.membership.membershipdatamigration.config;

import ca.bestbuy.membership.membershipdatamigration.entity.jpa.MemberIdStage;
import ca.bestbuy.membership.membershipdatamigration.entity.jpa.MembershipContract;
import ca.bestbuy.membership.membershipdatamigration.listener.EnrichedContractJobListener;
import ca.bestbuy.membership.membershipdatamigration.mapper.CsparcContractMapper;
import ca.bestbuy.membership.membershipdatamigration.repository.MemberIdStageRepository;
import java.util.List;
import javax.sql.DataSource;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.Chunk;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.database.JdbcPagingItemReader;
import org.springframework.batch.item.database.PagingQueryProvider;
import org.springframework.batch.item.database.support.SqlPagingQueryProviderFactoryBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.PlatformTransactionManager;

@Slf4j
@Configuration
@EnableBatchProcessing
@RequiredArgsConstructor
public class MemberIdLoadBatchConfiguration {

    private final MemberIdStageRepository memberIdStageRepository;

    private final DataSource dataSource;

    @Value("${membership.memberIdLoad.reader.pageSize}")
    private int pageSize;

    @Value("${membership.memberIdLoad.processor.chunkSize}")
    private int chunkSize;

    @Bean
    public ItemReader<MembershipContract> membershipContractReader(PagingQueryProvider queryProvider) {
        JdbcPagingItemReader<MembershipContract> reader = new JdbcPagingItemReader<>();
        reader.setDataSource(dataSource);
        reader.setPageSize(pageSize);
        reader.setQueryProvider(queryProvider);
        reader.setRowMapper(new CsparcContractMapper());
        return reader;
    }


    @Bean
    public PagingQueryProvider queryProvider() throws Exception {
        SqlPagingQueryProviderFactoryBean queryProviderFactory = new SqlPagingQueryProviderFactoryBean();
        queryProviderFactory.setDataSource(dataSource);
        queryProviderFactory.setSelectClause("SELECT id");
        queryProviderFactory.setFromClause("FROM membership_contracts_stage");
        queryProviderFactory.setSortKey("id");
        return queryProviderFactory.getObject();
    }


    @Bean
    public ItemWriter<MemberIdStage> enrichedMembershipContractItemWriter() {
        return new ItemWriter<MemberIdStage>() {
            @Override
            public void write(Chunk<? extends MemberIdStage> contracts) throws Exception {
                log.info(" Saving to memberIdStage table with the batch size of {} ", chunkSize);
                memberIdStageRepository.insertBatch((List<MemberIdStage>) contracts);
            }
        };
    }

    @Bean
    public Step addMemberIdToContractStep(JobRepository jobRepository,
            PlatformTransactionManager transactionManager,
            ItemReader<MembershipContract> membershipContractItemReader,
            ItemProcessor<MembershipContract, MemberIdStage> processor,
            ItemWriter<MemberIdStage> enrichedMembershipContractWriter) {

        return new StepBuilder("addMemberIdToContractTable", jobRepository)
                .<MembershipContract, MemberIdStage>chunk(chunkSize, transactionManager)
                .reader(membershipContractItemReader)
                .processor(processor)
                .writer(enrichedMembershipContractWriter)
                .build();
    }


    @Bean
    public Job addMemberIdToContractJob(JobRepository jobRepository,
            Step addMemberIdToContractStep,
            EnrichedContractJobListener listener) {

        return new JobBuilder("addMemberIdToContractTable", jobRepository)
                .start(addMemberIdToContractStep)
                .listener(listener)
                .build();
    }
}
