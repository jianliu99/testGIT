package ca.bestbuy.membership.membershipdatamigration.entity.jpa;

import static ca.bestbuy.membership.membershipdatamigration.util.Constant.APPLICATION_NAME;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import java.sql.Timestamp;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Data
@Entity(name = "MembershipStatus")
@Table(name = "membership_status")
@EntityListeners(AuditingEntityListener.class)
@NoArgsConstructor
@AllArgsConstructor
public class MembershipStatus {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(
            name = "membership_status_id",
            updatable = false,
            insertable = false,
            unique = true,
            columnDefinition = "TINYINT"
    )
    private Integer membershipStatusId;

    @Enumerated(
            EnumType.STRING
    )
    @Column(
            name = "membership_status_name",
            unique = true,
            nullable = false,
            columnDefinition = "VARCHAR(32)"
    )
    private Status membershipStatusName;

    @Enumerated(
            EnumType.STRING
    )
    @Column(
            name = "membership_status_code",
            unique = true,
            nullable = false,
            columnDefinition = "VARCHAR(2)"
    )
    private MembershipStatusCode membershipStatusCode;

    @Column(
            name = "membership_status_description",
            nullable = false,
            columnDefinition = "NVARCHAR(255)"
    )
    private String membershipStatusDescription;

    @Column(
            name = "created_by",
            updatable = false,
            nullable = false
    )
    @CreatedBy
    private String createdBy;

    @Column(
            name = "created_date",
            nullable = false,
            updatable = false,
            columnDefinition = "DATETIME"
    )
    @CreatedDate
    private Timestamp createdDate;

    @Column(
            name = "updated_by",
            nullable = false
    )
    @LastModifiedBy
    private String updatedBy;

    @Column(
            name = "updated_date",
            nullable = false,
            columnDefinition = "DATETIME"
    )
    @LastModifiedDate
    private Timestamp updatedDate;

    @PreUpdate
    public void onPreUpdate() {
        this.updatedBy = APPLICATION_NAME;
    }
}