package ca.bestbuy.membership.membershipdatamigration.repository;

import ca.bestbuy.membership.membershipdatamigration.entity.jpa.MemberIdStage;
import ca.bestbuy.membership.membershipdatamigration.mapper.MemberIdStageMapper;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import javax.sql.DataSource;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public class MemberIdStageRepository {

    private final JdbcTemplate jdbcTemplate;

    public MemberIdStageRepository(DataSource dataSource) {
        this.jdbcTemplate = new JdbcTemplate(dataSource);
    }

    @Transactional
    public void insertBatch(List<MemberIdStage> memberIds) {
        String sql = "INSERT INTO member_id_stage (ID, MEMBER_ID) VALUES (?, ?)";

        jdbcTemplate.batchUpdate(sql, new BatchPreparedStatementSetter() {
            @Override
            public void setValues(PreparedStatement ps, int i) throws SQLException {
                MemberIdStage memberIdStage = memberIds.get(i);
                ps.setInt(1, memberIdStage.getId());
                ps.setInt(2, memberIdStage.getMemberId());
            }

            @Override
            public int getBatchSize() {
                return memberIds.size();
            }
        });
    }

    public List<MemberIdStage> getAllMemberIdStages() {
        String selectAllMemberIdSql = "SELECT TOP 1000 ID , MEMBER_ID FROM  member_id_stage";
        return jdbcTemplate.query(selectAllMemberIdSql, new MemberIdStageMapper());
    }

}
