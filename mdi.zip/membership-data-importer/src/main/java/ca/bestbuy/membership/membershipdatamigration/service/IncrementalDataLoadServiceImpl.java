package ca.bestbuy.membership.membershipdatamigration.service;

import ca.bestbuy.membership.membershipdatamigration.entity.request.IncrementalDataLoadRequest;
import java.util.concurrent.Semaphore;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@RequiredArgsConstructor
@Service
@Slf4j
public class IncrementalDataLoadServiceImpl implements IncrementalDataLoadService {

    private final JobLauncher jobLauncher;

    private final Job processCancelRequestsAndPaymentsJob;

    private final Job processSuspendedAndCanceledMembershipsJob;

    @Async
    public void processIncrementalDataLoad(IncrementalDataLoadRequest request, Semaphore incrementalLoadLock)
            throws JobInstanceAlreadyCompleteException, JobExecutionAlreadyRunningException, JobParametersInvalidException, JobRestartException {
        try {
            JobParameters jobParameters = createInitialJobParameterMap(request);
            jobLauncher.run(processCancelRequestsAndPaymentsJob, jobParameters);
            if (!request.isRunIncomplete()) {
                jobLauncher.run(processSuspendedAndCanceledMembershipsJob, jobParameters);
            }
        } finally {
            incrementalLoadLock.release();
        }
    }

    private JobParameters createInitialJobParameterMap(IncrementalDataLoadRequest request) {

        if (request.getIncrementalLoadStartDate() != null) {
            return new JobParametersBuilder()
                    .addLong("time", System.currentTimeMillis())
                    .addString("incrementalLoadStartDate", request.getIncrementalLoadStartDate().toString())
                    .toJobParameters();
        } else {
            return new JobParametersBuilder()
                    .addLong("time", System.currentTimeMillis())
                    .toJobParameters();
        }
    }
}
