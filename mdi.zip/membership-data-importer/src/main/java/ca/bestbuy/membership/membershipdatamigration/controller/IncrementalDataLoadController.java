package ca.bestbuy.membership.membershipdatamigration.controller;

import ca.bestbuy.membership.membershipdatamigration.entity.request.IncrementalDataLoadRequest;
import ca.bestbuy.membership.membershipdatamigration.service.IncrementalDataLoadService;
import jakarta.validation.Valid;
import java.util.concurrent.Semaphore;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@AllArgsConstructor
@RestController
@Slf4j
public class IncrementalDataLoadController {

    private final IncrementalDataLoadService incrementalDataLoadService;

    private final Semaphore incrementalLoadLock = new Semaphore(1);


    @PostMapping("/process-incremental-data-load")
    public ResponseEntity<String> processIncrementalDataLoad(@Valid @RequestBody IncrementalDataLoadRequest request)
            throws JobInstanceAlreadyCompleteException, JobExecutionAlreadyRunningException, JobParametersInvalidException, JobRestartException {
        log.info("Handling incremental data load request");
        if (incrementalLoadLock.tryAcquire()) {
            incrementalDataLoadService.processIncrementalDataLoad(request, incrementalLoadLock);
            return ResponseEntity.ok("incremental data load batch process started successfully.");
        } else {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                    .body("A previous incremental data load batch process still running. Try after sometime");
        }
    }
}
