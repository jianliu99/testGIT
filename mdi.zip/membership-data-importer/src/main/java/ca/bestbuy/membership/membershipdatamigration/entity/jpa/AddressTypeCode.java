package ca.bestbuy.membership.membershipdatamigration.entity.jpa;

public enum AddressTypeCode {
    B, // Billing
    S  // Service
}