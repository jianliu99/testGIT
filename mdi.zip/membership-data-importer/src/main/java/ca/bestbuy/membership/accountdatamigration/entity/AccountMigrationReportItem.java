package ca.bestbuy.membership.accountdatamigration.entity;

import lombok.Data;

@Data
public class AccountMigrationReportItem {
    private String reltioPartyKey;
    private String accountKey;
    private String partyKeyStatus;
    private String firstNameStatus;
    private String lastNameStatus;
    private String phoneStatus;
    private String emailStatus;
    private String addressStatus;
    private String error;
}
