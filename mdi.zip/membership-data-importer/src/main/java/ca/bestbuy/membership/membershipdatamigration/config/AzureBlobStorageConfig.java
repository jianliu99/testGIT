package ca.bestbuy.membership.membershipdatamigration.config;

import com.azure.identity.ClientSecretCredential;
import com.azure.identity.ClientSecretCredentialBuilder;
import com.azure.storage.blob.BlobServiceClient;
import com.azure.storage.blob.BlobServiceClientBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AzureBlobStorageConfig {

    @Value("${azure.keyVault.clientId}")
    private String azureKeyVaultClientId;

    @Value("${azure.keyVault.tenantId}")
    private String azureKeyVaultTenantId;

    @Value("${azure.keyVault.clientSecret}")
    private String azureKeyVaultClientSecret;

    @Value("${azure.blobStorage.accountUrl}")
    private String azureBlobStorageAccountUrl;

    @Bean
    public BlobServiceClient blobServiceClient() {

        return new BlobServiceClientBuilder()
            .credential(createSecretClient())
            .endpoint(azureBlobStorageAccountUrl)
            .buildClient();
    }

    private ClientSecretCredential createSecretClient() {

        return new ClientSecretCredentialBuilder()
            .clientId(azureKeyVaultClientId)
            .clientSecret(azureKeyVaultClientSecret)
            .tenantId(azureKeyVaultTenantId)
            .build();
    }
}
