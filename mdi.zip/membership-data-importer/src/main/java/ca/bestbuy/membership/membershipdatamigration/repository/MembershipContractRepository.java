package ca.bestbuy.membership.membershipdatamigration.repository;

import ca.bestbuy.membership.membershipdatamigration.entity.jpa.MembershipContract;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MembershipContractRepository extends JpaRepository<MembershipContract, Integer> {

}

