package ca.bestbuy.membership.membershipdatamigration.util;

import java.util.regex.Pattern;
import lombok.experimental.UtilityClass;

@UtilityClass
public class MigrationReportConstant {

    // Reltio
    public static final Pattern ZIP_PATTERN = Pattern.compile("entities/(\\w+)/attributes/Address/(\\w+)/Zip/(\\w+)/PostalCode/(\\w+)");
    public static final Pattern EMAIL_PATTERN = Pattern.compile("entities/(\\w+)/attributes/Email/(\\w+)/Email/(\\w+)");
    public static final Pattern PHONE_PATTERN = Pattern.compile("entities/(\\w+)/attributes/Phone/(\\w+)/Number/(\\w+)");
    public static final String ENTITIES = "entities/";

    // Report
    public static final String REPORT_STATUS_PASS = "Pass";
    public static final String REPORT_STATUS_FAIL = "Fail";

    // Customer
    public static final String PARTY_KEY = "PartyKey";
    public static final String FIRST_NAME = "FirstName";
    public static final String LAST_NAME = "LastName";
    public static final String PHONE = "Phone";
    public static final String EMAIL = "Email";

    // Address
    public static final String ADDRESS_LINE_1 = "AddressLine1";
    public static final String ADDRESS_LINE_2 = "AddressLine2";
    public static final String CITY = "City";
    public static final String STATE_PROVINCE = "StateProvince";
    public static final String COUNTRY = "Country";
    public static final String ZIP = "Zip";
    public static final String REGION_CODE = "RegionCode";
    public static final String REGION_NAME = "RegionName";
}
