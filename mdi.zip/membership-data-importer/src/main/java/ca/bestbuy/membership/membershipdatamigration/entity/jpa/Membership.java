package ca.bestbuy.membership.membershipdatamigration.entity.jpa;

import static ca.bestbuy.membership.membershipdatamigration.util.Constant.APPLICATION_NAME;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.FetchType;
import jakarta.persistence.ForeignKey;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.Set;
import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity(name = "Membership")
@Table(name = "membership", indexes = @Index(name = "IDX_email_phone_gcid", columnList = "email_address, phone_number, global_contract_id"))
@EntityListeners(AuditingEntityListener.class)
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString(exclude = {"addresses"})
public class Membership {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(
            name = "membership_id",
            updatable = false,
            insertable = false,
            unique = true,
            columnDefinition = "INT"
    )
    private Integer membershipId;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(
            name = "membership_sku_id",
            referencedColumnName = "membership_sku_id",
            nullable = false,
            foreignKey = @ForeignKey(
                    name = "FK_membership_sku_id"
            )
    )
    private MembershipSku membershipSku;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(
            name = "membership_status_id",
            referencedColumnName = "membership_status_id",
            nullable = false,
            foreignKey = @ForeignKey(
                    name = "FK_membership_status_id"
            )
    )
    private MembershipStatus membershipStatus;

    @OneToMany(mappedBy = "membership", cascade = CascadeType.PERSIST)
    private Set<Address> addresses;

    @OneToMany(mappedBy = "membership")
    private Set<MembershipPayment> payments;

    @Column(
            name = "party_key"
    )
    private String partyKey;

    @Column(
            name = "member_id",
            nullable = false,
            unique = true
    )
    private Integer memberId;

    @Column(
        name = "membership_key",
        nullable = false,
        unique = true
    )
    private String membershipKey;

    @Column(
            name = "psp_id",
            nullable = false,
            unique = true,
            columnDefinition = "VARCHAR(30)"
    )
    private String pspId;

    @Column(
            name = "global_contract_id",
            columnDefinition = "VARCHAR(50)"
    )
    private String globalContractId;

    @Column(
            name = "zuora_product_rate_plan_id"
    )
    private String zuoraProductRatePlanId;

    @Column(
            name = "email_address",
            columnDefinition = "NVARCHAR(80)"
    )
    private String emailAddress;

    @Column(
            name = "phone_number",
            columnDefinition = "VARCHAR(15)"
    )
    private String phoneNumber;

    @Column(
            name = "membership_start_date",
            nullable = false,
            columnDefinition = "DATE"
    )
    private Date membershipStartDate;

    @Column(
            name = "membership_end_date",
            columnDefinition = "DATE"
    )
    private Date membershipEndDate;

    @Column(
            name = "first_name",
            nullable = false,
            columnDefinition = "NVARCHAR(60)"
    )
    private String firstName;

    @Column(
            name = "last_name",
            nullable = false,
            columnDefinition = "NVARCHAR(60)"
    )
    private String lastName;

    @Column(
            name = "total_recurring_amount_paid",
            nullable = false,
            columnDefinition = "DECIMAL(10, 2)"
    )
    private BigDecimal totalRecurringAmountPaid;

    @Column(
            name = "paid_up_to_date",
            columnDefinition = "DATE"
    )
    private Date paidUpToDate;

    @Column(
            name = "created_by",
            updatable = false,
            nullable = false
    )
    @CreatedBy
    private String createdBy;

    @Column(
            name = "created_date",
            nullable = false,
            updatable = false,
            columnDefinition = "DATETIME"
    )
    @CreatedDate
    private Timestamp createdDate;

    @Column(
            name = "updated_by",
            nullable = false
    )
    @LastModifiedBy
    private String updatedBy;

    @Column(
            name = "updated_date",
            nullable = false,
            columnDefinition = "DATETIME"
    )
    @LastModifiedDate
    private Timestamp updatedDate;

    @Column(
        name = "store_id",
        columnDefinition = "NVARCHAR(3)"
    )
    private String storeId;

    @PreUpdate
    public void onPreUpdate() {
        this.updatedBy = APPLICATION_NAME;
    }

    @PrePersist
    public void generateMembershipKey() {
        this.membershipKey = UUID.randomUUID().toString();
    }
}
