package ca.bestbuy.membership.accountdatamigration.processor;

import ca.bestbuy.membership.accountdatamigration.entity.AccountPartyKey;
import ca.bestbuy.membership.accountdatamigration.util.Constant;
import ca.bestbuy.membership.membershipdatamigration.entity.reltio.Entity;
import ca.bestbuy.membership.membershipdatamigration.entity.reltio.PartyKey;
import java.util.List;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
@Slf4j
public class AccountPartyKeyProcessor implements ItemProcessor<Entity, List<AccountPartyKey>> {

    @Override
    public List<AccountPartyKey> process(Entity entity) throws Exception {
        if (entity.getAttributes().getPartyKeys() == null) {
            log.debug("     Party key is null from entity, type:{}, names: {}, emails {}",
                    entity.getType(), entity.getAttributes().getFirstName(),
                    entity.getAttributes().getEmails());
            return null;
        }

        Optional<PartyKey> reltioPartyKey = entity.getAttributes().getPartyKeys().stream()
            .filter(PartyKey::isOv)
            .findFirst();

        if (reltioPartyKey.isEmpty()) {
            log.info("      isOv party key is empty, type:{}, names: {}, emails {}",
                    entity.getType(), entity.getAttributes().getFirstName(),
                    entity.getAttributes().getEmails());
            return null;
        }

        String partyKeyValue = reltioPartyKey.get().getValue();

        List<AccountPartyKey> accountPartyKeys = entity.getCrosswalks().stream()
            .filter(crosswalk -> Constant.ACCOUNT_SYSTEM_SOURCE.equals(crosswalk.getType()))
            .map(crosswalk -> {
                AccountPartyKey accountPartyKey = new AccountPartyKey();
                accountPartyKey.setPartyKey(partyKeyValue);
                accountPartyKey.setAccountKey(crosswalk.getValue());
                return accountPartyKey;
            }).toList();
        return accountPartyKeys.isEmpty() ? null : accountPartyKeys;
    }
}
