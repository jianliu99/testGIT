package ca.bestbuy.membership.membershipdatamigration.entity.jpa;


import java.math.BigDecimal;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class PaymentCalculation {

    private BigDecimal totalPayed;

    private Membership membership;
}
