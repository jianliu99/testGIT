package ca.bestbuy.membership.membershipdatamigration.config;

import ca.bestbuy.membership.membershipdatamigration.entity.jpa.Membership;
import jakarta.persistence.EntityManagerFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.database.JpaItemWriter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@Slf4j
public class WriterConfiguration {

    @Bean
    public ItemWriter<Membership> membershipWriter(EntityManagerFactory entityManagerFactory) {
        JpaItemWriter<Membership> writer = new JpaItemWriter<>();
        writer.setEntityManagerFactory(entityManagerFactory);

        return writer;
    }
}
