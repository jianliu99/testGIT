package ca.bestbuy.membership.accountdatamigration.config;

import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;

@Configuration
@EnableJpaRepositories(
        basePackages = {"ca.bestbuy.membership.accountdatamigration"},
        entityManagerFactoryRef = "accountEntityManagerFactory",
        transactionManagerRef = "accountTransactionManager"
)
public class AccountDataSourceConfig {

    @Bean(name = "accountDataSource")
    @ConfigurationProperties(prefix = "account.datasource")
    public DataSource accountDataSource() {
        return DataSourceBuilder.create().build();
    }

    @Bean(name = "accountEntityManagerFactory")
    public LocalContainerEntityManagerFactoryBean accountEntityManagerFactory(EntityManagerFactoryBuilder builder,
            @Qualifier("accountDataSource") DataSource accountDataSource) {
        return builder
                .dataSource(accountDataSource)
                .packages("ca.bestbuy.membership.accountdatamigration")
                .build();
    }
}
