package ca.bestbuy.membership.accountdatamigration.service;

import com.azure.storage.blob.BlobContainerClient;
import com.azure.storage.blob.BlobServiceClient;
import com.azure.storage.blob.models.BlobItem;
import java.sql.Timestamp;
import java.util.List;
import java.util.concurrent.Semaphore;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.StopWatch;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

@Slf4j
@Service
@AllArgsConstructor
public class AccountPartyKeyLoadServiceImpl implements AccountPartyKeyLoadService {

    private final JobLauncher jobLauncher;

    private Job loadAccountPartyKeyJob;

    private final BlobServiceClient blobServiceClient;

    @Value("${azure.blobStorage.container-name}")
    private String blobContainer;

    @Value("${azure.blobStorage.blob-name}")
    private String blobName;

    @Async
    public void processAccountPartyKeyLoad(Semaphore partyKeyLoadLock, String inputPath) {
        try {
            BlobContainerClient blobContainerClient = blobServiceClient.getBlobContainerClient(blobContainer);
            log.info("Azure blob path: {}", inputPath);

            String fullPath = blobName + inputPath;
            List<BlobItem> blobItemList = blobContainerClient.listBlobs().stream()
                    .filter(blobItem -> blobItem.getName().startsWith(fullPath)
                            && blobItem.getName().endsWith(".json.gz")).toList();

            if (CollectionUtils.isEmpty(blobItemList)) {
                log.info("No file exists in path: {}", fullPath);
                return;
            }
            StopWatch stopWatch = new StopWatch();
            stopWatch.start();
            log.info("******  ProcessAccountPartyKeyLoad job started.");
            for (BlobItem blobItem : blobItemList) {
                String relativePath = StringUtils.remove(blobItem.getName(), blobName);
                processJob(relativePath);
            }
            log.info("******  ProcessAccountPartyKeyLoad job completed, Time elapsed: {}", stopWatch);
            stopWatch.stop();
        } finally {
            partyKeyLoadLock.release();
        }
    }

    private void processJob(String fileExportName) {
        try {
            Timestamp jobStartTime = new Timestamp(System.currentTimeMillis());
            JobParameters jobParameters = createInitialJobParameterMap(jobStartTime, fileExportName);
            log.info("AccountPartyKeyLoad job [{}] started at {}", fileExportName, jobStartTime);
            JobExecution jobExecution = jobLauncher.run(loadAccountPartyKeyJob, jobParameters);

            BatchStatus batchStatus = jobExecution.getStatus();

            if (batchStatus == BatchStatus.COMPLETED) {
                Timestamp jobEndTime = new Timestamp(System.currentTimeMillis());
                log.info("AccountPartyKeyLoad job [{}] completed at {}", fileExportName, jobEndTime);
            } else {
                log.error("ProcessAccountPartyKeyLoad job [{}] did not complete", fileExportName);
            }
        } catch (Exception e) {
            log.error("Job [" + fileExportName + "] failed", e);
        }
    }

    private JobParameters createInitialJobParameterMap(Timestamp jobStartTime, String fileExportName) {
        return new JobParametersBuilder()
            .addLong("time", jobStartTime.getTime())
            .addString("fileExportName", fileExportName)
            .toJobParameters();
    }
}
