package ca.bestbuy.membership.membershipdatamigration.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PartyKey {

    private Integer membershipId;

    private String partyKey;

}
