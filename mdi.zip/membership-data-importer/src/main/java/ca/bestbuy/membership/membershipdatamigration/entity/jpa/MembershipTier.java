package ca.bestbuy.membership.membershipdatamigration.entity.jpa;

import static ca.bestbuy.membership.membershipdatamigration.util.Constant.APPLICATION_NAME;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import java.sql.Timestamp;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

@Data
@Builder
@Entity(name = "MembershipTier")
@Table(name = "membership_tier")
@NoArgsConstructor
@AllArgsConstructor
public class MembershipTier {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(
            name = "membership_tier_id",
            updatable = false,
            insertable = false,
            unique = true,
            columnDefinition = "TINYINT"
    )
    private Integer membershipTierId;

    @Enumerated(
            EnumType.STRING
    )
    @Column(
            name = "membership_tier_name",
            unique = true,
            nullable = false,
            columnDefinition = "VARCHAR(32)"
    )
    private MembershipTierName membershipTierName;

    @Enumerated(
            EnumType.STRING
    )
    @Column(
            name = "membership_tier_code",
            unique = true,
            nullable = false,
            columnDefinition = "VARCHAR(2)"
    )
    private MembershipTierCode membershipTierCode;

    @Column(
            name = "membership_tier_description",
            nullable = false,
            columnDefinition = "NVARCHAR(255)"
    )
    private String membershipTierDescription;

    @Column(
            name = "created_by",
            updatable = false,
            nullable = false
    )
    @CreatedBy
    private String createdBy;

    @Column(
            name = "created_date",
            nullable = false,
            updatable = false,
            columnDefinition = "DATETIME"
    )
    @CreatedDate
    private Timestamp createdDate;

    @Column(
            name = "updated_by",
            nullable = false
    )
    @LastModifiedBy
    private String updatedBy;

    @Column(
            name = "updated_date",
            nullable = false,
            columnDefinition = "DATETIME"
    )
    @LastModifiedDate
    private Timestamp updatedDate;

    @PreUpdate
    public void onPreUpdate() {
        this.updatedBy = APPLICATION_NAME;
    }
}