package ca.bestbuy.membership.accountdatamigration.service;

import static org.apache.commons.lang3.StringUtils.EMPTY;
import static org.apache.commons.lang3.StringUtils.isBlank;

import com.azure.storage.blob.BlobContainerClient;
import com.azure.storage.blob.BlobServiceClient;
import com.azure.storage.blob.models.BlobItem;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.StopWatch;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

@Slf4j
@Service
@RequiredArgsConstructor
public class AccountReportPostMigrationService {

    private final JobLauncher jobLauncher;

    private final Job accountReportPostMigrationJob;

    private final BlobServiceClient blobServiceClient;

    private final FileProcessingService fileProcessingService;
    @Value("${azure.blobStorage.container-name}")
    private String blobContainer;
    @Value("${azure.blobStorage.blob-name}")
    private String blobName;
    @Value("${account.report.base-path:/app/membership-data-importer/}")
    private String reportBasePath;
    @Value("${account.report.single-report-only: false}")
    private boolean isSingleReportOnly;

    @Async
    public void reportOnMigration(String inputPath) throws JobParametersInvalidException, JobExecutionAlreadyRunningException,
        JobRestartException, JobInstanceAlreadyCompleteException {
        BlobContainerClient blobContainerClient = blobServiceClient.getBlobContainerClient(blobContainer);
        log.info("Azure blob path: {}", inputPath);

        String fullPath = blobName + inputPath;
        List<BlobItem> blobItemList = blobContainerClient.listBlobs().stream()
                .filter(blobItem -> blobItem.getName().startsWith(fullPath)
                        && blobItem.getName().endsWith(".json.gz")).toList();

        if (CollectionUtils.isEmpty(blobItemList)) {
            log.info("No file exists in path: {}", fullPath);
            return;
        }
        StopWatch stopWatch = new StopWatch();
        stopWatch.start();
        log.info("******  ProcessAccountPartyKeyLoad job started.");
        for (BlobItem blobItem : blobItemList) {
            String relativePath = StringUtils.remove(blobItem.getName(), blobName);
            generateReport(relativePath);
        }
        log.info("******  ProcessAccountPartyKeyLoad job completed, Time elapsed: {}", stopWatch);
        try {
            String reportFilePath = isSingleReportOnly ? EMPTY : inputPath;
            fileProcessingService.compress(reportBasePath + reportFilePath);
        } catch (IOException e) {
            log.error("Failed to generate Account report", e);
        }
        log.info("******  Report has been generated.");
        stopWatch.stop();
    }

    private void generateReport(String fileExportName) {
        try {
            Timestamp jobStartTime = new Timestamp(System.currentTimeMillis());
            JobParameters jobParameters = createInitialJobParameterMap(jobStartTime, fileExportName);
            log.info("Account Party Key post migration job [{}] started at {}", fileExportName, jobStartTime);
            JobExecution jobExecution = jobLauncher.run(accountReportPostMigrationJob, jobParameters);

            BatchStatus batchStatus = jobExecution.getStatus();

            if (batchStatus == BatchStatus.COMPLETED) {
                Timestamp jobEndTime = new Timestamp(System.currentTimeMillis());
                log.info("Account Party Key post migration job [{}] completed at {}", fileExportName, jobEndTime);
            } else {
                log.error("Report job [{}] did not complete", fileExportName);
            }
        } catch (Exception e) {
            log.error("Job [" + fileExportName + "] failed", e);
        }
    }

    private JobParameters createInitialJobParameterMap(Timestamp jobStartTime, String fileExportName) {
        return new JobParametersBuilder()
                .addLong("time", jobStartTime.getTime())
                .addString("fileExportName", fileExportName)
                .toJobParameters();
    }
}
