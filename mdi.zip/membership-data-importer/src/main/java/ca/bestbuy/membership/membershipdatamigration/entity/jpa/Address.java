package ca.bestbuy.membership.membershipdatamigration.entity.jpa;

import static ca.bestbuy.membership.membershipdatamigration.util.Constant.APPLICATION_NAME;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.ForeignKey;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import java.sql.Timestamp;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Getter
@Setter
@Entity(name = "Address")
@Table(name = "address")
@ToString(exclude = {"membership"})
@EntityListeners(AuditingEntityListener.class)
public class Address {

    @ManyToOne
    @JoinColumn(
            name = "membership_id",
            referencedColumnName = "membership_id",
            nullable = false,
            foreignKey = @ForeignKey(
                    name = "FK_address_membership_id"
            )
    )
    private Membership membership;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(
            name = "address_id",
            updatable = false,
            insertable = false,
            unique = true,
            columnDefinition = "INT"
    )
    private Integer addressId;

    @OneToOne
    @JoinColumn(
            name = "address_type_id",
            referencedColumnName = "address_type_id",
            nullable = false,
            foreignKey = @ForeignKey(
                    name = "FK_address_type_id"
            )
    )
    private AddressType addressType;

    @Column(
            name = "address_line_1",
            nullable = false
    )
    private String addressLine1;

    @Column(
            name = "address_line_2"
    )
    private String addressLine2;

    @Column(
            name = "city",
            columnDefinition = "VARCHAR(60)"
    )
    private String city;

    @Column(
            name = "suite",
            columnDefinition = "VARCHAR(32)"
    )
    private String suite;

    @Column(
            name = "region_code",
            columnDefinition = "VARCHAR(8)",
            nullable = false
    )
    private String regionCode;

    @Column(
            name = "region_name",
            columnDefinition = "VARCHAR(32)",
            nullable = false
    )
    private String regionName;

    @Column(
            name = "country_code",
            columnDefinition = "VARCHAR(2)",
            nullable = false
    )
    private String countryCode;

    @Column(
            name = "country_name",
            columnDefinition = "VARCHAR(32)",
            nullable = false
    )
    private String countryName;

    @Column(
            name = "postal_code",
            columnDefinition = "VARCHAR(10)",
            nullable = false
    )
    private String postalCode;

    @Column(
            name = "phone_number",
            columnDefinition = "VARCHAR(15)"
    )
    private String phoneNumber;

    @Column(
            name = "created_by",
            updatable = false,
            nullable = false
    )
    @CreatedBy
    private String createdBy;

    @Column(
            name = "created_date",
            nullable = false,
            updatable = false,
            columnDefinition = "DATETIME"
    )
    @CreatedDate
    private Timestamp createdDate;

    @Column(
            name = "updated_by",
            nullable = false
    )
    @LastModifiedBy
    private String updatedBy;

    @Column(
            name = "updated_date",
            nullable = false,
            columnDefinition = "DATETIME"
    )
    @LastModifiedDate
    private Timestamp updatedDate;

    @PreUpdate
    public void onPreUpdate() {
        this.updatedBy = APPLICATION_NAME;
    }
}