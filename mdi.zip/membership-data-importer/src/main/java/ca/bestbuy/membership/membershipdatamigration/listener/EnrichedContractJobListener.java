package ca.bestbuy.membership.membershipdatamigration.listener;

import ca.bestbuy.membership.membershipdatamigration.processor.UpdateMemberIdProcessor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class EnrichedContractJobListener implements JobExecutionListener {

    private UpdateMemberIdProcessor processor;

    public EnrichedContractJobListener(UpdateMemberIdProcessor processor) {
        this.processor = processor;
    }

    @Override
    public void beforeJob(JobExecution jobExecution) {
        // Start the job with clean memberId cache
        log.info("Clearing memberId cache before starting the member id update job");
        processor.clearMemberIdCache();
    }

    @Override
    public void afterJob(JobExecution jobExecution) {
        // Clear the memberIds cache after populate member id job completes
        log.info("Clearing memberId cache after starting the member id update job");
        processor.clearMemberIdCache();
    }
}