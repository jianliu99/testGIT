package ca.bestbuy.membership.accountdatamigration.util;

public class Constant {

    private Constant() {}

    public static final String ACCOUNT_SYSTEM_SOURCE = "configuration/sources/AccountsDatabase";
    public static final String DEFAULT_COMPRESSED_REPORT_NAME = "account_migration_report";
}
