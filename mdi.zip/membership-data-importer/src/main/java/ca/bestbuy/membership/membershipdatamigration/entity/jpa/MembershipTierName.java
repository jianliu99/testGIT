package ca.bestbuy.membership.membershipdatamigration.entity.jpa;

public enum MembershipTierName {
    BEST_BUY_MEMBERSHIP,
    PILOT_AND_LEGACY,
    NATIONAL_LAUNCH,
    GSPADP,
    GSPPBT1,
    GSPPBT2,
    GSPPBT3,
    GSBMT1,
    GSBMT2,
    GSBMT3,
    BEST_BUY_PROTECTION_PLUS
}