package ca.bestbuy.membership.membershipdatamigration.processor;

import static ca.bestbuy.membership.membershipdatamigration.util.Constant.ENTITY_TYPE_INDIVIDUAL;
import static ca.bestbuy.membership.membershipdatamigration.util.Constant.MEMBERSHIP_SYSTEM_SOURCE;
import static ca.bestbuy.membership.membershipdatamigration.util.MigrationReportConstant.ADDRESS_LINE_1;
import static ca.bestbuy.membership.membershipdatamigration.util.MigrationReportConstant.ADDRESS_LINE_2;
import static ca.bestbuy.membership.membershipdatamigration.util.MigrationReportConstant.CITY;
import static ca.bestbuy.membership.membershipdatamigration.util.MigrationReportConstant.COUNTRY;
import static ca.bestbuy.membership.membershipdatamigration.util.MigrationReportConstant.EMAIL;
import static ca.bestbuy.membership.membershipdatamigration.util.MigrationReportConstant.FIRST_NAME;
import static ca.bestbuy.membership.membershipdatamigration.util.MigrationReportConstant.LAST_NAME;
import static ca.bestbuy.membership.membershipdatamigration.util.MigrationReportConstant.PARTY_KEY;
import static ca.bestbuy.membership.membershipdatamigration.util.MigrationReportConstant.PHONE;
import static ca.bestbuy.membership.membershipdatamigration.util.MigrationReportConstant.REGION_NAME;
import static ca.bestbuy.membership.membershipdatamigration.util.MigrationReportConstant.REPORT_STATUS_FAIL;
import static ca.bestbuy.membership.membershipdatamigration.util.MigrationReportConstant.ZIP;
import static ca.bestbuy.membership.membershipdatamigration.util.ReltioSyncReportUtil.validateCustomerAttributes;
import static java.lang.Math.random;
import static org.springframework.util.CollectionUtils.isEmpty;

import ca.bestbuy.membership.membershipdatamigration.entity.reltio.Entity;
import ca.bestbuy.membership.membershipdatamigration.entity.report.MigrationReportItem;
import ca.bestbuy.membership.membershipdatamigration.entity.report.ReltioCustomer;
import ca.bestbuy.membership.membershipdatamigration.entity.report.ValidationResult;
import ca.bestbuy.membership.membershipdatamigration.entity.report.jpa.Customer;
import ca.bestbuy.membership.membershipdatamigration.mapper.CustomerMapper;
import ca.bestbuy.membership.membershipdatamigration.repository.CustomerRepository;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.BiConsumer;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@RequiredArgsConstructor
public class ReportPostCustomerMigrationProcessor implements ItemProcessor<Entity, List<MigrationReportItem>> {

    private final CustomerRepository customerRepository;

    private final CustomerMapper customerMapper;

    @Value("${validation-report.daily:false}")
    private boolean reportDaily;

    @Value("${validation-report.coverage:0.2}")
    private double reportCoverage;

    @Override
    public List<MigrationReportItem> process(Entity entity) throws Exception {
        List<MigrationReportItem> report = new ArrayList<>();

        if (toBeValidated()) {
            if (!ENTITY_TYPE_INDIVIDUAL.equals(entity.getType())) {
                return null;
            }
            String reltioPartyKey = entity.getAttributes().getPartyKeys().get(0).getValue();

            // Fetch the corresponding membership record
            Map<String, ReltioCustomer> reltioCustomerAttributeMap = customerMapper.getCustomerMap(entity, reportDaily, MEMBERSHIP_SYSTEM_SOURCE);
            if (!isEmpty(reltioCustomerAttributeMap)) {
                for (Map.Entry<String, ReltioCustomer> crosswalkEntry : reltioCustomerAttributeMap.entrySet()) {
                    MigrationReportItem reportItem = generateReltioSyncReportItem(
                        customerRepository.getCustomer(crosswalkEntry.getKey()), // key = membershipId
                        crosswalkEntry.getValue(), // value = reltioCustomer
                        reltioPartyKey
                    );

                    report.add(reportItem);
                }
            } else {
                MigrationReportItem reportItem = new MigrationReportItem();
                reportItem.setReltioPartyKey(reltioPartyKey);
                reportItem.setPartyKeyStatus(REPORT_STATUS_FAIL);
                reportItem.setError("No membership db crosswalk or membership id found for entity");
                report.add(reportItem);
            }
        }

        return report;
    }

    private MigrationReportItem generateReltioSyncReportItem(Customer membershipDbCustomer, ReltioCustomer reltioCustomer, String reltioPartyKey) {
        MigrationReportItem reportItem = new MigrationReportItem();
        reportItem.setReltioPartyKey(reltioPartyKey);

        if (membershipDbCustomer == null) {
            reportItem.setPartyKeyStatus(REPORT_STATUS_FAIL);
            reportItem.setError("No corresponding membership found in membership db for entity");
        } else {
            reportItem.setMembershipPartyKey(membershipDbCustomer.getPartyKey());
            reportItem.setMembershipId(membershipDbCustomer.getMembershipId());

            validateAndSetStatus(PARTY_KEY, membershipDbCustomer.getPartyKey(), reltioPartyKey, " ",
                reportItem, MigrationReportItem::setPartyKeyStatus);
            validateAndSetStatus(FIRST_NAME, membershipDbCustomer.getFirstName(), reltioCustomer.getFirstName(), reportItem.getError(),
                reportItem, MigrationReportItem::setFirstNameStatus);
            validateAndSetStatus(LAST_NAME, membershipDbCustomer.getLastName(), reltioCustomer.getLastName(), reportItem.getError(),
                reportItem, MigrationReportItem::setLastNameStatus);
            validateAndSetStatus(EMAIL, membershipDbCustomer.getEmailAddress(), reltioCustomer.getEmail(), reportItem.getError(),
                reportItem, MigrationReportItem::setEmailStatus);
            validateAndSetStatus(PHONE, membershipDbCustomer.getPhoneNumber(), reltioCustomer.getPhoneNumber(), reportItem.getError(),
                reportItem, MigrationReportItem::setPhoneStatus);

            ca.bestbuy.membership.membershipdatamigration.entity.report.jpa.Address membershipDbAddress = membershipDbCustomer.getAddress();
            ca.bestbuy.membership.membershipdatamigration.entity.report.Address reltioAddress = reltioCustomer.getAddress();
            if (reportDaily && reltioAddress != null) {
                validateAndSetStatus(ADDRESS_LINE_1, membershipDbAddress.getAddressLine1(), reltioAddress.getAddressLine1(), reportItem.getError(),
                    reportItem, MigrationReportItem::setAddressStatus);
                validateAndSetStatus(ADDRESS_LINE_2, membershipDbAddress.getAddressLine2(), reltioAddress.getAddressLine2(), reportItem.getError(),
                    reportItem, MigrationReportItem::setAddressStatus);
                validateAndSetStatus(CITY, membershipDbAddress.getCity(), reltioAddress.getCity(), reportItem.getError(),
                    reportItem, MigrationReportItem::setAddressStatus);
                validateAndSetStatus(REGION_NAME, membershipDbAddress.getRegionName(), reltioAddress.getStateProvince(), reportItem.getError(),
                    reportItem, MigrationReportItem::setAddressStatus);
                validateAndSetStatus(COUNTRY, membershipDbAddress.getCountryName(), reltioAddress.getCountry(), reportItem.getError(),
                    reportItem, MigrationReportItem::setAddressStatus);
                validateAndSetStatus(ZIP, membershipDbAddress.getPostalCode(), reltioAddress.getZip(), reportItem.getError(),
                    reportItem, MigrationReportItem::setAddressStatus);
            }
        }

        return reportItem;
    }

    private void validateAndSetStatus(String attribute, String value1, String value2, String comment,
                                      MigrationReportItem reportItem, BiConsumer<MigrationReportItem, String> setStatus) {
        ValidationResult validationResult = validateCustomerAttributes(attribute, value1, value2, comment);
        setStatus.accept(reportItem, validationResult.getStatus());
        reportItem.setError(validationResult.getComment());
    }

    /**
     * Random validation on percentage of the data in the reltio export file.
     */
    private boolean toBeValidated() {
        return random() < reportCoverage;
    }
}
