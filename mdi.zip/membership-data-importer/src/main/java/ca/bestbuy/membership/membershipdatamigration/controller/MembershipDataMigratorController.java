package ca.bestbuy.membership.membershipdatamigration.controller;

import ca.bestbuy.membership.membershipdatamigration.service.MemberIdUpdateDataService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequiredArgsConstructor
public class MembershipDataMigratorController {

    private final MemberIdUpdateDataService memberIdUpdateDataService;


    @GetMapping("/populate-member-id")
    public ResponseEntity<String> populateMemberId()
            throws JobInstanceAlreadyCompleteException, JobExecutionAlreadyRunningException, JobParametersInvalidException, JobRestartException {
        log.info("Starting populate member id batch process");
        memberIdUpdateDataService.enrichContractData();
        return ResponseEntity.ok("populate member id batch process started successfully.");
    }
}