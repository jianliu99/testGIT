package ca.bestbuy.membership.membershipdatamigration.util;

import java.math.BigDecimal;
import lombok.experimental.UtilityClass;

@UtilityClass
public class Constant {

    public static final String APPLICATION_NAME = "membershipDataImporter";

    public static final BigDecimal averageNumberOfDaysInYear = BigDecimal.valueOf(365.25);

    public static final BigDecimal averageNumberOfDaysInMonth = BigDecimal.valueOf(30.4375);

    public static final String MEMBERSHIP_STATUS_CODES_CACHE_NAME = "membershipStatusCodes";

    public static final String MEMBERSHIP_SYSTEM_SOURCE = "configuration/sources/MembershipSystem";

    public static final String ENTITY_TYPE_INDIVIDUAL = "configuration/entityTypes/Individual";
}
