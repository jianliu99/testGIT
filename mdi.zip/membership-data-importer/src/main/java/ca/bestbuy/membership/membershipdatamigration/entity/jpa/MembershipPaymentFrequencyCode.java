package ca.bestbuy.membership.membershipdatamigration.entity.jpa;

public enum MembershipPaymentFrequencyCode {
    M, // Monthly
    A, // Annual
    LS // Lump Sum
}