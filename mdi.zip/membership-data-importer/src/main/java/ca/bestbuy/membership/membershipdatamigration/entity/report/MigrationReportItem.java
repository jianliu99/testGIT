package ca.bestbuy.membership.membershipdatamigration.entity.report;

import lombok.Data;

@Data
public class MigrationReportItem {
    private String reltioPartyKey;
    private String membershipPartyKey;
    private String membershipId;
    private String partyKeyStatus;
    private String firstNameStatus;
    private String lastNameStatus;
    private String phoneStatus;
    private String emailStatus;
    private String addressStatus;
    private String error;
}
