package ca.bestbuy.membership.membershipdatamigration.config;

import java.util.ArrayList;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.item.Chunk;
import org.springframework.batch.item.ItemWriter;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class SuspendedAndCanceledLumpSumsCollector<T> implements ItemWriter<T> {

    private final List<T> suspendedMemberships = new ArrayList<>();

    @Override
    public void write(Chunk<? extends T> memberships) {
        suspendedMemberships.addAll(memberships.getItems());
    }

    public List<T> getSuspendedMemberships() {
        log.info(" **** Suspended Membership Cache size = {}", suspendedMemberships.size());
        return suspendedMemberships;
    }

    public void clearSuspendedMemberships() {
        suspendedMemberships.clear();
    }
}