package ca.bestbuy.membership.membershipdatamigration.entity.jpa;

public enum MembershipPaymentFrequencyName {
    MONTHLY,
    ANNUAL,
    LUMP_SUM
}
