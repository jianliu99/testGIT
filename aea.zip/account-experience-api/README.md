# Account Experience API

Technology | Version
--- | ---
Java | OpenJDK17
Spring Boot | 3.1.4

## Service Routes

### /health

Displays the current health status of the application for operational purposes.

##### Example Requests
```
curl -H "Accept: application/json" https://account-experience-api-stay-dmz-cdm-dev.apps.zcqa3ged.centralus.aroapp.io/health -v -k
curl -H "Accept: application/json" http://localhost:9999/health -v
```

## How To Run

1. Clone this BitBucket repo: https://bitbucketdev.ca.bestbuy.com/scm/cdm/account-experience-api.git


2. Make sure the application builds and passes all tests.

   ```
   **/:account-experience-api $mvn clean install
   ```

## Deployment

To deploy changes to OpenShift platform:
1. Check that all changes are done according to GitFlow strategy (follow this documentation https://code.bestbuy.com/wiki/display/MEMBERSHIP/GitFlow+Based+Development)

2. Edit build-account-experience-api-{env_name}.yaml file (https://bitbucketdev.ca.bestbuy.com/projects/GITOPS_STAY/repos/stay-apps-build/browse/deploy/account-experience-api)
   and update spec.source.git.ref with desired branch name

3. Sync updated configuration via ArgoCD (https://argocd-apps.apps.zcqa3ged.centralus.aroapp.io/applications/stay-apps-build)

4. Trigger the pipeline to deploy/promote desired build depending on environment:

Environment | Pipeline                                                                                                                                     | Testing
--- |----------------------------------------------------------------------------------------------------------------------------------------------| ---
Dev | https://console-openshift-console.apps.zcqa3ged.centralus.aroapp.io/k8s/ns/stay-apps-build/buildconfigs/build-account-experience-api-app-dev | https://account-experience-api-stay-dmz-cdm-dev.apps.zcqa3ged.centralus.aroapp.io
QA | https://console-openshift-console.apps.zcqa3ged.centralus.aroapp.io/k8s/ns/stay-apps-build/buildconfigs/build-account-experience-api-app-qa  | https://account-experience-api-stay-dmz-cdm-qa.apps.zcqa3ged.centralus.aroapp.io
Rel | https://console-openshift-console.apps.zcqa3ged.centralus.aroapp.io/k8s/ns/stay-apps-build/buildconfigs/build-account-experience-api-app-rel | https://account-experience-api-stay-dmz-cdm-rel.apps.zcqa3ged.centralus.aroapp.io

## Links

- [Application Documentation](https://code.bestbuy.com/wiki/display/MEMBERSHIP/Account+Experience+API)
- Service Overview Page: [Account Experience API - Service Overview](https://code.bestbuy.com/wiki/display/TSUP/Account+Experience+API+-+Service+Overview)
- Application Landing Page: [Account Experience API](https://code.bestbuy.com/wiki/display/TSUP/Account+Experience+API)