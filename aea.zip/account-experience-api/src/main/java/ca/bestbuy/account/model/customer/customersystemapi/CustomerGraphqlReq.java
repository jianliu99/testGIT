package ca.bestbuy.account.model.customer.customersystemapi;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class CustomerGraphqlReq {
    CustomerModel customerInput;
}
