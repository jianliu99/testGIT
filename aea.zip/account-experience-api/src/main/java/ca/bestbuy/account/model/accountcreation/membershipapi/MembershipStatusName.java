package ca.bestbuy.account.model.accountcreation.membershipapi;

public enum MembershipStatusName {
    ACTIVE,
    SUSPENDED,
    CANCELLED
}
