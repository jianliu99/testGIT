package ca.bestbuy.account.model.customer.customersystemapi;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class GraphQlBodyRequest {
    private String query;

    private Object variables;
}
