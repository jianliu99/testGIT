package ca.bestbuy.account.service.account;

import static org.springframework.http.MediaType.APPLICATION_JSON;

import ca.bestbuy.account.exception.ServerErrorException;
import ca.bestbuy.account.model.account.accountsystemapi.AddressResponse;
import ca.bestbuy.account.model.account.accountsystemapi.CreateAddressRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatusCode;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;

@Slf4j
@Service
@RequiredArgsConstructor
public class AccountSystemApiServiceImpl implements AccountSystemApiService {

    @Value("${bbyc.accountSystemApi.createAddressPath:/v1/accounts/{accountKey}/addresses}")
    private final String createAddressPath;

    private final WebClient accountSystemApiWebClient;

    @Override
    public AddressResponse createAddress(String accountKey, CreateAddressRequest createAddressRequest) {
        AddressResponse addressResponse = accountSystemApiWebClient
            .post()
            .uri(uriBuilder -> uriBuilder.path(createAddressPath).build(accountKey))
            .contentType(APPLICATION_JSON)
            .body(BodyInserters.fromValue(createAddressRequest))
            .retrieve()
            .onStatus(HttpStatusCode::isError, response -> {
                log.error("Exception thrown by AccountSystemApi.createAddress");
                return handleClientError(response);
            })
            .bodyToMono(AddressResponse.class)
            .block();

        if (addressResponse == null) {
            throw new ServerErrorException("Received null response from Account System API");
        }

        return addressResponse;
    }

    private Mono<Throwable> handleClientError(final ClientResponse response) {
        return response.bodyToMono(String.class)
            .flatMap(body -> Mono.error(new WebClientResponseException(
                response.statusCode().value(),
                response.statusCode().toString(),
                response.headers().asHttpHeaders(),
                body.getBytes(),
                null
            )));
    }
}
