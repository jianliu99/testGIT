package ca.bestbuy.account.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenApiConfig {
    @Bean
    public OpenAPI availabilityOpenApi() {
        return new OpenAPI()
                .info(new Info()
                        .title("Account Experience API")
                        .description("This app exposes APIs pertaining to account details"));
    }
}
