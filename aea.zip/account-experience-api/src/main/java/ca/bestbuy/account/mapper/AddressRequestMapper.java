package ca.bestbuy.account.mapper;

import ca.bestbuy.account.model.account.AddressRequest;
import ca.bestbuy.account.model.account.accountsystemapi.CreateAddressRequest;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface AddressRequestMapper {

    @Mapping(source = "defaultAddress", target = "isDefaultAddress")
    CreateAddressRequest addressRequestToCreateAddressRequest(final AddressRequest addressRequest);
}
