package ca.bestbuy.account.exception;

/**
 * Exception thrown when dealing with locales.
 */
public class LocaleException extends RuntimeException {

    public LocaleException(String message, Throwable cause) {
        super(message, cause);
    }

    public LocaleException(String message) {
        super(message);
    }
}
