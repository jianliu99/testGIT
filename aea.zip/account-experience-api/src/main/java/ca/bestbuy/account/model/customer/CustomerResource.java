package ca.bestbuy.account.model.customer;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CustomerResource {
    private String partyKey;
    private String firstName;
    private String lastName;
}
