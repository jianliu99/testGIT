package ca.bestbuy.account.service.account;

import ca.bestbuy.account.mapper.AddressRequestMapper;
import ca.bestbuy.account.mapper.AddressResourceMapper;
import ca.bestbuy.account.model.account.AddressRequest;
import ca.bestbuy.account.model.account.AddressResource;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class AddressResourceServiceImpl implements AddressResourceService {

    private final AccountSystemApiService accountSystemApiService;
    private final AddressRequestMapper addressRequestMapper;
    private final AddressResourceMapper addressResourceMapper;

    @Override
    public AddressResource createAddress(String accountKey, AddressRequest addressRequest) {
        return addressResourceMapper.addressResponseToAddressResource(
            accountSystemApiService.createAddress(accountKey, addressRequestMapper.addressRequestToCreateAddressRequest(addressRequest)));
    }
}
