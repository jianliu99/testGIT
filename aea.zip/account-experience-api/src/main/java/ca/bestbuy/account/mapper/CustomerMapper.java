package ca.bestbuy.account.mapper;

import ca.bestbuy.account.model.account.AddressRequest;
import ca.bestbuy.account.model.accountcreation.CustomerAccountRequest;
import ca.bestbuy.account.model.customer.customersystemapi.CustomerGraphqlReq;
import ca.bestbuy.account.model.customer.customersystemapi.CustomerAddressModel;
import java.util.Collections;
import java.util.List;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface CustomerMapper {
    @Mapping(source = "email", target = "customerInput.email")
    @Mapping(source = "firstName", target = "customerInput.firstName")
    @Mapping(source = "lastName", target = "customerInput.lastName")
    @Mapping(source = "accountKey", target = "customerInput.sourceId")
    @Mapping(source = "locale", target = "customerInput.language")
    @Mapping(source = "partyKey", target = "customerInput.partyKey")
    @Mapping(constant = "AccountSystem", target = "customerInput.sourceSystem")
    @Mapping(source = "addresses", target = "customerInput.addresses")
    CustomerGraphqlReq toCustomerGraphqlReq(final CustomerAccountRequest customerAccountRequest);

    @Mapping(source = "addressLine1", target = "addressLine1")
    @Mapping(source = "addressLine2", target = "addressLine2")
    @Mapping(source = "postalCode", target = "postalCode")
    @Mapping(source = "city", target = "city")
    @Mapping(source = "provinceCode", target = "regionCode")
    @Mapping(source = "provinceName", target = "regionName")
    @Mapping(source = "countryCode", target = "countryCode")
    @Mapping(expression = "java(org.apache.commons.lang3.StringUtils.upperCase(addressRequest.getCountryName()))", target = "countryName")
    @Mapping(source = "phoneNumber", target = "phoneNumber")
    CustomerAddressModel addressRequestToCustomerAddressModel(AddressRequest addressRequest);

    default List<CustomerAddressModel> mapAddresses(List<AddressRequest> addresses) {
        return addresses == null ? Collections.emptyList() :
                addresses.stream().map(this::addressRequestToCustomerAddressModel).toList();
    }
}
