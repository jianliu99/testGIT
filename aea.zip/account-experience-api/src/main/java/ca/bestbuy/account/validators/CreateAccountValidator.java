package ca.bestbuy.account.validators;

import ca.bestbuy.account.model.accountcreation.CustomerAccountRequest;
import ca.bestbuy.account.exception.ValidationException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@RequiredArgsConstructor
@Component
public class CreateAccountValidator extends AbstractValidator<CustomerAccountRequest> {

    private final EmailAddressValidator emailAddressValidator;
    private final CustomerNameValidator customerNameValidator;

    @Override
    protected void doValidation(CustomerAccountRequest toValidate) throws ValidationException {
        emailAddressValidator.validate(toValidate.getEmail());
        customerNameValidator.validate(toValidate.getFirstName());
        customerNameValidator.validate(toValidate.getLastName());
    }
}
