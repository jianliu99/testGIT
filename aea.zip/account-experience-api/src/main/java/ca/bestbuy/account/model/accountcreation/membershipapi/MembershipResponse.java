package ca.bestbuy.account.model.accountcreation.membershipapi;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This class holds the membership representation from MDB.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MembershipResponse {

    private String membershipKey;

    private Integer memberId;

    private MembershipStatusName membershipStatus;

    private String globalContractId;

    private String zuoraProductRatePlanId;

    private String coveredSku;

    private String membershipStartDate;

    private String membershipEndDate;
}
