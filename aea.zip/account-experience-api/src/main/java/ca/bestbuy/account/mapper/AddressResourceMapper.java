package ca.bestbuy.account.mapper;

import ca.bestbuy.account.model.account.AddressResource;
import ca.bestbuy.account.model.account.accountsystemapi.AddressResponse;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface AddressResourceMapper {

    @Mapping(source = "defaultAddress", target = "isDefaultAddress")
    AddressResource addressResponseToAddressResource(final AddressResponse addressResponse);
}
