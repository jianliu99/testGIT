package ca.bestbuy.account.config;

import static org.springframework.http.HttpHeaders.CONTENT_TYPE;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;
import io.netty.handler.ssl.SslContext;
import io.netty.handler.ssl.SslContextBuilder;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.security.KeyStore;
import javax.net.ssl.KeyManagerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.reactive.ClientHttpConnector;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.util.ResourceUtils;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.netty.http.client.HttpClient;

@Configuration
public class WebClientsConfig {

    @Value("${bbyc.customerSystemApi.baseUri}")
    private String customerSystemApiUri;

    @Value("${bbyc.accountSystemApi.baseUri}")
    private String accountSystemApiUri;

    @Value("${bbyc.membershipSystemApi.baseUri}")
    private String membershipSystemApiUri;

    @Value("${ssl.keystore.location}")
    private String keyStoreLocation;

    @Value("${ssl.keystore.password}")
    private String keyStorePassword;

    @Value("${ssl.keystore.type}")
    private String keyStoreType;

    @Value("${bbyc.webclient.connection.timeout.milliseconds: 10000}")
    private int webClientConnectionTimeOut;

    @Value("${bbyc.customerSystemApi.sslEnabled}")
    private boolean customerSystemApiSslEnabled;

    @Value("${bbyc.accountSystemApi.sslEnabled}")
    private boolean accountSystemApiSslEnabled;

    @Value("${bbyc.membershipSystemApi.sslEnabled}")
    private boolean membershipSystemApiSslEnabled;

    @Bean
    public WebClient customerSystemApiWebClient(final WebClient.Builder webClientBuilder) throws IOException, GeneralSecurityException {
        return webClientBuilder
                .baseUrl(customerSystemApiUri)
                .defaultHeader(CONTENT_TYPE, APPLICATION_JSON_VALUE)
                .clientConnector(createClientHttpConnectorWithSslContext(customerSystemApiSslEnabled))
                .build();
    }

    @Bean
    public WebClient accountSystemApiWebClient(final WebClient.Builder webClientBuilder) throws GeneralSecurityException, IOException {
        return webClientBuilder
                .baseUrl(accountSystemApiUri)
                .defaultHeader(CONTENT_TYPE, APPLICATION_JSON_VALUE)
                .clientConnector(createClientHttpConnectorWithSslContext(accountSystemApiSslEnabled))
                .build();
    }

    @Bean
    public WebClient membershipSystemApiWebClient(final WebClient.Builder webClientBuilder) throws GeneralSecurityException, IOException {
        return webClientBuilder
                .baseUrl(membershipSystemApiUri)
                .defaultHeader(CONTENT_TYPE, APPLICATION_JSON_VALUE)
                .clientConnector(createClientHttpConnectorWithSslContext(membershipSystemApiSslEnabled))
                .build();
    }

    private ClientHttpConnector createClientHttpConnectorWithSslContext(boolean sslEnabled) throws IOException, GeneralSecurityException {
        if (sslEnabled) {
            SslContext sslContext = buildSslContext();
            HttpClient client = HttpClient.create().secure(spec -> spec.sslContext(sslContext));
            return new ReactorClientHttpConnector(client);
        } else {
            return new ReactorClientHttpConnector();
        }
    }

    private SslContext buildSslContext() throws IOException, GeneralSecurityException {
        KeyStore keyStore = KeyStore.getInstance(keyStoreType);
        keyStore.load(new FileInputStream(ResourceUtils.getFile(keyStoreLocation)), keyStorePassword.toCharArray());

        KeyManagerFactory keyManagerFactory = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
        keyManagerFactory.init(keyStore, keyStorePassword.toCharArray());

        return SslContextBuilder.forClient().keyManager(keyManagerFactory).build();
    }
}