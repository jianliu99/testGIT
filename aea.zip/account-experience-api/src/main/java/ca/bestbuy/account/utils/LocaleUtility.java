package ca.bestbuy.account.utils;

import ca.bestbuy.account.exception.LocaleException;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Component;

import java.util.Locale;

/**
 * This utility is responsible for actions with locales. E.g. Mapping from locales (en, en-CA) to Java locales (en, en_CA) and getting setting them
 * for the request.
 */
@Component
public class LocaleUtility {

    public static final String CANADA_ENGLISH = "en-ca";
    public static final String CANADA_FRENCH = "fr-ca";
    public static final String CANADA_ENGLISH_LEGACY = "en-CA";
    public static final String CANADA_FRENCH_LEGACY = "fr-CA";
    public static final String LOG_MESSAGE_LOCALE_STRING_FORMAT_INVALID = "Locale string is not formatted correctly. Should be xx-XX.";
    public static final String LOG_MESSAGE_INVALID_LOCALE_OBJECT = "Required parameter is not found in Locale object.";
    private static final Logger LOGGER = LoggerFactory.getLogger(LocaleUtility.class);

    /**
     * return a {@link Locale} base on BestBuy customized locale
     */
    public static Locale getLocale(String customizedLocale) {
        return StringUtils.equals(customizedLocale, LocaleUtility.CANADA_FRENCH) ? Locale.CANADA_FRENCH : Locale.CANADA;
    }

    /**
     * Sets the passed request field's locale to the locale holder.
     *
     * @param locale Must be of the pattern "xx" or "xx-XX" if not null; Country component is optional.
     */
    public void setLocaleFromRequestField(String locale) {
        Locale resolvedLocale;

        // Default, if the request field is either not set or set to an empty String, is English without a country
        // Note, however, that we do not want an invalid locale string be turned into the default locale of English
        if (StringUtils.isEmpty(locale)) {
            resolvedLocale = Locale.ENGLISH;
        } else {
            resolvedLocale = getLocaleFromString(locale, false);
        }

        LOGGER.info("Setting request locale to: {}", resolvedLocale);
        LocaleContextHolder.setLocale(resolvedLocale);
    }

    /**
     * Sets the passed url locale to the locale holder.
     *
     * @param locale Must be of the pattern "xx-xx" or "xx-XX".
     */
    public void setLocaleFromUrlString(String locale) {
        Locale parsedLocale = getLocaleFromString(locale, true);

        LOGGER.info("Setting request locale to: {}", parsedLocale);
        LocaleContextHolder.setLocale(parsedLocale);
    }

    /**
     * Parses the passed locale to the locale holder.
     *
     * @param locale Must be of the pattern "xx", "xx-xx", or "xx-XX"; Country component is optional. The validity of the Language or the Country
     */
    public Locale getLocaleFromString(String locale, boolean requireCountry) {
        if (StringUtils.isBlank(locale)) {
            throw new LocaleException(LOG_MESSAGE_LOCALE_STRING_FORMAT_INVALID);
        }

        String[] langAndCountry = locale.split("-");

        if (requireCountry && langAndCountry.length != 2) {
            throw new LocaleException(LOG_MESSAGE_LOCALE_STRING_FORMAT_INVALID);
        }

        if (langAndCountry.length == 2 && StringUtils.isNotBlank(langAndCountry[0]) && StringUtils.isNotBlank(langAndCountry[1])) {
            return new Locale(langAndCountry[0], langAndCountry[1]);
        } else if (langAndCountry.length == 1 && StringUtils.isNotBlank(langAndCountry[0])) {
            return new Locale(langAndCountry[0]);
        } else {
            throw new LocaleException(LOG_MESSAGE_LOCALE_STRING_FORMAT_INVALID);
        }
    }

    /**
     * Formats locale parameters to a String in the format of "xx-XX"; Country component is optional. The validity of the Language or the Country
     * {@code String}s are not checked. Country is defaulted to Local.CANADA if not set.
     *
     * @param locale Must at least contain a language
     */
    public String getFormattedStringFromLocale(Locale locale) {
        if (StringUtils.isEmpty(locale.getLanguage())) {
            throw new LocaleException(LOG_MESSAGE_INVALID_LOCALE_OBJECT);
        }

        if (StringUtils.isEmpty(locale.getCountry())) {
            return locale.getLanguage() + "-" + Locale.CANADA.getCountry();
        }

        return locale.getLanguage() + "-" + locale.getCountry();
    }
}
