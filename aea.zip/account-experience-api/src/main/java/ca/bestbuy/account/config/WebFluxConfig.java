package ca.bestbuy.account.config;

import static org.springframework.http.HttpMethod.GET;
import static org.springframework.http.HttpMethod.OPTIONS;
import static org.springframework.http.HttpMethod.POST;
import static org.springframework.http.HttpMethod.PUT;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.util.StringUtils;
import org.springframework.web.reactive.config.CorsRegistry;
import org.springframework.web.reactive.config.EnableWebFlux;
import org.springframework.web.reactive.config.WebFluxConfigurer;

@Configuration
@EnableWebFlux
public class WebFluxConfig implements WebFluxConfigurer {

    private static final int MAX_AGE = 3600;

    @Value("${cors.allow-origins:*}")
    private String allowOrigins;

    @Override
    public void addCorsMappings(CorsRegistry registry) {

        registry.addMapping("/**")
                .allowedOriginPatterns(StringUtils.commaDelimitedListToStringArray(allowOrigins))
                .allowCredentials(true)
                .allowedMethods(GET.name(), POST.name(), PUT.name(), OPTIONS.name())
                .maxAge(MAX_AGE);
    }
}