package ca.bestbuy.account.service.membership;

import static org.springframework.http.MediaType.APPLICATION_JSON;

import ca.bestbuy.account.exception.ServerErrorException;
import ca.bestbuy.account.model.accountcreation.membershipapi.GetMembershipRequest;
import ca.bestbuy.account.model.accountcreation.membershipapi.MembershipResponse;
import ca.bestbuy.account.model.accountcreation.membershipapi.MembershipStatusName;
import java.time.Duration;
import java.time.temporal.ChronoUnit;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatusCode;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;

@Slf4j
@Service
@RequiredArgsConstructor
public class MembershipSystemApiServiceImpl implements MembershipSystemApiService {

    @Value("${bbyc.membershipSystemApi.membershipsPath:/v1/memberships}")
    private final String membershipsPath;

    @Value("${bbyc.customerSystemApi.timeout:5}")
    private final Long membershipSystemApiTimeout;

    private final WebClient membershipSystemApiWebClient;

    @Override
    public Mono<MembershipResponse> getMemberships(GetMembershipRequest getMembershipRequest) {
        log.info("Retrieving membership via customer-system-api.");
        return membershipSystemApiWebClient.post()
                .uri(uriBuilder -> uriBuilder.path(membershipsPath).build())
                .contentType(APPLICATION_JSON)
                .body(BodyInserters.fromValue(getMembershipRequest))
                .retrieve()
                .onStatus(httpStatusCode -> httpStatusCode.value() == 204,
                        response -> {
                            log.warn("Membership doesn't exist");
                            return Mono.error(new ServerErrorException("Membership doesn't exist"));
                        })
                .onStatus(HttpStatusCode::isError, response -> {
                    log.warn("Handling errors from membership-system-api: {}", response);
                    return response.bodyToMono(String.class)
                            .flatMap(body -> Mono.error(new WebClientResponseException(
                                    response.statusCode().value(),
                                    response.statusCode().toString(),
                                    response.headers().asHttpHeaders(),
                                    body.getBytes(),
                                    null
                            )));
                })
                .bodyToFlux(MembershipResponse.class)
                .timeout(Duration.of(membershipSystemApiTimeout, ChronoUnit.SECONDS))
                .switchIfEmpty(Mono.empty())
                .filter(member -> MembershipStatusName.ACTIVE.equals(member.getMembershipStatus()))
                .reduce((maxEndDateMember, currentMember) -> {
                    String maxEndDate = maxEndDateMember.getMembershipEndDate();
                    String currentEndDate = currentMember.getMembershipEndDate();
                    if (StringUtils.isBlank(maxEndDate)) {
                        return maxEndDateMember;
                    } else if (StringUtils.isBlank(currentEndDate)) {
                        return currentMember;
                    }
                    return maxEndDate.compareTo(currentEndDate) > 0 ? maxEndDateMember : currentMember;
                }).flatMap(this::validateMembershipResponse);
    }

    private Mono<MembershipResponse> validateMembershipResponse(MembershipResponse membershipResponse) {
        log.info("Validating membership response.");
        return Optional.ofNullable(membershipResponse).map(Mono::just)
                .orElseGet(() -> Mono.error(new ServerErrorException("membership-system-api is not responding with update customer data payload")));
    }
}
