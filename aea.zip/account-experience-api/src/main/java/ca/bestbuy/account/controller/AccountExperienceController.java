package ca.bestbuy.account.controller;

import static ca.bestbuy.account.utils.Constants.EMPTY_CUSTOMER;
import static ca.bestbuy.account.utils.Constants.EMPTY_MEMBERSHIP;

import ca.bestbuy.account.enums.ErrorCode;
import ca.bestbuy.account.exception.BadRequestException;
import ca.bestbuy.account.exception.ServerErrorException;
import ca.bestbuy.account.exception.ValidationException;
import ca.bestbuy.account.model.account.AddressRequest;
import ca.bestbuy.account.model.account.AddressResource;
import ca.bestbuy.account.model.accountcreation.CustomerAccountRequest;
import ca.bestbuy.account.model.accountcreation.CustomerInfoResource;
import ca.bestbuy.account.model.accountcreation.membershipapi.GetMembershipRequest;
import ca.bestbuy.account.model.accountcreation.membershipapi.MembershipResponse;
import ca.bestbuy.account.model.customer.CustomerResource;
import ca.bestbuy.account.model.customer.customersystemapi.CustomerModel;
import ca.bestbuy.account.service.account.AddressResourceService;
import ca.bestbuy.account.service.customer.CustomerSystemApiService;
import ca.bestbuy.account.service.membership.MembershipSystemApiService;
import ca.bestbuy.account.validators.CreateAccountValidator;
import ca.bestbuy.account.validators.EmailAddressValidator;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/v1")
public class AccountExperienceController {

    private final CreateAccountValidator createAccountValidator;
    private final EmailAddressValidator emailAddressValidator;
    private final CustomerSystemApiService customerSystemApiService;
    private final AddressResourceService addressResourceService;
    private final MembershipSystemApiService membershipSystemApiService;

    /**
     * Update customer profile in Reltio, partyKey is mandatory.
     */
    @PutMapping("/customer")
    public Mono<CustomerResource> updateCustomer(@Valid @RequestBody final CustomerAccountRequest customerAccountRequest) {
        log.info("Received UPDATE customer request.");
        Mono<CustomerModel> updateCustomerDto = customerSystemApiService.updateCustomer(customerAccountRequest);
        return updateCustomerDto.map(customerModel -> CustomerResource.builder()
                .partyKey(customerModel.getPartyKey())
                .firstName(customerModel.getFirstName())
                .lastName(customerModel.getLastName())
                .build());
    }

    @PostMapping("/accounts/{accountKey}/addresses")
    public AddressResource createAddress(@PathVariable final String accountKey,
                                         @Valid @RequestBody final AddressRequest addressRequest) {

        return addressResourceService.createAddress(accountKey, addressRequest);
    }

    /**
     * If partyKey is presented in request, updateCustomer will be called, otherwise createCustomer will be called.
     * This method zip-combines two api calls to downstream system apis:
     *  invoke customer-system-api to create or update customer profile in Reltio and return partyKey
     *  invoke membership-system-api to get optional memberId and membershipKey
     */
    @PostMapping(value = "/createAccount")
    public Mono<CustomerInfoResource> createOrUpdateAccount(@RequestBody final CustomerAccountRequest customerAccountRequest) {
        try {
            Mono<CustomerModel> customerMono;
            if (StringUtils.isBlank(customerAccountRequest.getPartyKey())) {
                log.info("Received CREATE account request");
                createAccountValidator.validate(customerAccountRequest);
                customerMono = customerSystemApiService.createCustomer(customerAccountRequest)
                        .defaultIfEmpty(EMPTY_CUSTOMER)
                        .onErrorReturn(EMPTY_CUSTOMER);
            } else {
                log.info("Received UPDATE account request");
                emailAddressValidator.validate(customerAccountRequest.getEmail());
                customerMono = customerSystemApiService.updateCustomer(customerAccountRequest)
                        .defaultIfEmpty(EMPTY_CUSTOMER)
                        .onErrorReturn(EMPTY_CUSTOMER);
            }

            GetMembershipRequest getMembershipRequest = GetMembershipRequest.builder().emailAddress(customerAccountRequest.getEmail()).build();
            Mono<MembershipResponse> membershipMono = membershipSystemApiService
                    .getMemberships(getMembershipRequest)
                    .defaultIfEmpty(EMPTY_MEMBERSHIP)
                    .onErrorReturn(EMPTY_MEMBERSHIP);

            if (StringUtils.isBlank(customerAccountRequest.getPartyKey())) {
                return Mono.zip(customerMono, membershipMono)
                        .map(tuple -> {
                            CustomerModel customerModel = tuple.getT1();
                            MembershipResponse membership = tuple.getT2();

                            return CustomerInfoResource.builder()
                                    .partyKey(customerModel.getPartyKey())
                                    .memberId(membership.getMemberId() == null ? null : membership.getMemberId().toString())
                                    .membershipKey(membership.getMembershipKey() == null ? null : membership.getMembershipKey())
                                    .build();
                });
            } else {
                // We don't wait and collect party key for update scenario since it's passed in from request,
                // as the call to Reltio through message-broker is time-consuming, it will increase consumer's waiting time if we collect both response from downstream .
                // customerMono (update) will be a "fire and forget" call.
                customerMono.subscribe();
                return membershipMono.map(membership -> CustomerInfoResource.builder()
                        .partyKey(customerAccountRequest.getPartyKey())
                        .memberId(membership.getMemberId() == null ? null : membership.getMemberId().toString())
                        .membershipKey(membership.getMembershipKey() == null ? null : membership.getMembershipKey())
                        .build());
            }
        } catch (ValidationException e) {
            log.error("Failed to validate createAccount request.", e);
            throw new BadRequestException(ErrorCode.BAD_REQUEST.name(), e);
        } catch (WebClientResponseException e) {
            log.error("Failed to call system api.", e);
            throw new ServerErrorException("Failed to call system api.");
        }
    }

    @GetMapping(value = "/getCustomer")
    public Flux<CustomerResource> getCustomer(@RequestParam String customerPartyKey) {
        log.info("Received GET customer request");
        try {
            Flux<CustomerModel> customerModelsFlux = customerSystemApiService.getCustomer(customerPartyKey);
            return customerModelsFlux.map(customerModel -> CustomerResource.builder()
                .partyKey(customerModel.getPartyKey())
                .firstName(customerModel.getFirstName())
                .lastName(customerModel.getLastName())
                .build());
        } catch (WebClientResponseException | ServerErrorException e) {
            log.error("Failed to call system api.", e);
            throw new ServerErrorException("Failed to call system api.");
        }
    }
}
