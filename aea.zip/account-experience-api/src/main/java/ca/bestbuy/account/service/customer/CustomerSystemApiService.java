package ca.bestbuy.account.service.customer;

import ca.bestbuy.account.model.accountcreation.CustomerAccountRequest;
import ca.bestbuy.account.model.customer.CustomerResource;
import ca.bestbuy.account.model.customer.customersystemapi.CustomerModel;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface CustomerSystemApiService {
    Mono<CustomerModel> updateCustomer(final CustomerAccountRequest customerAccountRequest);

    Mono<CustomerModel> createCustomer(final CustomerAccountRequest customerAccountRequest);

    Flux<CustomerModel> getCustomer(final String partyKey);
}
