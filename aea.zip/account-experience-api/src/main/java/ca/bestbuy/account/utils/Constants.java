package ca.bestbuy.account.utils;

import ca.bestbuy.account.model.accountcreation.membershipapi.MembershipResponse;
import ca.bestbuy.account.model.customer.customersystemapi.CustomerModel;
import lombok.experimental.UtilityClass;

@UtilityClass
public class Constants {
    public static final String ERROR = "error";
    public static final String MESSAGE = "message";
    public static final String BAD_REQUEST_MSG = "Bad request";

    public static final CustomerModel EMPTY_CUSTOMER = CustomerModel.builder().build();

    public static final MembershipResponse EMPTY_MEMBERSHIP = MembershipResponse.builder().build();

}
