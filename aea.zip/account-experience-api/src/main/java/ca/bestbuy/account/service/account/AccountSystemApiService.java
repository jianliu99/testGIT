package ca.bestbuy.account.service.account;


import ca.bestbuy.account.model.account.accountsystemapi.AddressResponse;
import ca.bestbuy.account.model.account.accountsystemapi.CreateAddressRequest;

public interface AccountSystemApiService {

    AddressResponse createAddress(String accountKey, CreateAddressRequest createAddressRequest);
}
