package ca.bestbuy.account.validators;

import ca.bestbuy.account.exception.ValidationException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Validator that will validate customer name, validation will fail if input is empty or does not match name pattern.
 */
@Component
@Slf4j
public class CustomerNameValidator extends AbstractValidator<String> {

    private static final String NAME_REGEX_EXPRESSION_PATTERN = "^[a-zA-Z\u00C0-\u017F\\s,-.']{1,40}$";
    private static final Pattern NAME_PATTERN = Pattern.compile(NAME_REGEX_EXPRESSION_PATTERN);

    @Override
    protected void doValidation(String input) throws ValidationException {
        Matcher matcher = NAME_PATTERN.matcher(input);
        if (StringUtils.isBlank(input) || !matcher.matches()) {
            throw new ValidationException("Input name in not valid format.");
        }
    }
}
