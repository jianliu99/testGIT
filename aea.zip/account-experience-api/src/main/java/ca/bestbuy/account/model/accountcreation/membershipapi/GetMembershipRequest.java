package ca.bestbuy.account.model.accountcreation.membershipapi;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class GetMembershipRequest {
    private String emailAddress;
}
