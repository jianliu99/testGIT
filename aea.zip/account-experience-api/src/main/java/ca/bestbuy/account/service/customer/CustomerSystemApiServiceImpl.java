package ca.bestbuy.account.service.customer;

import static ca.bestbuy.account.model.account.AddressType.SHIPPING;

import static java.time.temporal.ChronoUnit.MILLIS;
import static java.time.temporal.ChronoUnit.SECONDS;
import static org.apache.commons.lang3.StringUtils.isBlank;

import ca.bestbuy.account.exception.BadRequestException;
import ca.bestbuy.account.exception.ServerErrorException;
import ca.bestbuy.account.mapper.CustomerMapper;
import ca.bestbuy.account.model.accountcreation.CustomerAccountRequest;
import ca.bestbuy.account.model.customer.customersystemapi.CustomerAddressModel;
import ca.bestbuy.account.model.customer.customersystemapi.CustomerGraphqlReq;
import ca.bestbuy.account.model.customer.customersystemapi.CustomerGraphqlResp;
import ca.bestbuy.account.model.customer.customersystemapi.CustomerGraphqlResp.CustomerData;
import ca.bestbuy.account.model.customer.customersystemapi.CustomerModel;
import ca.bestbuy.account.model.customer.customersystemapi.ErrorResponse;
import ca.bestbuy.account.model.customer.customersystemapi.GetCustomerGraphqlReq;
import ca.bestbuy.account.model.customer.customersystemapi.GraphQlBodyRequest;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.TimeoutException;

import ca.bestbuy.account.model.customer.customersystemapi.PartyKeyModel;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatusCode;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.util.retry.Retry;

@Slf4j
@Service
@RequiredArgsConstructor
public class CustomerSystemApiServiceImpl implements CustomerSystemApiService {

    private static final String UPDATE_CUSTOMER_SCHEMA_FILE_NAME = "updateCustomer";
    private static final String CREATE_CUSTOMER_SCHEMA_FILE_NAME = "createCustomer";
    private static final String GET_CUSTOMER_SCHEMA_FILE_NAME = "getCustomer";
    private static final String GENERIC_ERROR = "Customer System API is not responding with customer data payload";
    private static final double JITTER_FACTOR = 0.75;
    private static final String EXCEEDED_MAX_RETRIES = "Failed to process after max retries";

    private final WebClient customerSystemApiWebClient;

    @Value("${bbyc.customerSystemApi.graphqlPath:/graphql}")
    private final String customerSystemApiGraphqlPath;

    @Value("${bbyc.customerSystemApi.timeout:5}")
    private final Long customerSystemApiTimeout;

    private final CustomerMapper customerMapper;

    private final Map<String, String> customerQueryMap;

    @Value("${bbyc.customerSystemApi.retry.maxAttempts:2}")
    private final Integer retryMaxAttempts;

    @Value("${bbyc.customerSystemApi.retry.delayInSeconds:500}")
    private final Long retryDelayInMillis;

    @Override
    public Mono<CustomerModel> updateCustomer(final CustomerAccountRequest customerAccountRequest) {
        if (isBlank(customerAccountRequest.getPartyKey())) {
            throw new BadRequestException("PartyKey should not be empty");
        }

        log.info("Updating customer profile in Reltio via customer-system-api.");
        CustomerGraphqlReq customerGraphqlReq = getCustomerGraphqlReq(customerAccountRequest);
        GraphQlBodyRequest graphQlRequest = buildUpdateCustomerGraphQlRequest(customerGraphqlReq);
        return customerSystemApiWebClient.post()
            .uri(uriBuilder -> uriBuilder.path(customerSystemApiGraphqlPath).build())
            .bodyValue(graphQlRequest)
            .retrieve()
            .onStatus(HttpStatusCode::is4xxClientError, this::handleClientError)
            .onStatus(HttpStatusCode::is5xxServerError, response -> {
                log.error(response.toString());
                return Mono.error(new ServerErrorException("DownStream server error: " + response.statusCode()));
            })
            .bodyToMono(CustomerGraphqlResp.class)
            .timeout(Duration.of(customerSystemApiTimeout, SECONDS))
            .onErrorResume(TimeoutException.class, ex -> {
                log.error(ex.getMessage());
                throw new ServerErrorException("Response timeout: " + ex.getMessage());
            })
            .retryWhen(Retry.backoff(retryMaxAttempts, Duration.of(retryDelayInMillis, MILLIS))
                    .filter(ServerErrorException.class::isInstance)
                    .jitter(JITTER_FACTOR)
                    .doAfterRetry(signal -> log.info("Retry update customer counts: {}", signal.totalRetries()))
                    .onRetryExhaustedThrow((retryBackoffSpec, retrySignal) -> {
                        log.error(EXCEEDED_MAX_RETRIES);
                        throw new ServerErrorException(EXCEEDED_MAX_RETRIES);
                    })
            )
            .flatMap(this::validateUpdateCustomerResponse);
    }

    @Override
    public Mono<CustomerModel> createCustomer(final CustomerAccountRequest customerAccountRequest) {
        log.info("Creating customer profile in Reltio via customer-system-api.");
        CustomerGraphqlReq customerGraphqlReq = getCustomerGraphqlReq(customerAccountRequest);

        GraphQlBodyRequest graphQlRequest = buildCreateCustomerGraphQlRequest(customerGraphqlReq);
        return customerSystemApiWebClient.post()
            .uri(uriBuilder -> uriBuilder.path(customerSystemApiGraphqlPath).build())
            .bodyValue(graphQlRequest)
            .retrieve()
            .onStatus(HttpStatusCode::is4xxClientError, this::handleClientError)
            .onStatus(HttpStatusCode::is5xxServerError, response -> {
                log.error(response.toString());
                return Mono.error(new ServerErrorException("DownStream server error: " + response.statusCode()));
            })
            .bodyToMono(CustomerGraphqlResp.class)
            .timeout(Duration.of(customerSystemApiTimeout, SECONDS))
            .onErrorResume(TimeoutException.class, ex -> {
                log.error(ex.getMessage());
                throw new ServerErrorException("Response timeout: " + ex.getMessage());
            })
            .retryWhen(Retry.backoff(retryMaxAttempts, Duration.of(retryDelayInMillis, MILLIS))
                    .filter(ServerErrorException.class::isInstance)
                    .jitter(JITTER_FACTOR)
                    .doAfterRetry(signal -> log.info("Retry create customer counts: {}", signal.totalRetries()))
                    .onRetryExhaustedThrow((retryBackoffSpec, retrySignal) -> {
                        log.error(EXCEEDED_MAX_RETRIES);
                        throw new ServerErrorException(EXCEEDED_MAX_RETRIES);
                    })
            )
            .flatMap(this::validateCreateCustomerResponse);
    }

    /**
     * Only set default shipping address in request
     */
    private CustomerGraphqlReq getCustomerGraphqlReq(final CustomerAccountRequest customerAccountRequest) {
        final CustomerGraphqlReq customerGraphqlReq = customerMapper.toCustomerGraphqlReq(customerAccountRequest);

        List<CustomerAddressModel> shippingAddresses = new ArrayList<>();
        Optional.ofNullable(customerAccountRequest.getAddresses())
            .flatMap(addressRequests -> addressRequests.stream()
                .filter(addressRequest -> addressRequest.isDefaultAddress() && SHIPPING.equals(addressRequest.getAddressType()))
                .findFirst()
            )
            .ifPresent(defaultShippingAddress -> {
                customerGraphqlReq.getCustomerInput().setPhoneNumber(defaultShippingAddress.getPhoneNumber());
                customerGraphqlReq.getCustomerInput().setPhoneExtension(defaultShippingAddress.getPhoneNumberExtension());
                shippingAddresses.add(customerMapper.addressRequestToCustomerAddressModel(defaultShippingAddress));
            });
        customerGraphqlReq.getCustomerInput().setAddresses(shippingAddresses);

        log.info("Sending Customer Graphql Request, {}", customerGraphqlReq);

        return customerGraphqlReq;
    }

    private GraphQlBodyRequest buildUpdateCustomerGraphQlRequest(final CustomerGraphqlReq customerGraphqlReq) {
        GraphQlBodyRequest graphQlRequest = new GraphQlBodyRequest();
        graphQlRequest.setQuery(customerQueryMap.get(UPDATE_CUSTOMER_SCHEMA_FILE_NAME));
        graphQlRequest.setVariables(customerGraphqlReq);
        return graphQlRequest;
    }

    private GraphQlBodyRequest buildCreateCustomerGraphQlRequest(final CustomerGraphqlReq customerGraphqlReq) {
        GraphQlBodyRequest graphQlRequest = new GraphQlBodyRequest();
        graphQlRequest.setQuery(customerQueryMap.get(CREATE_CUSTOMER_SCHEMA_FILE_NAME));
        graphQlRequest.setVariables(customerGraphqlReq);
        return graphQlRequest;
    }

    private Mono<Throwable> handleClientError(final ClientResponse response) {
        log.warn("Handling errors from customer-system-api: {}", response.statusCode());
        return response.bodyToMono(String.class)
            .flatMap(body -> Mono.error(new WebClientResponseException(
                response.statusCode().value(),
                response.statusCode().toString(),
                response.headers().asHttpHeaders(),
                body.getBytes(),
                null
            )));
    }

    private Mono<CustomerModel> validateUpdateCustomerResponse(CustomerGraphqlResp customerResp) {
        log.info("Validating update customer response.");
        return Optional.ofNullable(customerResp)
                .map(CustomerGraphqlResp::getData)
                .map(CustomerData::getUpdateCustomer)
                .map(customerModel -> {
                    log.info("Successfully updated customer profile in Reltio via customer-system-api.");
                    return Mono.just(customerModel);
                })
                .orElseGet(() -> {
                List<ErrorResponse> errorResponses = Optional.ofNullable(customerResp).map(CustomerGraphqlResp::getErrors)
                    .orElseThrow(() -> {
                        log.error(GENERIC_ERROR);
                        return new RuntimeException(GENERIC_ERROR);
                    });
                log.error("Error response returned from customer-system-api: {}", errorResponses);
                return Mono.error(new ServerErrorException(errorResponses.toString()));
            });
    }

    private Mono<CustomerModel> validateCreateCustomerResponse(CustomerGraphqlResp customerResp) {
        log.info("Validating create customer response.");
        return Optional.ofNullable(customerResp)
                .map(CustomerGraphqlResp::getData)
                .map(CustomerData::getCreateCustomer)
                .map(customerModel -> {
                    log.info("Successfully created customer profile in Reltio via customer-system-api.");
                    return Mono.just(customerModel);
                })
                .orElseGet(() -> {
                List<ErrorResponse> errorResponses = Optional.ofNullable(customerResp).map(CustomerGraphqlResp::getErrors)
                    .orElseThrow(() -> {
                        log.error(GENERIC_ERROR);
                        return new RuntimeException(GENERIC_ERROR);
                    });
                log.error("Error response returned from customer-system-api: {}", errorResponses);
                return Mono.error(new ServerErrorException(errorResponses.toString()));
            });
    }

    @Override
    public Flux<CustomerModel> getCustomer(final String partyKey) {
        log.info("Retrieving customer profile in Reltio via customer-system-api.");

        PartyKeyModel partyKeyModel = PartyKeyModel.builder().partyKey(partyKey).build();
        GetCustomerGraphqlReq getCustomerGraphqlReq = GetCustomerGraphqlReq.builder().queryInput(partyKeyModel).build();

        GraphQlBodyRequest graphQlRequest = buildGetCustomerGraphQlRequest(getCustomerGraphqlReq);

        return customerSystemApiWebClient.post()
            .uri(uriBuilder -> uriBuilder.path(customerSystemApiGraphqlPath).build())
            .bodyValue(graphQlRequest)
            .retrieve()
            .onStatus(HttpStatusCode::is4xxClientError, this::handleClientError)
            .onStatus(HttpStatusCode::is5xxServerError, response -> {
                log.error(response.toString());
                return Mono.error(new ServerErrorException("DownStream server error: " + response.statusCode()));
            })
            .bodyToMono(CustomerGraphqlResp.class)
            .timeout(Duration.of(customerSystemApiTimeout, SECONDS))
            .onErrorResume(TimeoutException.class, ex -> {
                log.error(ex.getMessage());
                throw new ServerErrorException("Response timeout: " + ex.getMessage());
            })
            .retryWhen(Retry.backoff(retryMaxAttempts, Duration.of(retryDelayInMillis, MILLIS))
                .filter(ServerErrorException.class::isInstance)
                .jitter(JITTER_FACTOR)
                .doAfterRetry(signal -> log.info("Retry create customer counts: {}", signal.totalRetries()))
                .onRetryExhaustedThrow((retryBackoffSpec, retrySignal) -> {
                    log.error(EXCEEDED_MAX_RETRIES);
                    throw new ServerErrorException(EXCEEDED_MAX_RETRIES);
                })
            ).flatMapMany(this::validateGetCustomerResponse);

    }

    private Flux<CustomerModel> validateGetCustomerResponse(CustomerGraphqlResp customerResp) {
        log.info("Validating get customer response.");
        return Optional.ofNullable(customerResp)
            .map(CustomerGraphqlResp::getData)
            .map(CustomerData::getGetCustomers)
            .map(customerModel -> {
                log.info("Successfully get customer profile in Reltio via customer-system-api.");
                return Flux.just(customerModel);
            })
            .orElseGet(() -> {
                List<ErrorResponse> errorResponses = Optional.ofNullable(customerResp).map(CustomerGraphqlResp::getErrors)
                    .orElseThrow(() -> {
                        log.error(GENERIC_ERROR);
                        return new RuntimeException(GENERIC_ERROR);
                    });
                log.error("Error response returned from customer-system-api: {}", errorResponses);
                return Flux.error(new ServerErrorException(errorResponses.toString()));
            });
    }

    private GraphQlBodyRequest buildGetCustomerGraphQlRequest(final GetCustomerGraphqlReq getCustomerGraphqlReq) {
        GraphQlBodyRequest graphQlRequest = new GraphQlBodyRequest();
        graphQlRequest.setQuery(customerQueryMap.get(GET_CUSTOMER_SCHEMA_FILE_NAME));
        graphQlRequest.setVariables(getCustomerGraphqlReq);
        return graphQlRequest;
    }
}
