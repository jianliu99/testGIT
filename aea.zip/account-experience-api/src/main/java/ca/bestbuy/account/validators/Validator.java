package ca.bestbuy.account.validators;

import ca.bestbuy.account.exception.ValidationException;

/**
 * Interface for each BbycValidator to implement.
 */
public interface Validator<T> {

    /**
     * Validate the given object.
     *
     * @param toValidate The object to validate.
     * @throws ValidationException Exception thrown when given object is invalid.
     */
    void validate(T toValidate) throws ValidationException;
}
