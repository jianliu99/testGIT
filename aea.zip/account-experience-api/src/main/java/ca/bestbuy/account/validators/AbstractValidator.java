package ca.bestbuy.account.validators;

import ca.bestbuy.account.exception.ValidationException;
import lombok.extern.slf4j.Slf4j;

/**
 * Validator abstract class to do default null check
 *
 * @param <T> the type of object to validate
 */
@Slf4j
public abstract class AbstractValidator<T> implements Validator<T> {

    @Override
    public void validate(T toValidate) throws ValidationException {
        if (toValidate == null) {
            log.debug("Validation failed because the input is null.");
            throw new ValidationException("Validator was passed null object.");
        }
        doValidation(toValidate);
    }

    protected abstract void doValidation(T toValidate) throws ValidationException;
}
