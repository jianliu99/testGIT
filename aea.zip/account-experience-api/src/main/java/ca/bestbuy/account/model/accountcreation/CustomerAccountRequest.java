package ca.bestbuy.account.model.accountcreation;

import ca.bestbuy.account.model.account.AddressRequest;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(Include.NON_NULL)
public class CustomerAccountRequest {

    private String email;
    private String firstName;
    private String lastName;
    private String locale;
    private String accountKey;
    private String partyKey;

    private List<AddressRequest> addresses;
}
