package ca.bestbuy.account.enums;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

/**
 * Map an error message to error code
 */
public enum ErrorCode {
    USER_IS_LOCKED("User account is locked"),
    USER_IS_DISABLED("User is disabled"),
    USER_IS_CREDENTIALSEXPIRED("User credentials have expired"),
    MULTI_STATUS("Multi Status"),
    BAD_CREDENTIALS("Bad credentials"),
    BAD_REQUEST("Bad Request"),
    CHALLENGE_REQUIRED("Challenge required"),
    SESSION_TIMEOUT("Session Timeout"),
    NOT_FOUND("Not Found"),
    ERROR("Error"),
    INVALID_TOKEN("Invalid token"),
    EXPIRED_TOKEN("Expired token"),
    PASSWORD_PREVIOUSLY_USED("Previously used password"),
    PASSWORD_BLACKLISTED("Blacklisted Password"),
    PASSWORD_BASIC_CRITERIA_FAILED("Password basic criteria not met"),
    INSUFFICIENT_PERMISSIONS("Insufficient permissions"),
    ALREADY_EXISTS("Resource already exists");

    private static final Map<String, ErrorCode> errorCodeValues = new HashMap<>();
    private static final Logger LOGGER = LoggerFactory.getLogger(ErrorCode.class);

    static {
        for (ErrorCode value : values()) {
            errorCodeValues.put(value.errorCodeValue, value);
        }
    }

    private final String errorCodeValue;

    ErrorCode(String errorCodeValue) {
        this.errorCodeValue = errorCodeValue;
    }

    /**
     * Parses any string to a ErrorCode.
     *
     * @param errorValue value of scope to parse.
     * @return Parsed ErrorCode.
     */
    public static ErrorCode fromValue(String errorValue) {
        ErrorCode errorCode = errorCodeValues.get(errorValue);
        if (errorCode != null) {
            return errorCode;
        }

        return ErrorCode.ERROR;
    }

    /**
     * @param errorName name of scope to parse.
     */
    public static ErrorCode from(String errorName) {
        try {
            return ErrorCode.valueOf(errorName);
        } catch (IllegalArgumentException e) {
            LOGGER.warn("Handling unknown error: {} as {}.", errorName, ErrorCode.ERROR.name(), e);
            return ErrorCode.ERROR;
        }
    }

    /**
     * Returns this ErrorCode as a friendly string.
     *
     * @return string representation of this error code.
     */
    @Override
    public String toString() {
        return errorCodeValue;
    }
}
