package ca.bestbuy.account.exception;

import static ca.bestbuy.account.utils.Constants.ERROR;
import static org.springframework.http.HttpStatus.BAD_REQUEST;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@Slf4j
@RestControllerAdvice
public class ControllerAdvice {

    @ExceptionHandler(value = {BadRequestException.class})
    @ResponseStatus(BAD_REQUEST)
    public Map<String, Object> handleBadRequestException(BadRequestException ex) {
        log.error("Handling BadRequestException and IllegalArgumentException {}. Client responded with HTTP BAD_REQUEST", ex.getMessage());
        return Map.of(
            ERROR, ex.getMessage()
        );
    }

    @ExceptionHandler(value = {MethodArgumentNotValidException.class})
    @ResponseStatus(BAD_REQUEST)
    public Map<String, Object> handleMethodArgumentNotValidException(MethodArgumentNotValidException ex) {
        Map<String, Object> errorMap = new HashMap<>();
        if (ex.getBindingResult().hasFieldErrors()) {
            List<String> fieldErrorsMessages = ex.getBindingResult().getFieldErrors().stream()
                .map(fieldError -> String.format("%s: %s", fieldError.getField(), fieldError.getDefaultMessage()))
                .filter(Objects::nonNull)
                .toList();
            log.error("Handling MethodArgumentNotValidException. Client responded with HTTP BAD_REQUEST. Field errors: {}", fieldErrorsMessages);
            errorMap.put(ERROR, fieldErrorsMessages);
        }
        return errorMap;
    }
}
