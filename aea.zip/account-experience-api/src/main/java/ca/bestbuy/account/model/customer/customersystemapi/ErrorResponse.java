package ca.bestbuy.account.model.customer.customersystemapi;

import lombok.Builder;
import lombok.Data;
import lombok.ToString;

@Data
@Builder
@ToString
public class ErrorResponse {

    private String message;

    private Extensions extensions;

    @Data
    @Builder
    @ToString
    public static class Extensions {
        private String classification;
    }
}
