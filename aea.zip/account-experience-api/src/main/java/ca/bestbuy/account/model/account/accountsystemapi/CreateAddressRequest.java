package ca.bestbuy.account.model.account.accountsystemapi;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_EMPTY;

import ca.bestbuy.account.model.account.AddressType;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@JsonInclude(NON_EMPTY)
public class CreateAddressRequest {

    private String addressLine1;

    private String addressLine2;

    private String postalCode;

    private String provinceCode;

    private String city;

    private String suite;

    private String provinceName;

    private String countryCode;

    private String countryName;

    private String phoneNumber;

    private String phoneNumberExtension;

    @JsonProperty(value = "isDefaultAddress")
    private boolean isDefaultAddress;

    private AddressType addressType;

    private String addressNickname;
}
