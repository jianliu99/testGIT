package ca.bestbuy.account.model.customer.customersystemapi;

import java.util.List;
import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class UpdateCustomerGraphqlResp {

    private UpdateCustomerData data;
    private List<ErrorResponse> errors;
    @Data
    @Builder
    public static class UpdateCustomerData {
        private CustomerModel updateCustomer;
    }
}
