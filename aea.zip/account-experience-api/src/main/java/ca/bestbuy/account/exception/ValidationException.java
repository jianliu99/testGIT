package ca.bestbuy.account.exception;

public class ValidationException extends Exception {

    /**
     * ValidationException with a message and cause.
     *
     * @param message Message to use with the exception
     * @param cause   Inner exception that caused the exception
     */
    public ValidationException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * ValidationException with a message.
     *
     * @param message Message to use with the exception.
     */
    public ValidationException(String message) {
        super(message);
    }
}
