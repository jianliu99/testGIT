package ca.bestbuy.account.model.account;

import java.util.Arrays;
import java.util.Objects;

public enum AddressType {

    SHIPPING,
    BILLING,
    OTHER;

    public static AddressType fromName(String nameFrom) {
        return Arrays.stream(AddressType.values())
            .filter(addressType -> Objects.equals(addressType.name(), nameFrom))
            .findFirst().orElse(null);
    }
}
