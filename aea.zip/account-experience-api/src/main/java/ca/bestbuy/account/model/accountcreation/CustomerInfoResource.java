package ca.bestbuy.account.model.accountcreation;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CustomerInfoResource {

    private String partyKey;
    private String memberId;
    private String membershipKey;
}
