package ca.bestbuy.account.model.account.accountsystemapi;

import ca.bestbuy.account.model.account.AddressType;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class AddressResponse {

    private String addressKey;

    private String addressLine1;

    private String addressLine2;

    private String postalCode;

    private String city;

    private String suite;

    private String provinceCode;

    private String provinceName;

    private String countryCode;

    private String countryName;

    private String phoneNumber;

    private String phoneNumberExtension;

    @JsonProperty(value = "isDefaultAddress")
    private boolean isDefaultAddress;

    private AddressType addressType;

    private String addressNickname;
}
