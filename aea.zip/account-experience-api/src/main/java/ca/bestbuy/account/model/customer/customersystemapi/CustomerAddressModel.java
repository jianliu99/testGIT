package ca.bestbuy.account.model.customer.customersystemapi;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CustomerAddressModel {

    private String addressLine1;
    private String addressLine2;
    private String postalCode;
    private String city;
    private String regionCode;
    private String regionName;
    private String countryCode;
    private String countryName;
    private String phoneNumber;
    private String suite;
}
