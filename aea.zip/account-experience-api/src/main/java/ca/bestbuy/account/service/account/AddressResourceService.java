package ca.bestbuy.account.service.account;

import ca.bestbuy.account.model.account.AddressRequest;
import ca.bestbuy.account.model.account.AddressResource;

public interface AddressResourceService {

    AddressResource createAddress(String accountKey, AddressRequest addressRequest);
}
