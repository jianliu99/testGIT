package ca.bestbuy.account.service.membership;

import ca.bestbuy.account.model.accountcreation.membershipapi.GetMembershipRequest;
import ca.bestbuy.account.model.accountcreation.membershipapi.MembershipResponse;
import reactor.core.publisher.Mono;

public interface MembershipSystemApiService {
     Mono<MembershipResponse> getMemberships(GetMembershipRequest getMembershipRequest);
}
