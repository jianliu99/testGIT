package ca.bestbuy.account.config;

import static java.nio.charset.StandardCharsets.UTF_8;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.util.FileCopyUtils;

@Configuration
@Slf4j
public class GraphqlSchemaConfig {

    @Value("${bbyc.customerSystemApi.graphqlPath:/graphql}")
    private String graphqlPath;
    @Bean
    public Map<String, String> customerQueryMap() throws IOException {

        Map<String, String> queries = new HashMap<>();
        PathMatchingResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
        Resource[] resources = resolver.getResources(graphqlPath + "/*.graphql");
        for (Resource resource: resources) {
            String queryName = FilenameUtils.removeExtension(resource.getFilename());
            log.info("Loading graphql file {}", queryName);
            queries.put(queryName, new String(FileCopyUtils.copyToByteArray(resource.getInputStream()), UTF_8));
        }

        return queries;
    }
}
