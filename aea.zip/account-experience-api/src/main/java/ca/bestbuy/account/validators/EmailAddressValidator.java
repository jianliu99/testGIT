package ca.bestbuy.account.validators;

import ca.bestbuy.account.exception.ValidationException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Validator for email addresses
 */
@Slf4j
@Component
public class EmailAddressValidator implements Validator<String> {

    public static final String EMAIL_REGEX_PATTERN = "^\\w+([-.]\\w+)*@[A-Za-z0-9]+([-.][A-Za-z0-9]+)*\\.[A-Za-z]{2,}$";
    public static final String EMAIL_REGEX_VALIDATION_MESSAGE_INVALID_EMAIL_ADDRESS = "Invalid email address format.";
    public static final String EMAIL_REGEX_VALIDATION_MESSAGE_EMPTY_EMAIL = "Email cannot be empty.";
    private static final Pattern emailPattern = Pattern.compile(EMAIL_REGEX_PATTERN);

    @Override
    public void validate(String emailAddress) throws ValidationException {

        if (StringUtils.isBlank(emailAddress)) {
            throw new ValidationException(EMAIL_REGEX_VALIDATION_MESSAGE_EMPTY_EMAIL);
        }

        Matcher matcher = emailPattern.matcher(emailAddress);
        if (!matcher.matches()) {
            throw new ValidationException(EMAIL_REGEX_VALIDATION_MESSAGE_INVALID_EMAIL_ADDRESS);
        }

        log.debug("Email is valid");
    }
}
