package ca.bestbuy.account.model.customer;

import jakarta.validation.constraints.NotBlank;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public final class UpdateCustomerReq {
    @NotBlank(message = "Party Key is required")
    private String partyKey;
    private String firstName;
    private String lastName;
}
