package ca.bestbuy.account.model.account;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class AddressRequest {

    @NotEmpty
    private String addressLine1;

    private String addressLine2;

    @NotEmpty
    private String postalCode;

    private String provinceCode;

    private String suite;

    @NotEmpty
    private String city;

    @NotEmpty
    private String provinceName;

    private String countryCode;

    @NotEmpty
    private String countryName;

    @NotEmpty
    private String phoneNumber;

    private String phoneNumberExtension;

    private boolean isDefaultAddress;

    @NotNull
    private AddressType addressType;

    private String addressNickname;
}
