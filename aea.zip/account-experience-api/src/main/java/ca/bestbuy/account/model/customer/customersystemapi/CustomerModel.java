package ca.bestbuy.account.model.customer.customersystemapi;

import java.util.ArrayList;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CustomerModel {

    private String email;
    private String firstName;
    private String lastName;
    private String sourceId;
    private String sourceSystem;
    private String phoneNumber;
    private String phoneExtension;
    private String language;
    private String partyKey;

    @Builder.Default
    private List<CustomerAddressModel> addresses = new ArrayList<>();
}
