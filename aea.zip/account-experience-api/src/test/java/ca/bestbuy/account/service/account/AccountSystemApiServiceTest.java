package ca.bestbuy.account.service.account;

import static ca.bestbuy.account.factory.account.AddressResponseFactory.buildAddressResponse;
import static ca.bestbuy.account.factory.account.CreateAddressRequestFactory.buildCreateAddressRequest;
import static ca.bestbuy.account.utils.TestConstant.ACCOUNT_KEY;
import static ca.bestbuy.account.utils.TestConstant.ADDRESS_KEY;
import static ca.bestbuy.account.utils.TestConstant.ADDRESS_LINE1;
import static ca.bestbuy.account.utils.TestConstant.ADDRESS_LINE2;
import static ca.bestbuy.account.utils.TestConstant.ADDRESS_NICKNAME;
import static ca.bestbuy.account.utils.TestConstant.CITY;
import static ca.bestbuy.account.utils.TestConstant.COUNTRY_CODE;
import static ca.bestbuy.account.utils.TestConstant.COUNTRY_NAME;
import static ca.bestbuy.account.utils.TestConstant.PHONE_NUMBER;
import static ca.bestbuy.account.utils.TestConstant.PHONE_NUMBER_EXTENSION;
import static ca.bestbuy.account.utils.TestConstant.POSTAL_CODE;
import static ca.bestbuy.account.utils.TestConstant.PROVINCE_CODE;
import static ca.bestbuy.account.utils.TestConstant.PROVINCE_NAME;
import static ca.bestbuy.account.utils.TestConstant.SUITE;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import ca.bestbuy.account.model.account.AddressType;
import ca.bestbuy.account.model.account.accountsystemapi.AddressResponse;
import ca.bestbuy.account.model.account.accountsystemapi.CreateAddressRequest;
import java.util.function.Function;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

@ExtendWith(MockitoExtension.class)
class AccountSystemApiServiceTest {

    @Mock
    private WebClient accountSystemApiWebClient;

    @Mock
    private WebClient.RequestBodyUriSpec requestBodyUriSpec;

    @Mock
    private WebClient.RequestBodySpec requestBodySpec;

    @Mock
    private WebClient.RequestHeadersSpec requestHeadersSpec;

    @Mock
    private WebClient.ResponseSpec responseSpec;

    @InjectMocks
    private AccountSystemApiServiceImpl accountSystemApiService;

    @Test
    void testUpdateCustomerName() {
        // Given
        CreateAddressRequest createAddressRequest = buildCreateAddressRequest();

        AddressResponse addressResponse = buildAddressResponse();
        when(accountSystemApiWebClient.post()).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(any(Function.class))).thenReturn(requestBodySpec);
        when(requestBodySpec.contentType(any())).thenReturn(requestBodySpec);
        when(requestBodySpec.body(any())).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.onStatus(any(), any())).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(ArgumentMatchers.<Class<AddressResponse>>notNull())).thenReturn(
            Mono.just(addressResponse));

        // When
        AddressResponse result = accountSystemApiService.createAddress(ACCOUNT_KEY, createAddressRequest);

        // Expect
        assertEquals(ADDRESS_KEY, result.getAddressKey());
        assertEquals(ADDRESS_LINE1, result.getAddressLine1());
        assertEquals(ADDRESS_LINE2, result.getAddressLine2());
        assertEquals(POSTAL_CODE, result.getPostalCode());
        assertEquals(PROVINCE_CODE, result.getProvinceCode());
        assertEquals(PROVINCE_NAME, result.getProvinceName());
        assertEquals(COUNTRY_CODE, result.getCountryCode());
        assertEquals(COUNTRY_NAME, result.getCountryName());
        assertEquals(CITY, result.getCity());
        assertEquals(SUITE, result.getSuite());
        assertEquals(PHONE_NUMBER, result.getPhoneNumber());
        assertEquals(PHONE_NUMBER_EXTENSION, result.getPhoneNumberExtension());
        assertTrue(result.isDefaultAddress());
        assertEquals(AddressType.SHIPPING, result.getAddressType());
        assertEquals(ADDRESS_NICKNAME, result.getAddressNickname());
    }
}