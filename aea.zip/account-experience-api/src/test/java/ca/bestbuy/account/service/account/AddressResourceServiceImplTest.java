package ca.bestbuy.account.service.account;

import static ca.bestbuy.account.factory.account.AddressRequestFactory.buildAddressRequest;
import static ca.bestbuy.account.factory.account.AddressResourceFactory.buildAddressResource;
import static ca.bestbuy.account.factory.account.AddressResponseFactory.buildAddressResponse;
import static ca.bestbuy.account.factory.account.CreateAddressRequestFactory.buildCreateAddressRequest;
import static ca.bestbuy.account.utils.TestConstant.ACCOUNT_KEY;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import ca.bestbuy.account.mapper.AddressRequestMapper;
import ca.bestbuy.account.mapper.AddressResourceMapper;
import ca.bestbuy.account.model.account.AddressRequest;
import ca.bestbuy.account.model.account.AddressResource;
import ca.bestbuy.account.model.account.accountsystemapi.AddressResponse;
import ca.bestbuy.account.model.account.accountsystemapi.CreateAddressRequest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class AddressResourceServiceImplTest {

    @Mock
    private AccountSystemApiService accountSystemApiService;

    @Mock
    private AddressRequestMapper addressRequestMapper;

    @Mock
    private AddressResourceMapper addressResourceMapper;

    @InjectMocks
    private AddressResourceServiceImpl addressResourceService;

    @Test
    void testCreateAddress() {
        AddressRequest addressRequest = buildAddressRequest();
        CreateAddressRequest createAddressRequest = buildCreateAddressRequest();
        AddressResponse addressResponse = buildAddressResponse();
        AddressResource expectedAddressResource = buildAddressResource();

        when(addressRequestMapper.addressRequestToCreateAddressRequest(addressRequest)).thenReturn(createAddressRequest);
        when(accountSystemApiService.createAddress(ACCOUNT_KEY, createAddressRequest)).thenReturn(addressResponse);
        when(addressResourceMapper.addressResponseToAddressResource(addressResponse)).thenReturn(expectedAddressResource);

        AddressResource actualAddressResource = addressResourceService.createAddress(ACCOUNT_KEY, addressRequest);

        assertEquals(expectedAddressResource, actualAddressResource);
    }
}