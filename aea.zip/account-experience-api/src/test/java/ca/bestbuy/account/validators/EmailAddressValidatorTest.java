package ca.bestbuy.account.validators;

import ca.bestbuy.account.exception.ValidationException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

@ExtendWith(MockitoExtension.class)
class EmailAddressValidatorTest {

    static final String EMAIL_REGEX_VALIDATION_MESSAGE_INVALID_EMAIL_ADDRESS = "Invalid email address format.";
    static final String EMAIL_REGEX_VALIDATION_MESSAGE_EMPTY_USERNAME = "Email cannot be empty.";
    @Mock
    private EmailAddressValidator emailAddressValidator;

    @BeforeEach
    void setUp() {
        this.emailAddressValidator = new EmailAddressValidator();
    }

    @Test
    void validatePassesWhenValidationSucceeds() throws ValidationException {
        String email = "valid-email@bestbuycanada.ca";
        emailAddressValidator.validate(email);
    }

    @Test
    void validateThrowsExceptionGivenEmptyString() throws ValidationException {
        String email = "";
        ValidationException exception = assertThrows(ValidationException.class,
                () -> emailAddressValidator.validate(email));
        assertEquals(EMAIL_REGEX_VALIDATION_MESSAGE_EMPTY_USERNAME, exception.getMessage());
    }

    @Test
    void validateThrowsExceptionGivenFrontSlash() throws ValidationException {
        String email = "invalid/@email.com";
        ValidationException exception = assertThrows(ValidationException.class,
                () -> emailAddressValidator.validate(email));
        assertEquals(EMAIL_REGEX_VALIDATION_MESSAGE_INVALID_EMAIL_ADDRESS, exception.getMessage());
    }

    @Test
    void validateThrowsExceptionGivenBackSlash() throws ValidationException {
        String email = "invalid\\@email.com";
        ValidationException exception = assertThrows(ValidationException.class,
                () -> emailAddressValidator.validate(email));
        assertEquals(EMAIL_REGEX_VALIDATION_MESSAGE_INVALID_EMAIL_ADDRESS, exception.getMessage());
    }

    @Test
    void validateThrowsExceptionGivenComma() throws ValidationException {
        String email = "invalid,,@email.com";
        ValidationException exception = assertThrows(ValidationException.class,
                () -> emailAddressValidator.validate(email));
        assertEquals(EMAIL_REGEX_VALIDATION_MESSAGE_INVALID_EMAIL_ADDRESS, exception.getMessage());
    }

    @Test
    void validateThrowsExceptionGivenInvalidEmailLiteralStr() throws ValidationException {
        String email = "exampleexample";
        ValidationException exception = assertThrows(ValidationException.class,
                () -> emailAddressValidator.validate(email));
        assertEquals(EMAIL_REGEX_VALIDATION_MESSAGE_INVALID_EMAIL_ADDRESS, exception.getMessage());
    }

    @Test
    void validateThrowsExceptionGivenNoDomain() throws ValidationException {
        String email = "example@example";
        ValidationException exception = assertThrows(ValidationException.class,
                () -> emailAddressValidator.validate(email));
        assertEquals(EMAIL_REGEX_VALIDATION_MESSAGE_INVALID_EMAIL_ADDRESS, exception.getMessage());
    }

    @Test
    void validateThrowsExceptionGivenNoSuffix() throws ValidationException {
        String email = "example@";
        ValidationException exception = assertThrows(ValidationException.class,
                () -> emailAddressValidator.validate(email));
        assertEquals(EMAIL_REGEX_VALIDATION_MESSAGE_INVALID_EMAIL_ADDRESS, exception.getMessage());
    }

    @Test
    void validateThrowsExceptionGivenNoPrefix() throws ValidationException {
        String email = "example.com";
        ValidationException exception = assertThrows(ValidationException.class,
                () -> emailAddressValidator.validate(email));
        assertEquals(EMAIL_REGEX_VALIDATION_MESSAGE_INVALID_EMAIL_ADDRESS, exception.getMessage());
    }

    @Test
    void validateThrowsExceptionGivenDomainTooShort() throws ValidationException {
        String email = "example@a.b";
        ValidationException exception = assertThrows(ValidationException.class,
                () -> emailAddressValidator.validate(email));
        assertEquals(EMAIL_REGEX_VALIDATION_MESSAGE_INVALID_EMAIL_ADDRESS, exception.getMessage());
    }
}
