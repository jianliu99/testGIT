package ca.bestbuy.account.utilities;

import ca.bestbuy.account.exception.LocaleException;
import ca.bestbuy.account.utils.LocaleUtility;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.context.i18n.LocaleContextHolder;

import java.util.Locale;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

@ExtendWith(MockitoExtension.class)
class LocaleUtilityTest {

    static final String MESSAGE_LOCALE_STRING_FORMAT_INVALID = "Locale string is not formatted correctly. Should be xx-XX.";
    static final String MESSAGE_INVALID_LOCALE_OBJECT = "Required parameter is not found in Locale object.";
    private LocaleUtility localeUtility;

    @BeforeEach
    void setup() {
        localeUtility = new LocaleUtility();
    }

    @Test
    void setLocalFromUrlStringThrowsExceptionForInvalidInput() {
        LocaleException exception = assertThrows(LocaleException.class,
                () -> localeUtility.setLocaleFromUrlString("en"));
        assertEquals(MESSAGE_LOCALE_STRING_FORMAT_INVALID, exception.getMessage());
    }

    @Test
    void setLocaleFromUrlStringUpdatesTheLocaleContextWithoutValidation() {
        localeUtility.setLocaleFromUrlString("zz-AA");
        Locale result = LocaleContextHolder.getLocale();
        assertEquals("zz", result.getLanguage());
        assertEquals("AA", result.getCountry());
    }

    @Test
    void setLocaleFromUrlStringUpdatesTheLocaleContext() {
        localeUtility.setLocaleFromUrlString("fr-CA");
        Locale result = LocaleContextHolder.getLocale();
        assertEquals("fr", result.getLanguage());
        assertEquals("CA", result.getCountry());
    }

    @Test
    void setLocaleFromRequestFieldUpdatesTheLocaleContextWithCountry() {
        localeUtility.setLocaleFromRequestField("fr-CA");
        Locale result = LocaleContextHolder.getLocale();
        assertEquals("fr", result.getLanguage());
        assertEquals("CA", result.getCountry());
    }

    @Test
    void setLocaleFromRequestFieldUpdatesTheLocaleContextWithoutCountry() {
        localeUtility.setLocaleFromRequestField("fr");
        Locale result = LocaleContextHolder.getLocale();
        assertEquals("fr", result.getLanguage());
        assertEquals("", result.getCountry());
    }

    @Test
    void setLocaleFromRequestFieldUpdatesTheLocaleContextNullDefaultsToEnglish() {
        localeUtility.setLocaleFromRequestField(null);
        Locale result = LocaleContextHolder.getLocale();
        assertEquals("en", result.getLanguage());
        assertEquals("", result.getCountry());
    }

    @Test
    void setLocaleFromRequestFieldUpdatesTheLocaleContextEmptyStringDefaultsToEnglish() {
        localeUtility.setLocaleFromRequestField("");
        Locale result = LocaleContextHolder.getLocale();
        assertEquals("en", result.getLanguage());
        assertEquals("", result.getCountry());
    }

    @Test
    void setLocaleFromRequestFieldThrowsLocalExceptionForInvalidLocaleStringEmptyLanguage() {
        LocaleException exception = assertThrows(LocaleException.class,
                () -> localeUtility.setLocaleFromRequestField(" "));
        assertEquals(MESSAGE_LOCALE_STRING_FORMAT_INVALID, exception.getMessage());
    }

    @Test
    void getLocaleFromStringNullThrowsException() {
        LocaleException exception = assertThrows(LocaleException.class,
                () -> localeUtility.getLocaleFromString(null, false));
        assertEquals(MESSAGE_LOCALE_STRING_FORMAT_INVALID, exception.getMessage());

        exception = assertThrows(LocaleException.class,
                () -> localeUtility.getLocaleFromString(null, true));
        assertEquals(MESSAGE_LOCALE_STRING_FORMAT_INVALID, exception.getMessage());
    }

    @Test
    void getLocaleFromStringEmptyStringThrowsException() {
        LocaleException exception = assertThrows(LocaleException.class,
                () -> localeUtility.getLocaleFromString("", false));
        assertEquals(MESSAGE_LOCALE_STRING_FORMAT_INVALID, exception.getMessage());
        exception = assertThrows(LocaleException.class,
                () -> localeUtility.getLocaleFromString("", true));
        assertEquals(MESSAGE_LOCALE_STRING_FORMAT_INVALID, exception.getMessage());
    }

    @Test
    void getLocaleFromStringWithoutCountryNotRequiringCountry() {
        Locale result = localeUtility.getLocaleFromString("zz", false);
        assertEquals("zz", result.getLanguage());
        assertEquals("", result.getCountry());
    }

    @Test
    void getLocaleFromStringWithoutCountryButWithDelimiterNotRequiringCountry() {
        Locale result = localeUtility.getLocaleFromString("zz-", false);
        assertEquals("zz", result.getLanguage());
        assertEquals("", result.getCountry());
    }

    @Test
    void getLocaleFromStringWithoutCountryRequiringCountryThrowsException() {
        LocaleException exception = assertThrows(LocaleException.class,
                () -> localeUtility.getLocaleFromString("zz", true));
        assertEquals(MESSAGE_LOCALE_STRING_FORMAT_INVALID, exception.getMessage());
    }

    @Test
    void getLocaleFromStringWithoutCountryButWithDelimiterRequiringCountryThrowsException() {
        LocaleException exception = assertThrows(LocaleException.class,
                () -> localeUtility.getLocaleFromString("zz-", true));
        assertEquals(MESSAGE_LOCALE_STRING_FORMAT_INVALID, exception.getMessage());
    }

    @Test
    void getLocaleFromStringWithCountry() {
        Locale result = localeUtility.getLocaleFromString("zz-ZZ", false);
        assertEquals("zz", result.getLanguage());
        assertEquals("ZZ", result.getCountry());
        result = localeUtility.getLocaleFromString("zz-ZZ", true);
        assertEquals("zz", result.getLanguage());
        assertEquals("ZZ", result.getCountry());
    }

    @Test
    void getLocaleFromStringWithCountryMissingLanguage() {
        LocaleException exception = assertThrows(LocaleException.class,
                () -> localeUtility.getLocaleFromString("-ZZ", true));
        assertEquals(MESSAGE_LOCALE_STRING_FORMAT_INVALID, exception.getMessage());
    }

    @Test
    void getLocaleFromStringThrowsExceptionForEmptyLanguage() {
        LocaleException exception = assertThrows(LocaleException.class,
                () -> localeUtility.setLocaleFromRequestField(" "));
        assertEquals(MESSAGE_LOCALE_STRING_FORMAT_INVALID, exception.getMessage());
    }

    @Test
    void getLocaleFromStringThrowsExceptionForEmptyCountry() {
        LocaleException exception = assertThrows(LocaleException.class,
                () -> localeUtility.setLocaleFromRequestField("en- "));
        assertEquals(MESSAGE_LOCALE_STRING_FORMAT_INVALID, exception.getMessage());
    }

    @Test
    void getFormattedStringFromLocaleReturnsCorrectlyFormattedStringWithLanguageAndCountry() {
        Locale testLocale = new Locale("zz", "ZZ");
        String result = localeUtility.getFormattedStringFromLocale(testLocale);
        assertEquals("zz-ZZ", result);
    }

    @Test
    void getFormattedStringFromLocaleReturnsCanadaWhenCountryIsNotSetWithLanguageOnly() {
        Locale testLocale = new Locale("zz");
        String result = localeUtility.getFormattedStringFromLocale(testLocale);
        assertEquals("zz-CA", result);
    }

    @Test
    void getFormattedStringFromLocaleThrowsLocaleExceptionWhenLanguageIsNotSet() {
        Locale testLocale = new Locale("");
        LocaleException exception = assertThrows(LocaleException.class,
                () -> localeUtility.getFormattedStringFromLocale(testLocale));
        assertEquals(MESSAGE_INVALID_LOCALE_OBJECT, exception.getMessage());
    }

    @Test
    void getLocaleSuccessEnCa() {
        final Locale retrievedLocale = LocaleUtility.getLocale("en-ca");
        assertEquals(retrievedLocale, Locale.CANADA);
    }

    @Test
    void getLocaleSuccessFrCa() {
        final Locale retrievedLocale = LocaleUtility.getLocale("fr-ca");
        assertEquals(retrievedLocale, Locale.CANADA_FRENCH);
    }

    @Test
    void getLocaleFailureLocaleEmpty() {
        final Locale retrievedLocale = LocaleUtility.getLocale(null);
        assertEquals(Locale.CANADA, retrievedLocale);
    }
}