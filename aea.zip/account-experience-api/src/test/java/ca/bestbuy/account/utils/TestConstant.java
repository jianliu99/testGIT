package ca.bestbuy.account.utils;

import java.util.UUID;

public class TestConstant {

    // Account
    public static final String FIRST_NAME = "Firstname";
    public static final String LAST_NAME = "Lastname";
    public static final String PARTY_KEY = UUID.randomUUID().toString();
    public static final String ACCOUNT_KEY = "123";

    // Address
    public static final String ADDRESS_KEY = "123";
    public static final String ADDRESS_LINE1 = "Line 1";
    public static final String ADDRESS_LINE2 = "Line 2";
    public static final String POSTAL_CODE = "A1B2C3";
    public static final String PROVINCE_CODE = "ON";
    public static final String PROVINCE_NAME = "Ontario";
    public static final String COUNTRY_CODE = "CA";
    public static final String COUNTRY_NAME = "Canada";
    public static final String CITY = "City";
    public static final String SUITE = "Suite";
    public static final String PHONE_NUMBER = "1234567890";
    public static final String PHONE_NUMBER_EXTENSION = "01";
    public static final String ADDRESS_NICKNAME = "Home";
    public static final String EMAIL_ADDRESS = "test@test.com";
    public static final String SOURCE_SYSTEM = "AccountSystem";
    public static final String LANGUAGE = "en-CA";
}