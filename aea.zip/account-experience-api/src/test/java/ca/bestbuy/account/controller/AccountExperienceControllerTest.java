package ca.bestbuy.account.controller;

import ca.bestbuy.account.exception.BadRequestException;
import ca.bestbuy.account.exception.ServerErrorException;
import ca.bestbuy.account.exception.ValidationException;
import ca.bestbuy.account.factory.account.CustomerAccountReqFactory;
import ca.bestbuy.account.model.accountcreation.CustomerAccountRequest;
import ca.bestbuy.account.model.accountcreation.CustomerInfoResource;
import ca.bestbuy.account.model.accountcreation.membershipapi.GetMembershipRequest;
import ca.bestbuy.account.model.accountcreation.membershipapi.MembershipResponse;
import ca.bestbuy.account.model.customer.CustomerResource;
import ca.bestbuy.account.model.customer.customersystemapi.CustomerModel;
import ca.bestbuy.account.service.membership.MembershipSystemApiService;
import ca.bestbuy.account.service.customer.CustomerSystemApiService;
import ca.bestbuy.account.validators.CreateAccountValidator;
import ca.bestbuy.account.validators.EmailAddressValidator;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import static ca.bestbuy.account.factory.account.CustomerModelFactory.buildCustomerModel;
import static ca.bestbuy.account.utils.TestConstant.FIRST_NAME;
import static ca.bestbuy.account.utils.TestConstant.LAST_NAME;
import static ca.bestbuy.account.utils.TestConstant.PARTY_KEY;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.UUID;

@ExtendWith(MockitoExtension.class)
class AccountExperienceControllerTest {

    @InjectMocks
    private AccountExperienceController accountExperienceController;
    @Mock
    private CustomerSystemApiService customerSystemApiService;
    @Mock
    private CreateAccountValidator mockCreateAccountValidator;

    @Mock
    private EmailAddressValidator mockEmailAddressValidator;
    @Mock
    private MembershipSystemApiService membershipSystemApiService;
    private CustomerAccountRequest customerAccountRequest;
    private CustomerModel customerModel;

    @BeforeEach
    public void setUp() {
        customerAccountRequest = CustomerAccountReqFactory.buildCustomerAccountRequest();
        customerModel = new CustomerModel();
        customerModel.setPartyKey("partyKey");
        customerModel.setFirstName("firstName");
        customerModel.setLastName("lastName");
    }

    @Test
    void testUpdateCustomerName() {
        when(customerSystemApiService.updateCustomer(any())).thenReturn(Mono.just(buildCustomerModel()));

        var actual = accountExperienceController.updateCustomer(customerAccountRequest);

        StepVerifier.create(actual).consumeNextWith(v -> {
            assertEquals(FIRST_NAME, v.getFirstName());
            assertEquals(LAST_NAME, v.getLastName());
            assertEquals(PARTY_KEY, v.getPartyKey());
        }).verifyComplete();
    }

    @Test
    void updateAccount_Successfully_WithValidPartyKey() throws ValidationException {
        String partyKey = UUID.randomUUID().toString();
        customerAccountRequest.setPartyKey(partyKey);
        doNothing().when(mockEmailAddressValidator).validate(customerAccountRequest.getEmail());

        when(customerSystemApiService.updateCustomer(customerAccountRequest))
                .thenReturn(Mono.just(CustomerModel.builder().partyKey(partyKey).build()));

        when(membershipSystemApiService.getMemberships(any(GetMembershipRequest.class)))
                .thenReturn(Mono.just(MembershipResponse.builder().memberId(123).membershipKey("456").build()));

        Mono<CustomerInfoResource> response = accountExperienceController.createOrUpdateAccount(customerAccountRequest);
        StepVerifier.create(response).consumeNextWith(v -> {
            assertEquals(partyKey, v.getPartyKey());
            assertEquals("123", v.getMemberId());
            assertEquals("456", v.getMembershipKey());
        }).verifyComplete();

        verify(mockCreateAccountValidator, never()).validate(customerAccountRequest);
        verify(customerSystemApiService, never()).createCustomer(customerAccountRequest);
        verify(membershipSystemApiService, times(1)).getMemberships(any(GetMembershipRequest.class));

    }

    @Test
    void createAccount_Successfully_WithAllValuesReturned() throws ValidationException {
        String partyKey = UUID.randomUUID().toString();

        doNothing().when(mockCreateAccountValidator).validate(customerAccountRequest);
        when(customerSystemApiService.createCustomer(customerAccountRequest))
                .thenReturn(Mono.just(CustomerModel.builder().partyKey(partyKey).build()));
        when(membershipSystemApiService.getMemberships(any(GetMembershipRequest.class)))
                .thenReturn(Mono.just(MembershipResponse.builder().memberId(123).membershipKey("456").build()));

        Mono<CustomerInfoResource> response = accountExperienceController.createOrUpdateAccount(customerAccountRequest);
        StepVerifier.create(response).consumeNextWith(v -> {
            assertEquals(partyKey, v.getPartyKey());
            assertEquals("123", v.getMemberId());
            assertEquals("456", v.getMembershipKey());
        }).verifyComplete();

        verify(mockCreateAccountValidator, times(1)).validate(customerAccountRequest);
        verify(customerSystemApiService, times(1)).createCustomer(customerAccountRequest);
        verify(membershipSystemApiService, times(1)).getMemberships(any(GetMembershipRequest.class));
    }

    @Test
    void createAccount_Successfully_WithOnlyMembershipReturned() throws ValidationException {

        doNothing().when(mockCreateAccountValidator).validate(customerAccountRequest);
        when(customerSystemApiService.createCustomer(customerAccountRequest))
                .thenReturn(Mono.empty());
        when(membershipSystemApiService.getMemberships(any(GetMembershipRequest.class)))
                .thenReturn(Mono.just(MembershipResponse.builder().memberId(123).membershipKey("456").build()));

        Mono<CustomerInfoResource> response = accountExperienceController.createOrUpdateAccount(customerAccountRequest);
        StepVerifier.create(response).consumeNextWith(v -> {
            assertNull(v.getPartyKey());
            assertEquals("123", v.getMemberId());
            assertEquals("456", v.getMembershipKey());
        }).verifyComplete();

        verify(mockCreateAccountValidator, times(1)).validate(customerAccountRequest);
        verify(customerSystemApiService, times(1)).createCustomer(customerAccountRequest);
        verify(membershipSystemApiService, times(1)).getMemberships(any(GetMembershipRequest.class));
    }

    @Test
    void createAccount_Successfully_WithOnlyPartyKeyReturned() throws ValidationException {
        String partyKey = UUID.randomUUID().toString();

        doNothing().when(mockCreateAccountValidator).validate(customerAccountRequest);
        when(customerSystemApiService.createCustomer(customerAccountRequest))
                .thenReturn(Mono.just(CustomerModel.builder().partyKey(partyKey).build()));
        when(membershipSystemApiService.getMemberships(any(GetMembershipRequest.class)))
                .thenReturn(Mono.empty());

        Mono<CustomerInfoResource> response = accountExperienceController.createOrUpdateAccount(customerAccountRequest);
        StepVerifier.create(response).consumeNextWith(v -> {
            assertEquals(partyKey, v.getPartyKey());
        }).verifyComplete();

        verify(mockCreateAccountValidator, times(1)).validate(customerAccountRequest);
        verify(customerSystemApiService, times(1)).createCustomer(customerAccountRequest);
        verify(membershipSystemApiService, times(1)).getMemberships(any(GetMembershipRequest.class));
    }

    @Test
    void createAccount_Successfully_WithNoValueReturned() throws ValidationException {

        doNothing().when(mockCreateAccountValidator).validate(customerAccountRequest);
        when(customerSystemApiService.createCustomer(customerAccountRequest))
                .thenReturn(Mono.empty());
        when(membershipSystemApiService.getMemberships(any(GetMembershipRequest.class)))
                .thenReturn(Mono.empty());

        Mono<CustomerInfoResource> response = accountExperienceController.createOrUpdateAccount(customerAccountRequest);
        StepVerifier.create(response).consumeNextWith(v -> {
            assertNull(v.getPartyKey());
            assertNull(v.getMemberId());
            assertNull(v.getMembershipKey());
        }).verifyComplete();

        verify(mockCreateAccountValidator, times(1)).validate(customerAccountRequest);
        verify(customerSystemApiService, times(1)).createCustomer(customerAccountRequest);
        verify(membershipSystemApiService, times(1)).getMemberships(any(GetMembershipRequest.class));
    }

    @Test
    void createAccount_Failed_WhenInvalidCreateCustomerRequest() throws ValidationException {
        doThrow(ValidationException.class).when(mockCreateAccountValidator).validate(customerAccountRequest);
        BadRequestException errorException = assertThrows(BadRequestException.class,
                () -> accountExperienceController.createOrUpdateAccount(customerAccountRequest));

        assertNotNull(errorException);
        assertEquals("BAD_REQUEST", errorException.getMessage());

        verify(mockCreateAccountValidator, times(1)).validate(customerAccountRequest);
        verify(customerSystemApiService, never()).createCustomer(customerAccountRequest);
        verify(membershipSystemApiService, never()).getMemberships(any(GetMembershipRequest.class));
    }

    @Test
    void createAccount_Failed_WhenFailedToCallCustomerSystemApiService() throws ValidationException {
        doNothing().when(mockCreateAccountValidator).validate(customerAccountRequest);
        doThrow(WebClientResponseException.class).when(customerSystemApiService).createCustomer(customerAccountRequest);

        ServerErrorException errorException = assertThrows(ServerErrorException.class,
                () -> accountExperienceController.createOrUpdateAccount(customerAccountRequest));

        assertNotNull(errorException);
        assertEquals("Failed to call system api.", errorException.getMessage());
    }

    @Test
    void createAccount_Failed_WhenFailedToCallMembershipSystemApiService() throws ValidationException {
        doNothing().when(mockCreateAccountValidator).validate(customerAccountRequest);
        doThrow(WebClientResponseException.class).when(customerSystemApiService).createCustomer(customerAccountRequest);

        ServerErrorException errorException = assertThrows(ServerErrorException.class,
                () -> accountExperienceController.createOrUpdateAccount(customerAccountRequest));

        assertNotNull(errorException);
        assertEquals("Failed to call system api.", errorException.getMessage());

    }

    @Test
    void getCustomer_Successfully() {
        when(customerSystemApiService.getCustomer(anyString())).thenReturn(Flux.just(customerModel));

        Flux<CustomerResource> result = accountExperienceController.getCustomer("partyKey");

        StepVerifier.create(result)
            .assertNext(customerResource -> {
                assertEquals("partyKey", customerResource.getPartyKey());
                assertEquals("firstName", customerResource.getFirstName());
                assertEquals("lastName", customerResource.getLastName());
            })
            .verifyComplete();
    }


    @Test
    void getCustomer_Failed_WhenFailedToCallCustomerStemApiService() {

        doThrow(WebClientResponseException.class).when(customerSystemApiService).getCustomer(anyString());

        ServerErrorException errorException = assertThrows(ServerErrorException.class,
            () -> accountExperienceController.getCustomer("partyKey"));

        assertNotNull(errorException);
        assertEquals("Failed to call system api.", errorException.getMessage());

    }
}
