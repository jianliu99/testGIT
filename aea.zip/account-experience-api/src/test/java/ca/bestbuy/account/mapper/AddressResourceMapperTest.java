package ca.bestbuy.account.mapper;

import static ca.bestbuy.account.factory.account.AddressResponseFactory.buildAddressResponse;
import static org.junit.jupiter.api.Assertions.assertEquals;

import ca.bestbuy.account.model.account.AddressResource;
import ca.bestbuy.account.model.account.accountsystemapi.AddressResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mapstruct.factory.Mappers;

class AddressResourceMapperTest {

    private AddressResourceMapper mapper;

    @BeforeEach
    public void beforeEach() {
        mapper = Mappers.getMapper(AddressResourceMapper.class);
    }

    @Test
    void addressResponseToAddressResource() {
        // Given
        AddressResponse addressResponse = buildAddressResponse();

        // When
        AddressResource addressResource = mapper.addressResponseToAddressResource(addressResponse);

        // Then
        assertEquals(addressResponse.getAddressKey(), addressResource.getAddressKey());
        assertEquals(addressResponse.getAddressLine1(), addressResource.getAddressLine1());
        assertEquals(addressResponse.getAddressLine2(), addressResource.getAddressLine2());
        assertEquals(addressResponse.getPostalCode(), addressResource.getPostalCode());
        assertEquals(addressResponse.getProvinceCode(), addressResource.getProvinceCode());
        assertEquals(addressResponse.getProvinceName(), addressResource.getProvinceName());
        assertEquals(addressResponse.getCountryCode(), addressResource.getCountryCode());
        assertEquals(addressResponse.getCountryName(), addressResource.getCountryName());
        assertEquals(addressResponse.getCity(), addressResource.getCity());
        assertEquals(addressResponse.getSuite(), addressResource.getSuite());
        assertEquals(addressResponse.getPhoneNumber(), addressResource.getPhoneNumber());
        assertEquals(addressResponse.getPhoneNumberExtension(), addressResource.getPhoneNumberExtension());
        assertEquals(addressResponse.isDefaultAddress(), addressResource.isDefaultAddress());
        assertEquals(addressResponse.getAddressType(), addressResource.getAddressType());
        assertEquals(addressResponse.getAddressNickname(), addressResource.getAddressNickname());
    }
}