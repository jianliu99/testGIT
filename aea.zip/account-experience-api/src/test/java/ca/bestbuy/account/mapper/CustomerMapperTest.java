package ca.bestbuy.account.mapper;

import static ca.bestbuy.account.utils.TestConstant.ACCOUNT_KEY;
import static ca.bestbuy.account.utils.TestConstant.EMAIL_ADDRESS;
import static ca.bestbuy.account.utils.TestConstant.FIRST_NAME;
import static ca.bestbuy.account.utils.TestConstant.LANGUAGE;
import static ca.bestbuy.account.utils.TestConstant.LAST_NAME;
import static ca.bestbuy.account.utils.TestConstant.SOURCE_SYSTEM;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import ca.bestbuy.account.factory.account.AddressRequestFactory;
import ca.bestbuy.account.factory.account.CustomerAccountReqFactory;
import ca.bestbuy.account.model.account.AddressRequest;
import ca.bestbuy.account.model.accountcreation.CustomerAccountRequest;
import ca.bestbuy.account.model.customer.customersystemapi.CustomerAddressModel;
import ca.bestbuy.account.model.customer.customersystemapi.CustomerGraphqlReq;
import ca.bestbuy.account.model.customer.customersystemapi.CustomerModel;
import java.util.Collections;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mapstruct.factory.Mappers;

class CustomerMapperTest {

    private CustomerMapper customerMapper = Mappers.getMapper(CustomerMapper.class);

    @BeforeEach
    public void beforeEach() {
        customerMapper = Mappers.getMapper(CustomerMapper.class);
    }

    @Test
    void testToCustomerNameReqToUpdateNamesGraphqlReq() {
        CustomerAccountRequest customerAccountRequest = CustomerAccountReqFactory.buildCustomerAccountRequest();
        AddressRequest addressRequest = AddressRequestFactory.buildAddressRequest();
        customerAccountRequest.setAddresses(Collections.singletonList(addressRequest));

        CustomerGraphqlReq request = customerMapper.toCustomerGraphqlReq(customerAccountRequest);

        CustomerModel customerInput = request.getCustomerInput();

        assertNotNull(customerInput);
        assertEquals(EMAIL_ADDRESS, customerInput.getEmail());
        assertEquals(FIRST_NAME, customerInput.getFirstName());
        assertEquals(LAST_NAME, customerInput.getLastName());
        assertEquals(ACCOUNT_KEY, customerInput.getSourceId());
        assertEquals(LAST_NAME, customerInput.getLastName());
        assertEquals(SOURCE_SYSTEM, customerInput.getSourceSystem());
        assertEquals(LANGUAGE, customerInput.getLanguage());

        CustomerAddressModel address = customerInput.getAddresses().get(0);
        assertEquals(address.getAddressLine1(), addressRequest.getAddressLine1());
        assertEquals(address.getAddressLine2(), addressRequest.getAddressLine2());
        assertEquals(address.getCity(), addressRequest.getCity());
        assertEquals(address.getCountryCode(), addressRequest.getCountryCode());
        assertEquals(address.getCountryName(), addressRequest.getCountryName().toUpperCase());
        assertEquals(address.getPostalCode(), addressRequest.getPostalCode());
        assertEquals(address.getRegionCode(), addressRequest.getProvinceCode());
        assertEquals(address.getRegionName(), addressRequest.getProvinceName());
        assertEquals(address.getPhoneNumber(), addressRequest.getPhoneNumber());
        assertNotNull(address);
    }

    @Test
    void testToCustomerNameReqToUpdateNamesGraphqlReqWithoutAddresses() {
        CustomerAccountRequest customerAccountRequest = CustomerAccountReqFactory.buildCustomerAccountRequest();

        CustomerGraphqlReq request = customerMapper.toCustomerGraphqlReq(customerAccountRequest);

        CustomerModel customerInput = request.getCustomerInput();

        assertNotNull(customerInput);
        assertEquals(EMAIL_ADDRESS, customerInput.getEmail());
        assertEquals(FIRST_NAME, customerInput.getFirstName());
        assertEquals(LAST_NAME, customerInput.getLastName());
        assertEquals(ACCOUNT_KEY, customerInput.getSourceId());
        assertEquals(LAST_NAME, customerInput.getLastName());
        assertEquals(SOURCE_SYSTEM, customerInput.getSourceSystem());
        assertEquals(LANGUAGE, customerInput.getLanguage());

        assertNotNull(customerInput.getAddresses());
        assertEquals(0, customerInput.getAddresses().size());
    }
}