package ca.bestbuy.account.service.membership;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.springframework.http.HttpHeaders.CONTENT_TYPE;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import ca.bestbuy.account.factory.membership.MembershipApiRequestFactory;
import ca.bestbuy.account.model.accountcreation.membershipapi.MembershipResponse;
import ca.bestbuy.account.model.accountcreation.membershipapi.MembershipStatusName;
import java.io.IOException;
import java.util.Arrays;
import com.fasterxml.jackson.databind.ObjectMapper;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;


@ExtendWith(MockitoExtension.class)
class MembershipSystemApiServiceImplTest {

    private static final String ANY_MEMBERSHIP_KEY1 = "9001";
    private static final int ANY_MEMBER_ID1 = 1001;
    private static final String ANY_MEMBERSHIP_KEY2 = "9002";
    private static final int ANY_MEMBER_ID2 = 1002;
    private static final String ANY_MEMBERSHIP_KEY3 = "9003";
    private static final int ANY_MEMBER_ID3 = 1003;
    private static MockWebServer mockMembershipSystemApiServer;

    private static final ObjectMapper objectMapper = new ObjectMapper();

    private MembershipSystemApiServiceImpl membershipSystemApiService;

    @BeforeEach
    public void beforeEach() throws IOException {
        mockMembershipSystemApiServer = new MockWebServer();
        mockMembershipSystemApiServer.start();

        String mockMembershipSystemApiUrl = String.format("http://localhost:%s", mockMembershipSystemApiServer.getPort());

        membershipSystemApiService = new MembershipSystemApiServiceImpl("/v1/memberships", 5L,
                WebClient.builder().baseUrl(mockMembershipSystemApiUrl).build());
    }

    @Test
    void getMemberships_ReturnsMembershipSuccessfully() throws Exception {
        mockMembershipSystemApiServer.enqueue(new MockResponse()
                .setBody(objectMapper.writeValueAsString(
                        MembershipApiRequestFactory
                                .createMembershipResponse(ANY_MEMBER_ID1, ANY_MEMBERSHIP_KEY1, MembershipStatusName.ACTIVE, "2025-03-18")))
                .addHeader(CONTENT_TYPE, APPLICATION_JSON_VALUE));

        Mono<MembershipResponse> membershipMono =
                membershipSystemApiService.getMemberships(MembershipApiRequestFactory.buildMembershipApiRequest());

        assertNotNull(membershipMono);
        StepVerifier.create(membershipMono)
                .expectNextMatches(membership -> membership.getMemberId().equals(ANY_MEMBER_ID1)
                        && membership.getMembershipKey().equals(ANY_MEMBERSHIP_KEY1)
                        && membership.getMembershipStatus().equals(MembershipStatusName.ACTIVE)
                        && membership.getMembershipEndDate().equals("2025-03-18"))
                .verifyComplete();
    }

    @Test
    void getMemberships_FilteredTheMostEndDateMembership_WhenApiReturnsMultipleRecords() throws Exception {
        mockMembershipSystemApiServer.enqueue(new MockResponse()
                .addHeader(CONTENT_TYPE, APPLICATION_JSON_VALUE)
                .setBody(objectMapper.writeValueAsString(Arrays.asList(
                            MembershipApiRequestFactory
                                    .createMembershipResponse(ANY_MEMBER_ID1, ANY_MEMBERSHIP_KEY1, MembershipStatusName.ACTIVE, "2025-03-18"),
                            MembershipApiRequestFactory
                                    .createMembershipResponse(ANY_MEMBER_ID2, ANY_MEMBERSHIP_KEY2, MembershipStatusName.ACTIVE, "2024-07-10"),
                            MembershipApiRequestFactory
                                    .createMembershipResponse(ANY_MEMBER_ID3, ANY_MEMBERSHIP_KEY3, MembershipStatusName.ACTIVE, "2026-01-20")
                        ))));

        Mono<MembershipResponse> membershipMono =
                membershipSystemApiService.getMemberships(MembershipApiRequestFactory.buildMembershipApiRequest());

        assertNotNull(membershipMono);
        StepVerifier.create(membershipMono)
                .expectNextMatches(membership -> membership.getMemberId().equals(ANY_MEMBER_ID3)
                        && membership.getMembershipKey().equals(ANY_MEMBERSHIP_KEY3)
                        && membership.getMembershipStatus().equals(MembershipStatusName.ACTIVE)
                        && membership.getMembershipEndDate().equals("2026-01-20"))
                .expectComplete()
                .verify();
    }

    @Test
    void getMemberships_FilteredMembership_WhenApiReturnsNoRecord() {
        mockMembershipSystemApiServer.enqueue(new MockResponse());

        Mono<MembershipResponse> membershipMono =
                membershipSystemApiService.getMemberships(MembershipApiRequestFactory.buildMembershipApiRequest());

        assertNotNull(membershipMono);
        StepVerifier.create(membershipMono)
                .expectNextCount(0)
                .expectComplete()
                .verify();
    }

    @AfterAll
    static void tearDown() throws IOException {
        mockMembershipSystemApiServer.shutdown();
    }
}
