package ca.bestbuy.account.mapper;


import static ca.bestbuy.account.factory.account.AddressRequestFactory.buildAddressRequest;
import static org.junit.jupiter.api.Assertions.assertEquals;

import ca.bestbuy.account.model.account.AddressRequest;
import ca.bestbuy.account.model.account.accountsystemapi.CreateAddressRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mapstruct.factory.Mappers;

class AddressRequestMapperTest {

    private AddressRequestMapper mapper;

    @BeforeEach
    public void beforeEach() {
        mapper = Mappers.getMapper(AddressRequestMapper.class);
    }

    @Test
    void addressRequestToCreateAddressRequestTest() {
        // Given
        AddressRequest addressRequest = buildAddressRequest();

        // When
        CreateAddressRequest createAddressRequest = mapper.addressRequestToCreateAddressRequest(addressRequest);

        // Expect
        assertEquals(addressRequest.getAddressLine1(), createAddressRequest.getAddressLine1());
        assertEquals(addressRequest.getAddressLine2(), createAddressRequest.getAddressLine2());
        assertEquals(addressRequest.getPostalCode(), createAddressRequest.getPostalCode());
        assertEquals(addressRequest.getProvinceCode(), createAddressRequest.getProvinceCode());
        assertEquals(addressRequest.getProvinceName(), createAddressRequest.getProvinceName());
        assertEquals(addressRequest.getCountryCode(), createAddressRequest.getCountryCode());
        assertEquals(addressRequest.getCountryName(), createAddressRequest.getCountryName());
        assertEquals(addressRequest.getCity(), createAddressRequest.getCity());
        assertEquals(addressRequest.getSuite(), createAddressRequest.getSuite());
        assertEquals(addressRequest.getPhoneNumber(), createAddressRequest.getPhoneNumber());
        assertEquals(addressRequest.getPhoneNumberExtension(), createAddressRequest.getPhoneNumberExtension());
        assertEquals(addressRequest.isDefaultAddress(), createAddressRequest.isDefaultAddress());
        assertEquals(addressRequest.getAddressType(), createAddressRequest.getAddressType());
        assertEquals(addressRequest.getAddressNickname(), createAddressRequest.getAddressNickname());
    }
}