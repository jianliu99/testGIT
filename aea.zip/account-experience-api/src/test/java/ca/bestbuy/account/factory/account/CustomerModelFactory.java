package ca.bestbuy.account.factory.account;

import static ca.bestbuy.account.utils.TestConstant.FIRST_NAME;
import static ca.bestbuy.account.utils.TestConstant.LAST_NAME;
import static ca.bestbuy.account.utils.TestConstant.PARTY_KEY;
import static java.util.Collections.emptyList;

import ca.bestbuy.account.model.customer.customersystemapi.CustomerModel;

public class CustomerModelFactory {
    public static CustomerModel buildCustomerModel() {
        return CustomerModel.builder()
            .firstName(FIRST_NAME)
            .lastName(LAST_NAME)
            .partyKey(PARTY_KEY)
            .addresses(emptyList())
            .build();
    }

    public static CustomerModel[] buildCustomerModelList() {
        return new CustomerModel[]{CustomerModel.builder()
            .firstName(FIRST_NAME)
            .lastName(LAST_NAME)
            .partyKey(PARTY_KEY)
            .addresses(emptyList())
            .build()};
    }
}
