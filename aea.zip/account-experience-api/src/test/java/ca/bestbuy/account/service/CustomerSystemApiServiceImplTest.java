package ca.bestbuy.account.service;

import static ca.bestbuy.account.factory.account.CustomerAccountReqFactory.buildCustomerAccountRequest;
import static ca.bestbuy.account.factory.account.CustomerAccountReqFactory.buildCustomerAccountRequestWithDefaultAddress;
import static ca.bestbuy.account.factory.account.CustomerGraphqlReqFactory.buildCustomerGraphqlReq;
import static ca.bestbuy.account.factory.account.CustomerGraphqlRespFactory.buildCreateCustomerGraphqlResp;
import static ca.bestbuy.account.factory.account.CustomerGraphqlRespFactory.buildGetCustomerGraphqlResp;
import static ca.bestbuy.account.factory.account.CustomerGraphqlRespFactory.buildUpdateCustomerGraphqlResp;
import static ca.bestbuy.account.factory.account.CustomerModelFactory.buildCustomerModelList;
import static ca.bestbuy.account.utils.TestConstant.FIRST_NAME;
import static ca.bestbuy.account.utils.TestConstant.LAST_NAME;
import static ca.bestbuy.account.utils.TestConstant.PARTY_KEY;
import static ca.bestbuy.account.utils.TestConstant.PHONE_NUMBER;
import static ca.bestbuy.account.utils.TestConstant.PHONE_NUMBER_EXTENSION;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import ca.bestbuy.account.exception.BadRequestException;
import ca.bestbuy.account.mapper.CustomerMapper;
import ca.bestbuy.account.model.accountcreation.CustomerAccountRequest;
import ca.bestbuy.account.model.customer.customersystemapi.CustomerGraphqlReq;
import ca.bestbuy.account.model.customer.customersystemapi.CustomerGraphqlResp;
import ca.bestbuy.account.model.customer.customersystemapi.CustomerModel;
import ca.bestbuy.account.service.customer.CustomerSystemApiServiceImpl;
import java.util.Map;
import java.util.UUID;
import java.util.function.Function;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.NullAndEmptySource;
import org.mockito.ArgumentMatchers;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@SuppressWarnings("unchecked")
@ExtendWith(MockitoExtension.class)
class CustomerSystemApiServiceImplTest {
    @Mock
    private WebClient webClient;

    @Mock
    private WebClient.RequestBodyUriSpec requestBodyUriSpec;

    @Mock
    private WebClient.RequestBodySpec requestBodySpec;

    @Mock
    private WebClient.RequestHeadersSpec requestHeadersSpec;

    @Mock
    private WebClient.ResponseSpec responseSpec;

    @Mock
    private CustomerMapper customerMapper;

    @Mock
    private Map<String, String> customerQueryMap;

    private CustomerSystemApiServiceImpl customerSystemApiService;

    @BeforeEach
    public void beforeEach() {
        customerSystemApiService = new CustomerSystemApiServiceImpl(webClient, "", 5L, customerMapper, customerQueryMap, 3, 1000L);
    }

    @Test
    void testUpdateCustomerName() {
        // Given
        CustomerAccountRequest updateCustomerReq = buildCustomerAccountRequest(UUID.randomUUID().toString());

        when(customerMapper.toCustomerGraphqlReq(updateCustomerReq)).thenReturn(buildCustomerGraphqlReq());
        when(webClient.post()).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(any(Function.class))).thenReturn(requestBodySpec);
        when(requestBodySpec.bodyValue(any())).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.onStatus(any(), any())).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(ArgumentMatchers.<Class<CustomerGraphqlResp>>notNull())).thenReturn(Mono.just(buildUpdateCustomerGraphqlResp()));

        // When
        CustomerModel result = customerSystemApiService.updateCustomer(updateCustomerReq).block();

        // Expect
        assertNotNull(result);
        assertEquals(FIRST_NAME, result.getFirstName());
        assertEquals(LAST_NAME, result.getLastName());
        assertEquals(PARTY_KEY, result.getPartyKey());
    }

    @ParameterizedTest
    @NullAndEmptySource
    void testUpdateCustomerNameMissingPartyKey(final String value) {
        // Given
        CustomerAccountRequest updateCustomerReq = buildCustomerAccountRequest(value);

        // When
        assertThrows(BadRequestException.class,
            () -> customerSystemApiService.updateCustomer(updateCustomerReq)
        );
    }

    @Test
    void testCreateCustomerSuccessfully_WithEmptyAddress() {
        // Given
        CustomerAccountRequest customerAccountRequest = buildCustomerAccountRequest();

        when(customerMapper.toCustomerGraphqlReq(customerAccountRequest)).thenReturn(buildCustomerGraphqlReq());
        when(webClient.post()).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(any(Function.class))).thenReturn(requestBodySpec);
        when(requestBodySpec.bodyValue(any())).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.onStatus(any(), any())).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(ArgumentMatchers.<Class<CustomerGraphqlResp>>notNull())).thenReturn(Mono.just(buildCreateCustomerGraphqlResp()));

        // When
        Mono<CustomerModel> customerModelMono = customerSystemApiService.createCustomer(customerAccountRequest);
        StepVerifier.create(customerModelMono).consumeNextWith(v -> {
            assertEquals(FIRST_NAME, v.getFirstName());
            assertEquals(LAST_NAME, v.getLastName());
            assertEquals(PARTY_KEY, v.getPartyKey());
        }).verifyComplete();
    }

    @Test
    void testCreateCustomerSuccessfully_WithDefaultAddress() {
        // Given
        CustomerAccountRequest customerAccountRequest = buildCustomerAccountRequestWithDefaultAddress();

        CustomerGraphqlReq customerGraphqlReq = buildCustomerGraphqlReq();
        when(customerMapper.toCustomerGraphqlReq(customerAccountRequest)).thenReturn(customerGraphqlReq);
        when(webClient.post()).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(any(Function.class))).thenReturn(requestBodySpec);
        when(requestBodySpec.bodyValue(any())).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.onStatus(any(), any())).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(ArgumentMatchers.<Class<CustomerGraphqlResp>>notNull())).thenReturn(Mono.just(buildCreateCustomerGraphqlResp()));

        // When
        Mono<CustomerModel> customerModelMono = customerSystemApiService.createCustomer(customerAccountRequest);

        assertNotNull(customerGraphqlReq);
        assertNotNull(customerGraphqlReq.getCustomerInput());
        assertEquals(PHONE_NUMBER, customerGraphqlReq.getCustomerInput().getPhoneNumber());
        assertEquals(PHONE_NUMBER_EXTENSION, customerGraphqlReq.getCustomerInput().getPhoneExtension());

        StepVerifier.create(customerModelMono).consumeNextWith(v -> {
            assertEquals(FIRST_NAME, v.getFirstName());
            assertEquals(LAST_NAME, v.getLastName());
            assertEquals(PARTY_KEY, v.getPartyKey());
        }).verifyComplete();
    }

    @Test
    void testGetCustomer() {
        // Given
        when(webClient.post()).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(any(Function.class))).thenReturn(requestBodySpec);
        when(requestBodySpec.bodyValue(any())).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.onStatus(any(), any())).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(ArgumentMatchers.<Class<CustomerGraphqlResp>>notNull())).thenReturn(Mono.just(buildGetCustomerGraphqlResp()));

        // When
        Flux<CustomerModel> customerModelFlux = customerSystemApiService.getCustomer(PARTY_KEY);

        // Then
        StepVerifier.create(customerModelFlux)
            .expectNextMatches(customer -> {
                assertEquals(PARTY_KEY, customer.getPartyKey());
                assertEquals(LAST_NAME, customer.getLastName());
                assertEquals(FIRST_NAME, customer.getFirstName());
                return true;
            })
            .verifyComplete();
    }
}