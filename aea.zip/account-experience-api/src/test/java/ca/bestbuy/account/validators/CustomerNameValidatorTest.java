package ca.bestbuy.account.validators;

import ca.bestbuy.account.exception.ValidationException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

@ExtendWith(MockitoExtension.class)
class CustomerNameValidatorTest {

    private CustomerNameValidator customerNameValidator;

    @BeforeEach
    void setUp() {
        customerNameValidator = new CustomerNameValidator();
    }

    @Test
    void doValidatePasses_WhenGivenValidName() throws ValidationException {
        String validaName = "Canada";
        customerNameValidator.validate(validaName);
    }

    @Test
    void doValidatePassesWhenGivenValidNameWithAcceptedEnglishAndSpecialCharacter() throws ValidationException {
        String validName = "abcdefghijklmnopqrstuvwxyz ,-.'";
        customerNameValidator.validate(validName);
    }

    @Test
    void doValidatePassesWhenGivenValidNameWithFrenchCharacter() throws ValidationException {
        String validName = "ÇéâêîôûàèùëïüÀÂÆæÉÈÊËÎÏÔŒœÙÛÜŸÿ";
        customerNameValidator.validate(validName);
    }

    @Test
    void doValidateThrowsValidationExceptionWhenGivenNameWithNotAcceptedCharacter() throws ValidationException {
        String nameWithUnacceptedChar = "Ǧanąda";
        ValidationException exception = assertThrows(ValidationException.class,
                () -> customerNameValidator.validate(nameWithUnacceptedChar));
        assertEquals("Input name in not valid format.", exception.getMessage());
    }

    @Test
    void doValidateThrowsValidationExceptionWhenGivenNull() throws ValidationException {
        ValidationException exception = assertThrows(ValidationException.class,
                () -> customerNameValidator.validate(null));
        assertEquals("Validator was passed null object.", exception.getMessage());
    }

    @Test
    void doValidateThrowsValidationExceptionWhenGivenEmptyString() throws ValidationException {
        ValidationException exception = assertThrows(ValidationException.class,
                () -> customerNameValidator.validate(""));
        assertEquals("Input name in not valid format.", exception.getMessage());
    }

    @Test
    void doValidateValidationExceptionWhenGivenTooLongString() throws ValidationException {
        String nameWithLengthOutOfRange = "The Separate Customs Territory of Taiwan Penghu Kinmen and Matsu";
        ValidationException exception = assertThrows(ValidationException.class,
                () -> customerNameValidator.validate(nameWithLengthOutOfRange));
        assertEquals("Input name in not valid format.", exception.getMessage());
    }

}