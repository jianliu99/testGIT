package ca.bestbuy.account.enums;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
class ErrorCodeTest {

    private static final String lockedString = "User account is locked";

    @Test
    void fromValueReturnsErrorCodeFromValue() {
        ErrorCode result = ErrorCode.fromValue(lockedString);

        assertEquals(ErrorCode.USER_IS_LOCKED, result);
    }

    @Test
    void fromValueReturnsDefaultErrorCodeFromUnknownValue() {
        ErrorCode result = ErrorCode.fromValue("Unknown");

        assertEquals(ErrorCode.ERROR, result);
    }

    @Test
    void toStringReturnsFriendlyString() {
        assertEquals(lockedString, ErrorCode.USER_IS_LOCKED.toString());
    }

    @Test
    void FromErrorNameReturnsDefaultForUnknownConstant() {
        ErrorCode result = ErrorCode.from("UNKNOWN");

        assertEquals(ErrorCode.ERROR, result);
    }
}