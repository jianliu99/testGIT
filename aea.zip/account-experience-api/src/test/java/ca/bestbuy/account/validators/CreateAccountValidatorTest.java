package ca.bestbuy.account.validators;

import ca.bestbuy.account.model.accountcreation.CustomerAccountRequest;
import ca.bestbuy.account.exception.ValidationException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doThrow;

@ExtendWith(MockitoExtension.class)
class CreateAccountValidatorTest {

    private CreateAccountValidator createAccountValidator;

    @Mock
    private EmailAddressValidator mockEmailAddressValidator;

    @Mock
    private CustomerNameValidator mockCustomerNameValidator;

    private CustomerAccountRequest testCustomerAccountRequest;

    @BeforeEach
    void setUp() {
        createAccountValidator = new CreateAccountValidator(mockEmailAddressValidator, mockCustomerNameValidator);

        testCustomerAccountRequest = CustomerAccountRequest.builder().email("mockEmail@gmail.com")
                .firstName("firstName").lastName("lastName").locale("en-CA").build();
    }

    @Test
    void validateThrowsValidationExceptionNullObject() {
        ValidationException exception = assertThrows(ValidationException.class,
                () -> createAccountValidator.validate(null));
        assertEquals("Validator was passed null object.", exception.getMessage());
    }

    @Test
    void doValidationThrowsValidationExceptionWhenCustomerFirstNameValidatorThrowsException() throws ValidationException {
        doThrow(new ValidationException("Input name in not valid format.")).when(mockCustomerNameValidator).validate(testCustomerAccountRequest.getFirstName());
        ValidationException exception = assertThrows(ValidationException.class,
                () -> createAccountValidator.validate(testCustomerAccountRequest));
        assertEquals("Input name in not valid format.", exception.getMessage());
    }

    @Test
    void doValidationThrowsValidationExceptionWhenCustomerLastNameValidatorThrowsException() throws ValidationException {
        doThrow(new ValidationException("Input name in not valid format.")).when(mockCustomerNameValidator).validate(testCustomerAccountRequest.getFirstName());
        ValidationException exception = assertThrows(ValidationException.class,
                () -> createAccountValidator.validate(testCustomerAccountRequest));
        assertEquals("Input name in not valid format.", exception.getMessage());
    }

    @Test
    void doValidationPassesWhenSubValidatorsDoesNotThrowAnyExceptions() throws ValidationException {
        createAccountValidator.validate(testCustomerAccountRequest);
    }

}