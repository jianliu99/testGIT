package ca.bestbuy.account.factory.account;

import static ca.bestbuy.account.factory.account.CustomerModelFactory.buildCustomerModel;
import static ca.bestbuy.account.factory.account.CustomerModelFactory.buildCustomerModelList;

import ca.bestbuy.account.model.customer.customersystemapi.CustomerGraphqlResp;
import ca.bestbuy.account.model.customer.customersystemapi.CustomerGraphqlResp.CustomerData;

public class CustomerGraphqlRespFactory {
    public static CustomerGraphqlResp buildCreateCustomerGraphqlResp() {
        return CustomerGraphqlResp.builder()
                .data(CustomerData.builder().createCustomer(buildCustomerModel()).build())
                .build();
    }

    public static CustomerGraphqlResp buildUpdateCustomerGraphqlResp() {
        return CustomerGraphqlResp.builder()
                .data(CustomerData.builder().updateCustomer(buildCustomerModel()).build())
                .build();
    }

    public static CustomerGraphqlResp buildGetCustomerGraphqlResp() {
        return CustomerGraphqlResp.builder()
            .data(CustomerGraphqlResp.CustomerData.builder().getCustomers(buildCustomerModelList()).build())
            .build();
    }
}
