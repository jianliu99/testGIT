package ca.bestbuy.account.service;

import static io.netty.handler.codec.http.HttpResponseStatus.BAD_GATEWAY;
import static io.netty.handler.codec.http.HttpResponseStatus.BAD_REQUEST;
import static io.netty.handler.codec.http.HttpResponseStatus.GATEWAY_TIMEOUT;
import static io.netty.handler.codec.http.HttpResponseStatus.INTERNAL_SERVER_ERROR;
import static io.netty.handler.codec.http.HttpResponseStatus.SERVICE_UNAVAILABLE;
import static io.netty.handler.codec.http.HttpResponseStatus.UNAUTHORIZED;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;
import static org.springframework.http.HttpHeaders.CONTENT_TYPE;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import ca.bestbuy.account.exception.ServerErrorException;
import ca.bestbuy.account.factory.account.CustomerAccountReqFactory;
import ca.bestbuy.account.mapper.CustomerMapper;
import ca.bestbuy.account.model.accountcreation.CustomerAccountRequest;
import ca.bestbuy.account.model.customer.customersystemapi.CustomerGraphqlReq;
import ca.bestbuy.account.model.customer.customersystemapi.CustomerGraphqlResp;
import ca.bestbuy.account.model.customer.customersystemapi.CustomerGraphqlResp.CustomerData;
import ca.bestbuy.account.model.customer.customersystemapi.CustomerModel;
import ca.bestbuy.account.service.customer.CustomerSystemApiService;
import ca.bestbuy.account.service.customer.CustomerSystemApiServiceImpl;
import java.io.IOException;
import java.util.Map;
import java.util.UUID;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.netty.handler.codec.http.HttpResponseStatus;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import okhttp3.mockwebserver.RecordedRequest;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpMethod;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@ExtendWith(MockitoExtension.class)
class CustomerSystemApiServiceRetryTest {

    private static final int RETRY_MAX_ATTEMPTS = 5;
    private static final long RETRY_DELAY_IN_MILLIS = 10L;
    public static final String ANY_PATH = "/anyPath";
    private static MockWebServer mockCustomerSystemApiServer;
    private static final ObjectMapper objectMapper = new ObjectMapper();
    @Mock
    private CustomerMapper customerMapper;

    @Mock
    private Map<String, String> customerQueryMap;

    private CustomerSystemApiService customerSystemApiService;

    private CustomerAccountRequest customerAccountRequest;
    private CustomerModel customerModel;

    @BeforeEach
    void beforeEach() throws IOException {
        mockCustomerSystemApiServer = new MockWebServer();
        mockCustomerSystemApiServer.start();

        String mockCustomerSystemApiUrl = String.format("http://localhost:%s", mockCustomerSystemApiServer.getPort());

        customerSystemApiService = new CustomerSystemApiServiceImpl(WebClient.builder().baseUrl(mockCustomerSystemApiUrl).build(),
                ANY_PATH, 1L,
                customerMapper, customerQueryMap, RETRY_MAX_ATTEMPTS, RETRY_DELAY_IN_MILLIS);

        customerAccountRequest = CustomerAccountReqFactory.buildCustomerAccountRequest();
        customerModel = CustomerModel.builder().build();
    }

    @AfterEach
    void tearDown() throws IOException {
        mockCustomerSystemApiServer.shutdown();
    }

    @Test
    void createCustomer_ReturnsResponse_WithoutRetry() throws Exception {
        CustomerGraphqlResp response = CustomerGraphqlResp.builder()
                .data(CustomerData.builder().createCustomer(customerModel).build()).build();

        when(customerMapper.toCustomerGraphqlReq(customerAccountRequest))
                .thenReturn(CustomerGraphqlReq.builder().customerInput(customerModel).build());

        mockCustomerSystemApiServer.enqueue(new MockResponse()
                .addHeader(CONTENT_TYPE, APPLICATION_JSON_VALUE)
                .setBody(objectMapper.writeValueAsString(response))
                .setResponseCode(HttpResponseStatus.OK.code()));

        Mono<CustomerModel> customerModelMono = customerSystemApiService.createCustomer(customerAccountRequest);

        assertNotNull(customerModelMono);
        StepVerifier.create(customerModelMono)
                .expectNext(customerModel)
                .verifyComplete();
    }

    @Test
    void createCustomer_NoRetry_ForBadRequest() {
        when(customerMapper.toCustomerGraphqlReq(customerAccountRequest))
                .thenReturn(CustomerGraphqlReq.builder().customerInput(customerModel).build());

        mockCustomerSystemApiServer.enqueue(new MockResponse().setResponseCode(BAD_REQUEST.code()));
        Mono<CustomerModel> customerModelMono = customerSystemApiService.createCustomer(customerAccountRequest);

        assertNotNull(customerModelMono);
        StepVerifier.create(customerModelMono).verifyComplete();
    }

    @Test
    void createCustomer_NoRetry_ForUnAuthorized() {

        when(customerMapper.toCustomerGraphqlReq(customerAccountRequest))
                .thenReturn(CustomerGraphqlReq.builder().customerInput(customerModel).build());

        mockCustomerSystemApiServer.enqueue(new MockResponse().setResponseCode(UNAUTHORIZED.code()));
        Mono<CustomerModel> customerModelMono = customerSystemApiService.createCustomer(customerAccountRequest);

        assertNotNull(customerModelMono);
        StepVerifier.create(customerModelMono).verifyComplete();
    }

    @Test
    void createCustomer_ReturnsResponse_WithRetry() throws Exception {

        CustomerGraphqlResp response = CustomerGraphqlResp.builder()
                .data(CustomerData.builder().createCustomer(customerModel).build()).build();

        when(customerMapper.toCustomerGraphqlReq(customerAccountRequest))
                .thenReturn(CustomerGraphqlReq.builder().customerInput(customerModel).build());

        mockCustomerSystemApiServer.enqueue(new MockResponse().setResponseCode(SERVICE_UNAVAILABLE.code()));
        mockCustomerSystemApiServer.enqueue(new MockResponse().setResponseCode(INTERNAL_SERVER_ERROR.code()));
        mockCustomerSystemApiServer.enqueue(new MockResponse().setResponseCode(BAD_GATEWAY.code()));
        mockCustomerSystemApiServer.enqueue(new MockResponse().setResponseCode(GATEWAY_TIMEOUT.code()));
        mockCustomerSystemApiServer.enqueue(new MockResponse()
                .addHeader(CONTENT_TYPE, APPLICATION_JSON_VALUE)
                .setBody(objectMapper.writeValueAsString(response))
                .setResponseCode(HttpResponseStatus.OK.code()));

        Mono<CustomerModel> customerModelMono = customerSystemApiService.createCustomer(customerAccountRequest);

        assertNotNull(customerModelMono);
        StepVerifier.create(customerModelMono)
                .expectNext(customerModel)
                .verifyComplete();

        verifyRetryCounts(RETRY_MAX_ATTEMPTS);
    }

    @Test
    void createCustomer_RetryExhaustedThrown_WhenReachMaxAttempts() throws Exception {
        customerAccountRequest.setPartyKey(UUID.randomUUID().toString());
        when(customerMapper.toCustomerGraphqlReq(customerAccountRequest))
                .thenReturn(CustomerGraphqlReq.builder().customerInput(customerModel).build());

        mockCustomerSystemApiServer.enqueue(new MockResponse().setResponseCode(SERVICE_UNAVAILABLE.code()));
        mockCustomerSystemApiServer.enqueue(new MockResponse().setResponseCode(INTERNAL_SERVER_ERROR.code()));
        mockCustomerSystemApiServer.enqueue(new MockResponse().setResponseCode(BAD_GATEWAY.code()));
        mockCustomerSystemApiServer.enqueue(new MockResponse().setResponseCode(GATEWAY_TIMEOUT.code()));
        mockCustomerSystemApiServer.enqueue(new MockResponse().setResponseCode(GATEWAY_TIMEOUT.code()));
        mockCustomerSystemApiServer.enqueue(new MockResponse().setResponseCode(GATEWAY_TIMEOUT.code()));

        Mono<CustomerModel> customerModelMono
                = customerSystemApiService.updateCustomer(customerAccountRequest);

        assertNotNull(customerModelMono);
        StepVerifier.create(customerModelMono)
                .expectError(ServerErrorException.class)
                .verify();

        verifyRetryCounts(RETRY_MAX_ATTEMPTS + 1);
    }

    @Test
    void updateCustomer_RetrySuccessfully_WithoutRetry() throws Exception {
        customerAccountRequest.setPartyKey(UUID.randomUUID().toString());
        when(customerMapper.toCustomerGraphqlReq(customerAccountRequest))
                .thenReturn(CustomerGraphqlReq.builder().customerInput(customerModel).build());

        CustomerModel customerModel = CustomerModel.builder().build();
        CustomerGraphqlResp response = CustomerGraphqlResp.builder()
                .data(CustomerData.builder().updateCustomer(customerModel).build()).build();

        mockCustomerSystemApiServer.enqueue(new MockResponse()
                .addHeader(CONTENT_TYPE, APPLICATION_JSON_VALUE)
                .setBody(objectMapper.writeValueAsString(response))
                .setResponseCode(HttpResponseStatus.OK.code()));

        Mono<CustomerModel> customerModelMono
                = customerSystemApiService.updateCustomer(customerAccountRequest);

        assertNotNull(customerModelMono);
        StepVerifier.create(customerModelMono)
                .expectNext(customerModel)
                .verifyComplete();
    }

    @Test
    void updateCustomer_NoRetry_ForBadRequest() {

        when(customerMapper.toCustomerGraphqlReq(customerAccountRequest))
                .thenReturn(CustomerGraphqlReq.builder().customerInput(customerModel).build());

        mockCustomerSystemApiServer.enqueue(new MockResponse().setResponseCode(BAD_REQUEST.code()));
        Mono<CustomerModel> customerModelMono = customerSystemApiService.createCustomer(customerAccountRequest);

        assertNotNull(customerModelMono);
        StepVerifier.create(customerModelMono).verifyComplete();
    }

    @Test
    void updateCustomer_NoRetry_ForUnAuthorized() {

        when(customerMapper.toCustomerGraphqlReq(customerAccountRequest))
                .thenReturn(CustomerGraphqlReq.builder().customerInput(customerModel).build());

        mockCustomerSystemApiServer.enqueue(new MockResponse().setResponseCode(UNAUTHORIZED.code()));
        Mono<CustomerModel> customerModelMono = customerSystemApiService.createCustomer(customerAccountRequest);

        assertNotNull(customerModelMono);
        StepVerifier.create(customerModelMono).verifyComplete();
    }

    @Test
    void updateCustomer_ReturnsResponse_WithRetry() throws Exception {
        customerAccountRequest.setPartyKey(UUID.randomUUID().toString());
        when(customerMapper.toCustomerGraphqlReq(customerAccountRequest))
                .thenReturn(CustomerGraphqlReq.builder().customerInput(customerModel).build());

        CustomerModel customerModel = CustomerModel.builder().build();
        CustomerGraphqlResp response = CustomerGraphqlResp.builder()
                .data(CustomerData.builder().updateCustomer(customerModel).build()).build();

        mockCustomerSystemApiServer.enqueue(new MockResponse().setResponseCode(SERVICE_UNAVAILABLE.code()));
        mockCustomerSystemApiServer.enqueue(new MockResponse().setResponseCode(INTERNAL_SERVER_ERROR.code()));
        mockCustomerSystemApiServer.enqueue(new MockResponse().setResponseCode(BAD_GATEWAY.code()));
        mockCustomerSystemApiServer.enqueue(new MockResponse().setResponseCode(GATEWAY_TIMEOUT.code()));
        mockCustomerSystemApiServer.enqueue(new MockResponse()
                .addHeader(CONTENT_TYPE, APPLICATION_JSON_VALUE)
                .setBody(objectMapper.writeValueAsString(response))
                .setResponseCode(HttpResponseStatus.OK.code()));

        Mono<CustomerModel> customerModelMono
                = customerSystemApiService.updateCustomer(customerAccountRequest);

        assertNotNull(customerModelMono);
        StepVerifier.create(customerModelMono)
                .expectNext(customerModel)
                .verifyComplete();

        verifyRetryCounts(RETRY_MAX_ATTEMPTS);
    }

    @Test
    void updateCustomer_RetryExhaustedThrown_WhenReachMaxAttempts() throws Exception {
        CustomerAccountRequest customerAccountRequest = CustomerAccountReqFactory.buildCustomerAccountRequest();
        customerAccountRequest.setPartyKey(UUID.randomUUID().toString());
        when(customerMapper.toCustomerGraphqlReq(customerAccountRequest))
                .thenReturn(CustomerGraphqlReq.builder().customerInput(customerModel).build());

        mockCustomerSystemApiServer.enqueue(new MockResponse().setResponseCode(SERVICE_UNAVAILABLE.code()));
        mockCustomerSystemApiServer.enqueue(new MockResponse().setResponseCode(INTERNAL_SERVER_ERROR.code()));
        mockCustomerSystemApiServer.enqueue(new MockResponse().setResponseCode(BAD_GATEWAY.code()));
        mockCustomerSystemApiServer.enqueue(new MockResponse().setResponseCode(GATEWAY_TIMEOUT.code()));
        mockCustomerSystemApiServer.enqueue(new MockResponse().setResponseCode(GATEWAY_TIMEOUT.code()));
        mockCustomerSystemApiServer.enqueue(new MockResponse().setResponseCode(GATEWAY_TIMEOUT.code()));

        Mono<CustomerModel> customerModelMono
                = customerSystemApiService.updateCustomer(customerAccountRequest);

        assertNotNull(customerModelMono);
        StepVerifier.create(customerModelMono)
                .expectError(ServerErrorException.class)
                .verify();

        verifyRetryCounts(RETRY_MAX_ATTEMPTS);
    }

    private void verifyRetryCounts(int attempts) throws Exception {
        for (int i = 0; i < attempts; i++) {
            RecordedRequest recordedRequest = mockCustomerSystemApiServer.takeRequest();
            assertEquals(HttpMethod.POST.name(), recordedRequest.getMethod());
            assertEquals(ANY_PATH, recordedRequest.getPath());
        }
    }
}