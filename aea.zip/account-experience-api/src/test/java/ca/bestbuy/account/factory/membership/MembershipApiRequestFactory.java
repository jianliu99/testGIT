package ca.bestbuy.account.factory.membership;

import static ca.bestbuy.account.utils.TestConstant.EMAIL_ADDRESS;

import ca.bestbuy.account.model.accountcreation.membershipapi.GetMembershipRequest;
import ca.bestbuy.account.model.accountcreation.membershipapi.MembershipResponse;
import ca.bestbuy.account.model.accountcreation.membershipapi.MembershipStatusName;

public class MembershipApiRequestFactory {

    public static GetMembershipRequest buildMembershipApiRequest() {
        return GetMembershipRequest.builder().emailAddress(EMAIL_ADDRESS).build();
    }

    public static MembershipResponse createMembershipResponse(int memberId, String membershipKey, MembershipStatusName status, String endDate) {
        return MembershipResponse.builder()
                .memberId(memberId)
                .membershipKey(membershipKey)
                .membershipStatus(status)
                .membershipEndDate(endDate)
                .build();
    }
}
