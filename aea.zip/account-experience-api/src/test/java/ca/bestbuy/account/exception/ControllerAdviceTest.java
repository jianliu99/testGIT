package ca.bestbuy.account.exception;

import static ca.bestbuy.account.utils.Constants.ERROR;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;


class ControllerAdviceTest {

    private final ControllerAdvice controllerAdvice = new ControllerAdvice();

    @Test
    void handleBadRequestExceptionTest() {
        String testMessage = "test message";
        BadRequestException badRequestException = new BadRequestException(testMessage);
        Map<String, Object> errorResponse = controllerAdvice.handleBadRequestException(badRequestException);
        assertEquals(testMessage, errorResponse.get(ERROR));
    }

    @Test
    void handleMethodArgumentNotValidExceptionTest() {
        // Mock BindingResult
        String errorMessage = "must not be null";
        String fieldName = "field";
        BindingResult bindingResult = mock(BindingResult.class);
        FieldError fieldError = new FieldError(fieldName, fieldName, errorMessage);
        when(bindingResult.hasFieldErrors()).thenReturn(true);
        when(bindingResult.getFieldErrors()).thenReturn(Collections.singletonList(fieldError));

        // Mock MethodArgumentNotValidException
        MethodArgumentNotValidException ex = mock(MethodArgumentNotValidException.class);
        when(ex.getBindingResult()).thenReturn(bindingResult);

        // Call method and assert response
        Map<String, Object> errorResponse = controllerAdvice.handleMethodArgumentNotValidException(ex);
        List<String> errorList = (List<String>) errorResponse.get(ERROR);
        assertEquals(1, errorList.size());
        assertEquals(String.format("%s: %s", fieldName, errorMessage), errorList.get(0));
    }
}