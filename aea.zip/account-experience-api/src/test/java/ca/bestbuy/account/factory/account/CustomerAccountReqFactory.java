package ca.bestbuy.account.factory.account;

import static ca.bestbuy.account.utils.TestConstant.ACCOUNT_KEY;
import static ca.bestbuy.account.utils.TestConstant.ADDRESS_LINE1;
import static ca.bestbuy.account.utils.TestConstant.CITY;
import static ca.bestbuy.account.utils.TestConstant.COUNTRY_CODE;
import static ca.bestbuy.account.utils.TestConstant.COUNTRY_NAME;
import static ca.bestbuy.account.utils.TestConstant.EMAIL_ADDRESS;
import static ca.bestbuy.account.utils.TestConstant.FIRST_NAME;
import static ca.bestbuy.account.utils.TestConstant.LANGUAGE;
import static ca.bestbuy.account.utils.TestConstant.LAST_NAME;
import static ca.bestbuy.account.utils.TestConstant.PHONE_NUMBER;
import static ca.bestbuy.account.utils.TestConstant.PHONE_NUMBER_EXTENSION;
import static ca.bestbuy.account.utils.TestConstant.POSTAL_CODE;
import static ca.bestbuy.account.utils.TestConstant.PROVINCE_CODE;
import static ca.bestbuy.account.utils.TestConstant.PROVINCE_NAME;
import static java.util.Collections.emptyList;

import ca.bestbuy.account.model.account.AddressRequest;
import ca.bestbuy.account.model.account.AddressType;
import ca.bestbuy.account.model.accountcreation.CustomerAccountRequest;
import java.util.Collections;

public class CustomerAccountReqFactory {

    public static CustomerAccountRequest buildCustomerAccountRequest() {
        return CustomerAccountRequest.builder()
                .firstName(FIRST_NAME)
                .lastName(LAST_NAME)
                .email(EMAIL_ADDRESS)
                .accountKey(ACCOUNT_KEY)
                .locale(LANGUAGE)
                .addresses(emptyList())
                .build();
    }

    public static CustomerAccountRequest buildCustomerAccountRequestWithDefaultAddress() {
        return CustomerAccountRequest.builder()
                .firstName(FIRST_NAME)
                .lastName(LAST_NAME)
                .email(EMAIL_ADDRESS)
                .accountKey(ACCOUNT_KEY)
                .locale(LANGUAGE)
                .addresses(Collections.singletonList(
                        AddressRequest.builder()
                                .addressLine1(ADDRESS_LINE1)
                                .addressType(AddressType.SHIPPING)
                                .countryCode(COUNTRY_CODE)
                                .countryName(COUNTRY_NAME)
                                .postalCode(POSTAL_CODE)
                                .phoneNumber(PHONE_NUMBER)
                                .phoneNumberExtension(PHONE_NUMBER_EXTENSION)
                                .city(CITY)
                                .provinceCode(PROVINCE_CODE)
                                .provinceName(PROVINCE_NAME)
                                .isDefaultAddress(true)
                                .build()))
                .build();
    }

    public static CustomerAccountRequest buildCustomerAccountRequest(final String partyKey) {
        return CustomerAccountRequest.builder()
                .firstName(FIRST_NAME)
                .lastName(LAST_NAME)
                .email(EMAIL_ADDRESS)
                .accountKey(ACCOUNT_KEY)
                .partyKey(partyKey)
                .locale(LANGUAGE)
                .addresses(emptyList())
                .build();
    }
}
