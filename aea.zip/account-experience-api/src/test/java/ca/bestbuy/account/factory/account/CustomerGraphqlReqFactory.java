package ca.bestbuy.account.factory.account;

import static ca.bestbuy.account.factory.account.CustomerModelFactory.buildCustomerModel;

import ca.bestbuy.account.model.customer.customersystemapi.CustomerGraphqlReq;

public class CustomerGraphqlReqFactory {

    public static CustomerGraphqlReq buildCustomerGraphqlReq() {
        return CustomerGraphqlReq.builder()
            .customerInput(buildCustomerModel())
            .build();
    }
}
