package ca.bestbuy.account.factory.account;

import static ca.bestbuy.account.utils.TestConstant.ADDRESS_LINE1;
import static ca.bestbuy.account.utils.TestConstant.ADDRESS_LINE2;
import static ca.bestbuy.account.utils.TestConstant.ADDRESS_NICKNAME;
import static ca.bestbuy.account.utils.TestConstant.CITY;
import static ca.bestbuy.account.utils.TestConstant.COUNTRY_CODE;
import static ca.bestbuy.account.utils.TestConstant.COUNTRY_NAME;
import static ca.bestbuy.account.utils.TestConstant.PHONE_NUMBER;
import static ca.bestbuy.account.utils.TestConstant.PHONE_NUMBER_EXTENSION;
import static ca.bestbuy.account.utils.TestConstant.POSTAL_CODE;
import static ca.bestbuy.account.utils.TestConstant.PROVINCE_CODE;
import static ca.bestbuy.account.utils.TestConstant.PROVINCE_NAME;
import static ca.bestbuy.account.utils.TestConstant.SUITE;

import ca.bestbuy.account.model.account.AddressRequest;
import ca.bestbuy.account.model.account.AddressType;

public class AddressRequestFactory {
    public static AddressRequest buildAddressRequest() {
        return AddressRequest.builder()
            .addressLine1(ADDRESS_LINE1)
            .addressLine2(ADDRESS_LINE2)
            .postalCode(POSTAL_CODE)
            .provinceCode(PROVINCE_CODE)
            .provinceName(PROVINCE_NAME)
            .countryCode(COUNTRY_CODE)
            .countryName(COUNTRY_NAME)
            .city(CITY)
            .suite(SUITE)
            .phoneNumber(PHONE_NUMBER)
            .phoneNumberExtension(PHONE_NUMBER_EXTENSION)
            .isDefaultAddress(true)
            .addressType(AddressType.SHIPPING)
            .addressNickname(ADDRESS_NICKNAME)
            .build();
    }
}
